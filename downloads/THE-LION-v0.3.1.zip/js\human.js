// Personas 3D con articulaciones (cadera, rodillas, hombros, codos, cuello).
// Formas suaves (torno + cápsulas) en vez de cajas. Se usa para la chica de la intro y el compañero en línea.
(function () {
  const T = THREE;
  function ph(c, sh) { return new T.MeshPhongMaterial({ color: c, shininess: sh || 6, specular: 0x1a1a1a }); }
  function lathe(pts, seg) { return new T.LatheGeometry(pts.map(p => new T.Vector2(p[0], p[1])), seg || 16); }
  function cap(r, len, m) { const g = new T.CapsuleGeometry(r, len, 4, 10); g.translate(0, -len / 2 - r * 0.2, 0); return new T.Mesh(g, m); }

  // o: { skin, cloth, pants, hair, dress, coat, hat, hairStyle: 'pony'|'long'|'short', scale }
  TL.makeHuman = function (o) {
    const skin = ph(o.skin || 0xb08068, 12), cloth = ph(o.cloth || 0x3a2c20), pants = ph(o.pants || 0x24211e), hairM = ph(o.hair || 0x1a120c, 20), boot = ph(o.boot || 0x2a1e14, 18);
    const g = new T.Group(), hips = new T.Group(); hips.position.y = 0.94; g.add(hips);
    // torso (torno, aplanado)
    const spine = new T.Group(); hips.add(spine);
    const torso = new T.Mesh(lathe([[0.001, -0.06], [0.15, -0.05], [0.16, 0.06], [0.14, 0.2], [0.16, 0.36], o.dress ? [0.16, 0.45] : [0.19, 0.46], [0.13, 0.55], [0.05, 0.6]]), cloth);
    torso.scale.z = 0.72; spine.add(torso);
    if (o.dress || o.coat) {
      const sk = new T.Mesh(lathe(o.dress ? [[0.15, 0.02], [0.2, -0.12], [0.3, -0.35], [0.36, -0.55], [0.35, -0.57]] : [[0.17, 0.02], [0.21, -0.15], [0.25, -0.38], [0.27, -0.5]], 18), cloth);
      sk.material = sk.material.clone(); sk.material.side = T.DoubleSide; sk.scale.z = 0.8; hips.add(sk);
    }
    if (o.coat) { const col = new T.Mesh(new T.TorusGeometry(0.09, 0.035, 6, 12), cloth); col.rotation.x = Math.PI / 2; col.position.y = 0.56; spine.add(col); }
    // cuello y cabeza
    const neck = new T.Mesh(new T.CylinderGeometry(0.045, 0.055, 0.1, 10), skin); neck.position.y = 0.62; spine.add(neck);
    const head = new T.Group(); head.position.y = 0.7; spine.add(head);
    const skull = new T.Mesh(new T.SphereGeometry(0.1, 18, 14), skin); skull.scale.set(0.95, 1.12, 1.02); skull.position.y = 0.06; head.add(skull);
    const jaw = new T.Mesh(new T.SphereGeometry(0.075, 12, 10), skin); jaw.scale.set(1, 0.8, 1.05); jaw.position.set(0, 0.0, 0.025); head.add(jaw);
    const nose = new T.Mesh(new T.ConeGeometry(0.016, 0.04, 6), skin); nose.rotation.x = Math.PI / 2; nose.position.set(0, 0.055, 0.105); head.add(nose);
    const eyeM = new T.MeshPhongMaterial({ color: 0x120c08, shininess: 80 });
    [-1, 1].forEach(sx => { const e = new T.Mesh(new T.SphereGeometry(0.012, 8, 6), eyeM); e.position.set(sx * 0.037, 0.08, 0.088); head.add(e);
      const ear = new T.Mesh(new T.SphereGeometry(0.022, 8, 6), skin); ear.scale.set(0.5, 1, 0.8); ear.position.set(sx * 0.098, 0.06, 0); head.add(ear); });
    const hairCap = new T.Mesh(new T.SphereGeometry(0.108, 18, 12, 0, Math.PI * 2, 0, Math.PI * 0.55), hairM); hairCap.scale.set(1, 1.12, 1.08); hairCap.position.set(0, 0.075, -0.01); hairCap.rotation.x = -0.25; head.add(hairCap);
    if (o.hairStyle === 'pony') { const pony = cap(0.035, 0.22, hairM); pony.position.set(0, 0.1, -0.1); pony.rotation.x = 0.5; head.add(pony); }
    if (o.hairStyle === 'long') { const lh = new T.Mesh(lathe([[0.1, 0.1], [0.11, 0], [0.1, -0.15], [0.085, -0.22]], 12), hairM); lh.scale.z = 0.8; lh.position.set(0, 0.04, -0.03); head.add(lh); }
    if (o.hat) {
      const brim = new T.Mesh(new T.CylinderGeometry(0.21, 0.22, 0.018, 20), hairM); brim.position.y = 0.15; head.add(brim);
      const crown = new T.Mesh(lathe([[0.11, 0], [0.115, 0.09], [0.085, 0.13], [0.001, 0.12]], 16), hairM); crown.position.y = 0.15; head.add(crown);
      const band = new T.Mesh(new T.CylinderGeometry(0.113, 0.113, 0.02, 16, 1, true), ph(0x5a3a22)); band.position.y = 0.17; head.add(band);
    }
    // brazos y piernas con articulación
    function limb(parent, x, y, l1, l2, r1, r2, m1, m2, end) {
      const root = new T.Group(); root.position.set(x, y, 0); parent.add(root);
      root.add(cap(r1, l1, m1));
      const joint = new T.Group(); joint.position.y = -l1 - r1 * 0.3; root.add(joint);
      joint.add(cap(r2, l2, m2));
      const tip = new T.Group(); tip.position.y = -l2 - r2 * 0.3; joint.add(tip);
      if (end === 'foot') { const f = new T.Mesh(new T.BoxGeometry(0.1, 0.07, 0.24), boot); f.position.set(0, -0.02, 0.05); tip.add(f); }
      else { const h = new T.Mesh(new T.SphereGeometry(0.038, 10, 8), skin); h.scale.set(0.9, 1.25, 0.6); h.position.y = -0.03; tip.add(h); }
      return { root, joint, tip };
    }
    const legM = o.dress ? skin : pants;
    const legL = limb(hips, -0.09, -0.02, 0.4, 0.4, 0.068, 0.052, legM, legM, 'foot'), legR = limb(hips, 0.09, -0.02, 0.4, 0.4, 0.068, 0.052, legM, legM, 'foot');
    const armM = o.dress ? skin : cloth;
    const armL = limb(spine, -0.2, 0.5, 0.27, 0.25, 0.048, 0.04, armM, o.dress ? skin : cloth, 'hand'), armR = limb(spine, 0.2, 0.5, 0.27, 0.25, 0.048, 0.04, armM, o.dress ? skin : cloth, 'hand');
    armL.root.rotation.z = 0.08; armR.root.rotation.z = -0.08;
    g.traverse(m => { if (m.isMesh) { m.castShadow = true; m.receiveShadow = true; } });
    g.rotation.order = 'YXZ'; if (o.scale) g.scale.setScalar(o.scale);
    return { g, hips, spine, head, legL, legR, armL, armR };
  };

  // caminar / correr: p = fase, k = 0..1 (quieto → corriendo)
  TL.poseWalk = function (h, p, k, run) {
    const s = Math.sin(p), c = Math.cos(p), a = (run ? 0.85 : 0.45) * k;
    h.legL.root.rotation.x = s * a; h.legR.root.rotation.x = -s * a;
    h.legL.joint.rotation.x = Math.max(0, -c) * a * 1.6 + 0.05; h.legR.joint.rotation.x = Math.max(0, c) * a * 1.6 + 0.05;
    h.armL.root.rotation.x = -s * a * 0.9; h.armR.root.rotation.x = s * a * 0.9;
    h.armL.joint.rotation.x = -(run ? 1.3 : 0.3) * k - 0.1; h.armR.joint.rotation.x = -(run ? 1.3 : 0.3) * k - 0.1;
    h.spine.rotation.x = (run ? 0.22 : 0.04) * k; h.spine.rotation.y = s * 0.12 * k;
    h.hips.position.y = 0.94 - Math.abs(c) * 0.05 * k * (run ? 1.6 : 1);
  };
})();
