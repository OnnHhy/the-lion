// Lógica principal: estados, intro, presentimiento, pistas, armario, muerte, final
(function () {
  const T = THREE;
  function R(a, b) { return a + Math.random() * (b - a); }
  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }
  const $ = id => document.getElementById(id);

  const G = TL.G = {
    state: 'title', time: 0, fear: 10, valor: 10, found: [], notes: [], hp: 100, hurtV: 0, inv: { trapo: 0, cinta: 0, vendas: 0 },
    theory: { monstruo: 2, familia: 0, humanos: 0 }, shotsAtLion: 0, shotsHit: 0,
    breath: { air: 100, noise: 0, covering: false, lock: 0 }, mouseRight: false, paused: false,
    checkpoint: { x: 0, z: 40, yaw: 0 }, pendingHunt: null, nextAmbient: 50, riverMsgT: 0
  };

  // ---------- Motor ----------
  const canvas = $('c');
  const renderer = new T.WebGLRenderer({ canvas, antialias: false, powerPreference: 'high-performance' });
  renderer.setPixelRatio(1); G.renderer = renderer;
  let scale = 0.8;
  const scene = G.scene = new T.Scene();
  scene.background = new T.Color(0x0a0f14); scene.fog = new T.FogExp2(0x0a0f14, 0.047);
  const camera = G.camera = new T.PerspectiveCamera(72, innerWidth / innerHeight, 0.05, 160); scene.add(camera);
  TL.tex.aniso = Math.min(4, renderer.capabilities.getMaxAnisotropy());
  renderer.shadowMap.enabled = true; renderer.shadowMap.type = T.PCFShadowMap;
  // postproceso propio (1 sola pasada): color de cine, viñeta, grano, aberración con el miedo
  const rt = new T.WebGLRenderTarget(16, 16, { minFilter: T.LinearFilter, magFilter: T.LinearFilter });
  const postMat = new T.ShaderMaterial({
    uniforms: { tDiffuse: { value: rt.texture }, uTime: { value: 0 }, uFear: { value: 0 }, uAberr: { value: 0 }, uRed: { value: 0 }, uRes: { value: new T.Vector2(1, 1) } },
    vertexShader: 'varying vec2 vUv; void main(){ vUv = uv; gl_Position = vec4(position.xy, 0.0, 1.0); }',
    fragmentShader: [
      'uniform sampler2D tDiffuse; uniform float uTime, uFear, uAberr, uRed; uniform vec2 uRes; varying vec2 vUv;',
      'float hash(vec2 p){ return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453); }',
      'void main(){ vec2 c = vUv - 0.5; float ab = 0.0018 + uAberr * 0.014 + uFear * 0.0035;',
      ' vec3 col = vec3(texture2D(tDiffuse, vUv + c * ab).r, texture2D(tDiffuse, vUv).g, texture2D(tDiffuse, vUv - c * ab).b);',
      ' float l = dot(col, vec3(0.299, 0.587, 0.114));',
      ' col = mix(col, col * vec3(0.82, 0.98, 1.12), (1.0 - smoothstep(0.0, 0.5, l)) * 0.55);',
      ' col = mix(col, col * vec3(1.14, 1.0, 0.84), smoothstep(0.3, 1.0, l));',
      ' col = clamp(col * 1.12, 0.0, 1.0); col = mix(col, col * col * (3.0 - 2.0 * col), 0.35);',
      ' col = mix(col, vec3(l), uFear * 0.3);',
      ' float v = smoothstep(0.95, 0.22 - uFear * 0.12, length(c * vec2(1.0, 1.25))); col *= mix(0.18, 1.0, v);',
      ' col = mix(col, vec3(col.r * 1.5 + 0.06, col.g * 0.35, col.b * 0.35), uRed * (1.0 - v * 0.6));',
      ' col += (hash(vUv * uRes + fract(uTime * 7.13) * 91.0) - 0.5) * 0.055;',
      ' gl_FragColor = vec4(col, 1.0); }'
    ].join('\n'), depthTest: false, depthWrite: false
  });
  const postScene = new T.Scene(), postCam = new T.OrthographicCamera(-1, 1, 1, -1, 0, 1);
  postScene.add(new T.Mesh(new T.PlaneGeometry(2, 2), postMat));
  function resize() {
    const w = Math.floor(innerWidth * scale), h = Math.floor(innerHeight * scale);
    renderer.setSize(w, h, false); rt.setSize(w, h); postMat.uniforms.uRes.value.set(w, h);
    camera.aspect = innerWidth / innerHeight; camera.updateProjectionMatrix();
  }
  addEventListener('resize', resize); resize();
  const hemi = new T.HemisphereLight(0x3a4a66, 0x0c0a08, 0.45); scene.add(hemi);
  const moonL = new T.DirectionalLight(0x9aaad6, 0.5); moonL.position.set(-40, 48, -60); scene.add(moonL); scene.add(moonL.target);
  moonL.shadow.mapSize.set(1024, 1024); moonL.shadow.bias = -0.0008; moonL.shadow.normalBias = 0.04;
  Object.assign(moonL.shadow.camera, { left: -30, right: 30, top: 30, bottom: -30, near: 1, far: 140 });
  const closetL = new T.PointLight(0x9aaad0, 0, 8, 1.4); scene.add(closetL); // luz de luna que entra por la puerta (vista desde el armario)
  const MOON_OFF = new T.Vector3(-40, 48, -60).normalize().multiplyScalar(70);

  // calidad: alta (sombras de luna), media (sin sombras), baja (menos efectos y resolución)
  G.quality = 'alta';
  function applyQuality(q) {
    G.quality = q; const sh = q === 'alta';
    renderer.shadowMap.enabled = sh; moonL.castShadow = sh;
    scene.traverse(o => { if (o.material) [].concat(o.material).forEach(m => m.needsUpdate = true); });
    if (G.world) G.world.mist.forEach(m => m.visible = q !== 'baja');
    if (q === 'baja' && scale > 0.6) { scale = 0.6; resize(); }
    try { localStorage.setItem('thelion.quality', q); } catch (e) { }
  }
  function benchMs() {
    const gl = renderer.getContext(); renderer.setRenderTarget(rt); renderer.render(scene, camera); gl.finish();
    const t = performance.now(); for (let i = 0; i < 4; i++) { renderer.setRenderTarget(rt); renderer.render(scene, camera); renderer.setRenderTarget(null); renderer.render(postScene, postCam); } gl.finish();
    renderer.setRenderTarget(null); return (performance.now() - t) / 4;
  }
  function autoQuality() {
    let saved = null; try { saved = localStorage.getItem('thelion.quality'); } catch (e) { }
    if (G.menuQ && G.menuQ !== 'auto') saved = G.menuQ;
    if (saved) { applyQuality(saved); return; }
    applyQuality('alta'); let ms = benchMs(); G.benchAlta = ms;
    if (ms > 13) { applyQuality('media'); ms = benchMs(); G.benchMedia = ms; if (ms > 20) applyQuality('baja'); }
    try { localStorage.removeItem('thelion.quality'); } catch (e) { }
  }

  // dificultad: sube con cada pista encontrada (0 → 1)
  // en línea es más difícil: arranca con dificultad y sube más rápido
  G.mp = () => !!(G.net && G.net.on);
  G.diff = () => G.mp() ? Math.min(1, 0.25 + 0.85 * G.found.length / TL.CLUE_COUNT) : Math.min(1, G.found.length / TL.CLUE_COUNT);
  // a quién puede cazar el león (tú y, en línea, tu compañero)
  G.players = () => {
    const l = []; if (['play', 'clue', 'notebook', 'inventory'].indexOf(G.state) >= 0) l.push(P);
    if (G.net && G.net.remoteActive()) l.push(G.net.remote);
    return l;
  };
  G.startGame = () => startGame();
  // ---------- Efectos: sangre al herir al león, polvo donde pega la bala ----------
  G.fx = (function () {
    const N = 60, geo = new T.BufferGeometry(), pos = new Float32Array(N * 3), parts = [];
    geo.setAttribute('position', new T.BufferAttribute(pos, 3));
    const bloodP = new T.Points(geo, new T.PointsMaterial({ color: 0x7a0a06, size: 0.07, transparent: true, opacity: 0.95, depthWrite: false })); bloodP.frustumCulled = false;
    const g2 = new T.BufferGeometry(), p2 = new Float32Array(N * 3), parts2 = []; g2.setAttribute('position', new T.BufferAttribute(p2, 3));
    const dustP = new T.Points(g2, new T.PointsMaterial({ color: 0x6a5e4e, size: 0.09, transparent: true, opacity: 0.7, depthWrite: false })); dustP.frustumCulled = false;
    scene.add(bloodP); scene.add(dustP);
    for (let i = 0; i < N; i++) { parts.push({ p: new T.Vector3(0, -99, 0), v: new T.Vector3(), t: 9 }); parts2.push({ p: new T.Vector3(0, -99, 0), v: new T.Vector3(), t: 9 }); }
    let bi = 0, di = 0;
    function burst(list, idx, at, n, spd, up) { for (let i = 0; i < n; i++) { const q = list[(idx + i) % N]; q.p.copy(at); q.v.set(R(-1, 1) * spd, R(0.2, 1) * up, R(-1, 1) * spd); q.t = 0; } return (idx + n) % N; }
    function step(list, arr, dt, grav) { list.forEach((q, i) => { if (q.t < 1.2) { q.t += dt; q.v.y -= grav * dt; q.p.addScaledVector(q.v, dt); if (q.p.y < 0.02) { q.p.y = 0.02; q.v.set(0, 0, 0); } } else q.p.y = -99; arr[i * 3] = q.p.x; arr[i * 3 + 1] = q.p.y; arr[i * 3 + 2] = q.p.z; }); }
    return {
      blood(at) { if (at) bi = burst(parts, bi, at, 22, 1.6, 2.2); },
      dust(at) { di = burst(parts2, di, at, 12, 0.6, 1.2); },
      update(dt) { step(parts, pos, dt, 9); geo.attributes.position.needsUpdate = true; step(parts2, p2, dt, 3); g2.attributes.position.needsUpdate = true; }
    };
  })();
  G.audio = new TL.Audio();
  G.world = new TL.World(scene);
  G.player = new TL.Player(G);
  G.lion = new TL.Lion(G, { body: 0x86643a, mane: 0x4a2e16, scale: 1.0, eye: 0xffd34a });
  G.lion2 = new TL.Lion(G, { body: 0x5a4430, mane: 0x1e140c, scale: 1.35, scars: true, eye: 0xffa830 });
  G.introLion = new TL.Lion(G, { body: 0x3a2e22, mane: 0x150e09, scale: 1.15, eye: 0xffc040 });
  const P = G.player;

  // ---------- UI ----------
  G.ui = {
    thought(text, dur) { const el = $('thought'); el.textContent = text; el.classList.add('on'); clearTimeout(this._t); this._t = setTimeout(() => el.classList.remove('on'), (dur || 3.8) * 1000); },
    prompt(html) { const el = $('prompt'); if (html && el._h !== html) { el.innerHTML = html; } el._h = html; el.classList.toggle('on', !!html); },
    ammo() {
      $('ammo').innerHTML = '<div class="nm">RIFLE</div><div class="row"><div class="ch' + (P.loaded ? '' : ' empty') + '"></div><div class="res"><small>×</small>' + P.reserve + '</div></div>' +
        (P.loaded === 0 && P.reserve > 0 ? '<div class="rl"><span class="kb">R</span>RECARGAR</div>' : (P.loaded === 0 ? '<div class="rl" style="color:#c9b994">SIN BALAS</div>' : ''));
    },
    caption(text, top) { const c = $('caption'); c.className = top ? 'top' : ''; c.textContent = text; c.style.opacity = text ? 1 : 0; },
    valor() { let h = ''; const n = Math.round(G.valor / 20); for (let i = 0; i < 5; i++) h += '<span class="' + (i < n ? 'on' : '') + '"></span>'; $('valor').innerHTML = h; },
    inv() {
      const el = $('invList'); if (!el) return;
      el.innerHTML = Object.keys(ITEMS).map(k => '<div class="it' + (G.inv[k] ? '' : ' none') + '"><b>' + (G.inv[k] || 0) + '</b><span>' + ITEMS[k][0] + '</span><small>' + ITEMS[k][1] + '</small></div>').join('') +
        '<div class="it' + (P.reserve ? '' : ' none') + '"><b>' + P.reserve + '</b><span>Balas</span><small>Para el rifle.</small></div>';
      $('crShoes').className = 'cr' + (P.shoes ? ' done' : G.inv.trapo >= 2 ? ' ok' : '');
      $('crArms').className = 'cr' + (P.armor ? ' done' : G.inv.trapo >= 2 && G.inv.cinta >= 1 ? ' ok' : '');
      $('crBand').className = 'cr' + (G.inv.vendas && G.hp < 100 ? ' ok' : '');
      $('eqs').innerHTML = (P.shoes ? '<span>PASOS SILENCIOSOS</span>' : '') + (P.armor ? '<span>BRAZOS PROTEGIDOS</span>' : '');
    },
    clues() { let h = ''; for (let i = 0; i < TL.CLUE_COUNT; i++) h += '<span class="' + (i < G.found.length ? 'on' : '') + '"></span>'; $('clues').innerHTML = h + '<em>PISTAS ' + G.found.length + '/' + TL.CLUE_COUNT + '</em>'; },
    hp() { $('hpf').style.width = G.hp + '%'; $('hptrail').style.width = G.hp + '%'; $('hpn').textContent = Math.ceil(G.hp); $('sthp').classList.toggle('low', G.hp < 35); }
  };
  $('ver').textContent = 'THE LION · ' + TL.VERSION; $('tver').textContent = TL.VERSION + ' — Pueblo 1';
  function show(id, on) { $(id).style.display = on ? 'flex' : 'none'; }

  // ---------- Entrada ----------
  function locked() { return document.pointerLockElement === canvas; }
  function lock() {
    try { const r = canvas.requestPointerLock(); if (r && r.catch) r.catch(() => { }); } catch (e) { }
    setTimeout(() => { if (!locked() && G.state === 'play' && !G.noLockPause) { G.paused = true; show('pause', true); $('qlbl2').textContent = (QN || {})[G.quality] || ''; } }, 500);
  }
  addEventListener('keydown', e => {
    if (e.target && e.target.tagName === 'INPUT') return;
    if (['Tab', 'Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].indexOf(e.code) >= 0) e.preventDefault();
    P.keys[e.code] = true; if (e.repeat) return;
    const s = G.state;
    if (s === 'title' && e.code === 'Enter') { startGame(); return; }
    if (s === 'intro' && (e.code === 'Space' || e.code === 'Enter')) { beginPlay(); return; }
    if (s === 'clue' && (e.code === 'KeyE' || e.code === 'Space' || e.code === 'Enter')) { closeClue(); return; }
    if (s === 'notebook' && (e.code === 'Tab' || e.code === 'Escape')) { closeNotebook(); return; }
    if (s === 'inventory') { if (e.code === 'KeyI' || e.code === 'Escape' || e.code === 'Tab') closeInv(); else if (e.code === 'Digit1') craft('shoes'); else if (e.code === 'Digit2') craft('arms'); else if (e.code === 'Digit3') useBandage(); return; }
    if (s === 'struggle' && (e.code === 'KeyE' || e.code === 'Space')) { G.struggle.prog += 0.085 + G.valor / 2000; G.audio.grunt(); return; }
    if (s === 'play') {
      if (e.code === 'Tab') { openNotebook(); return; }
      if (e.code === 'KeyI') { openInv(); return; }
      if (e.code === 'KeyH') { useBandage(); return; }
      if (e.code === 'KeyE') { interact(); return; }
      if (e.code === 'KeyG') { const order = ['alta', 'media', 'baja'], q = order[(order.indexOf(G.quality) + 1) % 3]; applyQuality(q); if (q !== 'baja' && scale < 0.8) { scale = 0.8; resize(); } G.ui.thought('Calidad gráfica: ' + q.toUpperCase(), 2); return; }
      if (e.code === 'F3') { const f = $('fps'); f.style.display = f.style.display === 'block' ? 'none' : 'block'; return; }
      P.press(e.code);
    }
  });
  addEventListener('keyup', e => { P.keys[e.code] = false; });
  addEventListener('contextmenu', e => e.preventDefault());
  addEventListener('mousedown', e => {
    const s = G.state;
    if (s === 'title') return; // el menú tiene sus propios botones
    if (s === 'dead') { respawn(); return; }
    if (s === 'ending') { if (G.endShown) location.reload(); return; }
    if (s === 'clue') { closeClue(); return; }
    if (s === 'play') {
      if (!locked()) { lock(); return; }
      if (e.button === 0) P.press('Fire');
      if (e.button === 2) G.mouseRight = true;
    }
  });
  addEventListener('mouseup', e => { if (e.button === 2) G.mouseRight = false; });
  addEventListener('mousemove', e => {
    if (!locked() || G.state !== 'play') return;
    P.yaw -= e.movementX * 0.0022; P.pitch -= e.movementY * 0.0022;
  });
  document.addEventListener('pointerlockchange', () => {
    const pause = !locked() && G.state === 'play';
    G.paused = pause; show('pause', pause); $('qlbl2').textContent = QN[G.quality];
    if (!locked()) G.mouseRight = false;
  });
  $('pause').addEventListener('mousedown', e => { e.stopPropagation(); if (e.target.closest('#btnQ2')) return; lock(); });
  // ---------- Menú ----------
  const QN = { auto: 'AUTO', alta: 'ALTA', media: 'MEDIA', baja: 'BAJA' };
  try { G.menuQ = localStorage.getItem('thelion.quality') || 'auto'; } catch (e) { G.menuQ = 'auto'; }
  $('qlbl').textContent = QN[G.menuQ] || 'AUTO';
  document.querySelectorAll('.btn').forEach(b => b.addEventListener('mouseenter', () => G.audio.ui(false)));
  $('btnPlay').addEventListener('mousedown', e => { e.stopPropagation(); startGame(); });
  $('btnCtrl').addEventListener('mousedown', e => { e.stopPropagation(); const c = $('ctrls'); c.style.display = c.style.display === 'block' ? 'none' : 'block'; $('btnCtrl').classList.toggle('sel'); G.audio.ui(true); });
  $('btnQ').addEventListener('mousedown', e => {
    e.stopPropagation(); const o = ['auto', 'alta', 'media', 'baja']; G.menuQ = o[(o.indexOf(G.menuQ) + 1) % 4]; $('qlbl').textContent = QN[G.menuQ]; G.audio.ui(true);
    try { if (G.menuQ === 'auto') localStorage.removeItem('thelion.quality'); else localStorage.setItem('thelion.quality', G.menuQ); } catch (err) { }
  });
  $('btnQ2').addEventListener('mousedown', e => {
    e.stopPropagation(); const o = ['alta', 'media', 'baja'], q = o[(o.indexOf(G.quality) + 1) % 3]; applyQuality(q); if (q !== 'baja' && scale < 0.8) { scale = 0.8; resize(); }
    $('qlbl2').textContent = QN[q]; G.audio.ui(true);
  });

  // ---------- Título → Intro ----------
  function startGame() {
    if (G.state !== 'title') return;
    G.audio.init(); G.audio.resume();
    try { autoQuality(); } catch (e) { }
    show('title', false); startIntro();
  }

  function makeGirl() {
    const h = TL.makeHuman({ skin: 0xc89a7a, cloth: 0x7a1c1c, hair: 0x1a120c, dress: true, hairStyle: 'pony', boot: 0x3a2418, scale: 0.95 });
    scene.add(h.g); return h;
  }

  // Intro: la chica corre, el león la tumba, ella forcejea, la muerde despacio. Luego llega la camioneta.
  let girl = null; const IS = new T.Vector3(-18, 0, 46), IE = new T.Vector3(-6.5, 0, 33.5), IL = new T.Vector3(-1.5, 0, 30.5);
  G.car = TL.makeCar(scene); G.car.g.visible = false;
  const CAR_STOP = new T.Vector3(1.9, 0, 48.2);
  function startIntro() {
    G.state = 'intro'; G.introT = 0; G.introFlags = {};
    girl = makeGirl(); girl.g.position.copy(IS);
    G.introLion.place(IL.x, IL.z, Math.atan2(IE.x - IL.x, IE.z - IL.z)); G.introLion.group.visible = false; G.introLion.state = 'statue';
    P.light = false; $('fade').style.opacity = 1; $('skip').style.display = 'block';
  }
  function once(k) { if (G.introFlags[k]) return false; G.introFlags[k] = true; return true; }
  function updateIntro(dt) {
    const t = G.introT += dt, L = G.introLion;
    if (t > 0.4 && once('fadein')) $('fade').style.opacity = 0;
    if (t > 0.6 && once('cap1')) G.ui.caption('PUEBLO DE LAS CIÉNAGAS', true);
    if (t > 4.0 && once('cap1off')) G.ui.caption('');
    const dir = new T.Vector3().subVectors(IE, IS).normalize(), side = new T.Vector3(-dir.z, 0, dir.x);
    const gp = girl ? girl.g.position : IE;
    if (t < 6.0) {
      const p = clamp((t - 0.6) / 5.4, 0, 1); girl.g.position.lerpVectors(IS, IE, p); girl.g.rotation.y = Math.atan2(dir.x, dir.z);
      TL.poseWalk(girl, t * 11, 1, true);
      const back = (t > 2.6 && t < 3.2) || (t > 4.4 && t < 4.9); girl.head.rotation.y += ((back ? 1.6 : 0) - girl.head.rotation.y) * Math.min(1, dt * 8);
      if (!G.introFlags.st || t - G.introFlags.st > 0.3) { G.introFlags.st = t; if (t > 0.6) { const w = G.world.wetAt(gp.x, gp.z); G.audio.step(true, true, w); if (w) G.world.ripple(gp.x, gp.z); } }
      const hs = Math.sin(t * 9) * 0.03;
      camera.position.set(gp.x - dir.x * 3.4 + side.x * 1.3, 1.55 + hs, gp.z - dir.z * 3.4 + side.z * 1.3);
      camera.lookAt(gp.x + dir.x * 4, 1.1, gp.z + dir.z * 4);
    }
    if (t > 3.4 && once('growl')) G.audio.growl(L.pos, false, 2.0);
    if (t > 5.4 && t < 6.0) {
      L.group.visible = true; const u = (t - 5.4) / 0.6;
      L.pos.lerpVectors(IL, gp, u); L.pos.y = Math.sin(Math.PI * u) * 1.3; L.roarAnim = 0.3; L.sync(); L.animate(dt);
    }
    if (t >= 6.0 && once('hit')) {
      G.audio.roar(L.pos, false); G.audio.thud(); G.audio.gasp(); $('flash').style.opacity = 0.6; P.shake = 1;
      G.introGirlPos = gp.clone();
    }
    if (t >= 6.0 && t < 10.3) {
      const k = Math.min(1, (t - 6.0) / 0.35), base = G.introGirlPos;
      // ella cae de espaldas y se arrastra un poco hacia atrás
      const crawl = clamp((t - 6.4) / 2.0, 0, 1) * 0.5;
      girl.g.rotation.y = Math.atan2(dir.x, dir.z); girl.g.rotation.x = -k * Math.PI / 2 * 0.92;
      girl.g.position.set(base.x - dir.x * crawl, 0.12 * k, base.z - dir.z * crawl);
      // el león encima, mirando hacia su cuello
      const headAt = new T.Vector3(girl.g.position.x - dir.x * 1.45, 0, girl.g.position.z - dir.z * 1.45);
      L.heading = Math.atan2(-dir.x, -dir.z);
      L.pos.set(headAt.x + dir.x * 1.25 * L.scale, 0, headAt.z + dir.z * 1.25 * L.scale);
      L.t += dt; L.speed = 0; L.state = 'statue'; L.animate(dt);
      const fight = t < 8.2, w = fight ? 1 : Math.max(0, 1 - (t - 8.2) / 1.2);
      // forcejeo: brazos empujando, piernas pateando
      const f1 = Math.sin(t * 13), f2 = Math.sin(t * 11 + 1.3);
      girl.armL.root.rotation.x = -2.4 + f1 * 0.5 * w - (1 - w) * 0.4; girl.armR.root.rotation.x = -2.3 + f2 * 0.5 * w - (1 - w) * 0.4;
      girl.armL.joint.rotation.x = -0.6 - f2 * 0.4 * w; girl.armR.joint.rotation.x = -0.6 - f1 * 0.4 * w;
      girl.legL.root.rotation.x = -0.4 + f2 * 0.5 * w; girl.legR.root.rotation.x = -0.3 - f1 * 0.5 * w; girl.legL.joint.rotation.x = 0.6 + f1 * 0.4 * w; girl.legR.joint.rotation.x = 0.6 - f2 * 0.4 * w;
      girl.head.rotation.y = Math.sin(t * 7) * 0.5 * w; girl.spine.rotation.x = -0.1 + Math.sin(t * 9) * 0.06 * w;
      // el león: gruñe con la boca abierta y después baja la cabeza despacio hacia el cuello
      const bite = clamp((t - 8.2) / 1.8, 0, 1);
      L.crouchY = -0.05 - bite * 0.28; L.sync();
      L.m.head.rotation.x = (fight ? 0.25 + Math.sin(t * 8) * 0.12 : 0.25 + bite * 0.75);
      L.m.jaw.rotation.x = fight ? 0.35 + Math.max(0, Math.sin(t * 8)) * 0.25 : 0.55 - bite * 0.3;
      if (fight && (!G.introFlags.gr || t - G.introFlags.gr > 0.9)) { G.introFlags.gr = t; G.audio.growl(L.pos, false, 0.8); G.audio.gasp(); }
      // cámara baja de costado, se acerca
      const push = clamp((t - 8.2) / 2, 0, 1);
      const cx = girl.g.position.x - dir.x * 1.0 + side.x * (2.6 - push * 1.0), cz = girl.g.position.z - dir.z * 1.0 + side.z * (2.6 - push * 1.0);
      camera.position.set(cx + (Math.random() - 0.5) * 0.04 * P.shake, 0.55 + push * 0.1, cz);
      camera.lookAt(headAt.x, 0.45, headAt.z); P.shake = Math.max(0, P.shake - dt * 0.6);
    }
    if (t > 10.0 && once('bite')) { G.audio.bite(); $('flash').style.opacity = 0.85; }
    $('flash').style.opacity = Math.max(0, parseFloat($('flash').style.opacity || 0) - dt * 1.2);
    [6.4, 7.3, 8.4, 9.3].forEach((b, i) => { if (t > b && once('hb' + i)) G.audio.heartbeat(0.9 - i * 0.2); });
    if (t > 10.3 && once('black')) { $('fade').style.opacity = 1; }
    if (t > 11.0 && once('cap2')) G.ui.caption('Nadie supo quién era.');
    if (t > 12.8 && once('cap3')) G.ui.caption('Tres días después…');
    // ---- llegada en camioneta ----
    if (t > 14.4 && once('car')) {
      G.ui.caption(''); if (girl) { scene.remove(girl.g); girl = null; } L.off();
      G.car.g.visible = true; G.car.lights(true); G.car.g.position.set(0.6, 0, 104); G.car.g.rotation.y = 0;
      G.engine = G.audio.engine(); $('fade').style.opacity = 0;
    }
    if (t > 14.4 && t < 22.5) {
      const u = clamp((t - 14.4) / 6.2, 0, 1), e = 1 - Math.pow(1 - u, 2.2), C = G.car.g;
      const z = 104 + (CAR_STOP.z - 104) * e, x = 0.6 + (CAR_STOP.x - 0.6) * clamp((u - 0.7) / 0.3, 0, 1);
      const spd = u < 1 ? (CAR_STOP.z - 104) * 2.2 * Math.pow(1 - u, 1.2) / 6.2 : 0;
      C.position.set(x, Math.sin(t * 14) * 0.012 * (1 - u), z); C.rotation.y = -(CAR_STOP.x - 0.6) * 0.12 * Math.sin(Math.PI * clamp((u - 0.7) / 0.3, 0, 1));
      G.car.wheels.forEach(w => w.rotation.x += spd * dt / 0.36);
      if (G.engine) G.engine.set(Math.min(1, Math.abs(spd) / 9), x, z);
      if (u >= 1 && once('stop')) { G.engine.stop(); G.engine = null; }
      if (t > 21.0 && once('door')) G.audio.carDoor(true);
      if (t > 21.9 && once('door2')) G.audio.carDoor(false);
      // cámara: desde la entrada del pueblo, siguiendo las luces que se acercan por el pantano
      const cz = 45.5, cx = -6.5; camera.position.set(cx, 1.7 + Math.sin(t * 0.4) * 0.05, cz);
      camera.lookAt(C.position.x * 0.7, 0.9, C.position.z - 1);
      if (t > 15.2 && once('cap4')) G.ui.caption('Me pidieron que viniera a investigar.', false);
      if (t > 18.6 && once('cap4off')) G.ui.caption('');
    }
    if (t > 22.5 && once('end')) { G.colCar = G.world.colliders.push({ minX: CAR_STOP.x - 0.95, maxX: CAR_STOP.x + 0.95, minY: 0, maxY: 1.5, minZ: CAR_STOP.z - 2.3, maxZ: CAR_STOP.z + 2.3 }); beginPlay(); }
  }

  function blink() {
    const top = document.querySelector('#lids .top'), bot = document.querySelector('#lids .bot');
    [top, bot].forEach(l => { l.style.transition = 'none'; l.style.height = '50%'; });
    $('fade').style.transition = 'none'; $('fade').style.opacity = 0;
    setTimeout(() => { [top, bot].forEach(l => { l.style.transition = 'height 1.1s ease-out'; l.style.height = '8%'; }); }, 200);
    setTimeout(() => { [top, bot].forEach(l => { l.style.transition = 'height .14s ease-in'; l.style.height = '50%'; }); }, 1400);
    setTimeout(() => { [top, bot].forEach(l => { l.style.transition = 'height .8s ease-out'; l.style.height = '0'; }); $('fade').style.transition = 'opacity .8s'; }, 1650);
  }

  function beginPlay() {
    if (G.state !== 'intro') return;
    if (girl) { scene.remove(girl.g); girl = null; }
    if (G.engine) { G.engine.stop(); G.engine = null; }
    G.car.g.visible = true; G.car.lights(true); G.car.g.position.copy(CAR_STOP); G.car.g.rotation.y = 0;
    if (!G.colCar) G.colCar = G.world.colliders.push({ minX: CAR_STOP.x - 0.95, maxX: CAR_STOP.x + 0.95, minY: 0, maxY: 1.5, minZ: CAR_STOP.z - 2.3, maxZ: CAR_STOP.z + 2.3 });
    G.introLion.off(); G.ui.caption(''); $('skip').style.display = 'none'; $('flash').style.opacity = 0;
    G.world.blood.visible = true; G.world.scarf.visible = true;
    P.pos.set(0.3, 0, 46.5); P.yaw = 0.05; P.pitch = 0; P.light = true; P.shake = 0;
    G.state = 'play'; G.fear = 15; G.hp = 100; $('hud').style.display = 'block'; G.ui.ammo(); G.ui.valor(); G.ui.clues(); G.ui.hp();
    blink(); lock();
    setTimeout(() => G.ui.thought('Aquí la encontraron… Tengo que averiguar qué pasó.', 4.5), 2600);
    setTimeout(() => { $('help').style.opacity = 0; }, 20000);
  }

  // ---------- Interacción ----------
  function nearestInteract() {
    const c = camera.position, f = P.fwd(); let best = null, bs = 1e9;
    for (const it of G.world.interact) {
      if (it.done || (it.kind === 'closet' && it.ref.destroyed)) continue;
      const dx = it.x - c.x, dy = it.y - c.y, dz = it.z - c.z, d = Math.hypot(dx, dy, dz);
      if (d > 2.5) continue; const dot = (dx * f.x + dy * f.y + dz * f.z) / d; if (dot < 0.55) continue;
      // armario / cama: solo desde dentro de esa casa y por delante
      if (it.kind === 'closet') {
        const h = it.ref; if (G.world.buildingAt(P.pos.x, P.pos.z) !== h.b) continue;
        if ((h.front.x - h.x) * (P.pos.x - h.x) + (h.front.z - h.z) * (P.pos.z - h.z) <= 0.05) continue;
      }
      // nada a través de las paredes
      if (it.kind !== 'door' && TL.collide.segmentBlocked(c.x, c.z, it.x, it.z, it.y + 0.15, G.world.colliders)) continue;
      const sc = d * (1.7 - dot); if (sc < bs) { bs = sc; best = it; }
    }
    return best;
  }
  function interact() {
    if (P.hidden) { P.unhide(); P.pressed.Space = false; G.audio.thud(); return; }
    const it = nearestInteract(); if (!it) return;
    if (it.kind === 'clue') openClue(it);
    else if (it.kind === 'closet') { P.hide(it.ref); G.breath.air = 100; G.breath.noise = 0; }
    else if (it.kind === 'ammo') { if (G.net) G.net.send({ t: 'take', i: G.world.interact.indexOf(it) }); it.done = true; it.mesh.visible = false; P.reserve += 3; G.ui.ammo(); G.audio.bolt(); G.ui.thought('Tres balas. No es mucho.'); }
    else if (it.kind === 'heal' || it.kind === 'item') {
      if (G.net) G.net.send({ t: 'take', i: G.world.interact.indexOf(it) });
      it.done = true; it.mesh.visible = false; G.audio.cloth();
      const id = it.kind === 'heal' ? 'vendas' : it.item; G.inv[id] = (G.inv[id] || 0) + (id === 'cinta' ? 2 : 1);
      G.ui.thought({ vendas: 'Vendas. Las guardo (H para usarlas).', trapo: 'Unos trapos viejos… pueden servir. (I = inventario)', cinta: 'Una caja con cinta. Con trapos podría envolverme algo.' }[id], 3); G.ui.inv();
    }
    else if (it.kind === 'door') {
      const d = it.ref; d.setOpen(!d.open); G.audio.door(d, d.open); if (G.net) G.net.send({ t: 'door', i: G.world.doors.indexOf(d), o: d.open });
    }
  }
  // ---------- Inventario ----------
  const ITEMS = { trapo: ['Trapos', 'Tela vieja. Sirve para envolver.'], cinta: ['Cinta', 'Para sujetar trapos.'], vendas: ['Vendas', 'Cura 45 de vida.'] };
  function openInv() { G.state = 'inventory'; show('inv', true); G.audio.cloth(); G.ui.inv(); }
  function closeInv() { show('inv', false); G.state = 'play'; if (!locked()) lock(); }
  function useBandage() {
    if (!G.inv.vendas) { G.ui.thought('No tengo vendas.', 2); return; }
    if (G.hp >= 100) { G.ui.thought('No estoy herido.', 2); return; }
    G.inv.vendas--; G.hp = Math.min(100, G.hp + 45); G.ui.hp(); G.audio.heal(); G.ui.inv(); G.ui.thought('Me vendé la herida. Ya duele menos.');
  }
  function craft(k) {
    if (k === 'shoes') {
      if (P.shoes) return; if (G.inv.trapo < 2) { G.ui.thought('Necesito 2 trapos para envolver los zapatos.', 2.5); return; }
      G.inv.trapo -= 2; P.shoes = true; G.audio.cloth(); closeInv(); G.ui.thought('Me envolví los zapatos con trapos. Mis pasos casi no se oyen.', 3.5);
    } else if (k === 'arms') {
      if (P.armor) return; if (G.inv.trapo < 2 || G.inv.cinta < 1) { G.ui.thought('Necesito 2 trapos y cinta para envolverme los brazos.', 2.5); return; }
      G.inv.trapo -= 2; G.inv.cinta -= 1; P.armor = true; closeInv(); G.audio.cloth(); setTimeout(() => G.audio.tape(), 600);
      P.handMeshes.forEach(m => { if (m.geometry.type === 'BoxGeometry' || m.geometry.type === 'CylinderGeometry') m.material = P.wrapM; });
      P.startInspect(3.2); setTimeout(() => G.ui.thought('Brazos envueltos. Si me muerde, no entrará tan hondo.', 3.5), 1200);
    }
    G.ui.inv();
  }

  // registrar una pista (la encontraras tú o tu compañero)
  G.applyFound = function (id) {
    if (G.found.indexOf(id) >= 0) return null;
    const line = TL.pickLine(id, G.found); G.found.push(id); G.notes.push({ id, text: line.text });
    Object.keys(line.w).forEach(k => G.theory[k] += line.w[k]);
    G.valor = Math.min(100, 10 + G.found.length * 13); G.ui.valor(); G.ui.clues();
    const it = G.world.interact.find(i => i.kind === 'clue' && i.id === id); if (it) it.done = true;
    return line;
  };
  function openClue(it) {
    const id = it.id, c = TL.CLUES[id], line = G.applyFound(id); if (!line) return;
    if (G.net) G.net.send({ t: 'found', id });
    const cv = $('cluecv'), x = cv.getContext('2d'); x.drawImage(TL.art(id), 0, 0, 512, 352);
    $('clueplace').textContent = c.place.toUpperCase(); $('cluename').textContent = c.name; $('cluetext').textContent = '';
    let i = 0; clearInterval(G.typeI); G.typeI = setInterval(() => { i += 2; $('cluetext').textContent = line.text.slice(0, i); if (i >= line.text.length) clearInterval(G.typeI); }, 22);
    G.audio.page(); G.state = 'clue'; show('clue', true); G.ui.prompt('');
    G.pendingClue = { b: G.world.buildingAt(it.x, it.z), x: it.x, z: it.z };
  }
  // después de una pista: el león viene a esa casa (lo decide quien manda: el anfitrión o el juego solo)
  G.afterClue = function (b, who, mine) {
    const boss = !G.mp() || G.net.host;
    if (b && !b.hunted) {
      b.hunted = true; let late = false;
      if (mine) { G.fear = 100; G.audio.sting(); G.checkpoint = { x: b.doorOut.x, z: b.doorOut.z, yaw: b.s > 0 ? -Math.PI / 2 : Math.PI / 2 }; }
      if (boss) { late = Math.random() < 0.25 * (1 - G.diff() * 0.6); const d = G.diff(); G.pendingHunt = { b, who, t: G.time + (late ? R(10, 15) : R(2, 4) * (1 - d * 0.4)) }; }
      if (mine) setTimeout(() => G.ui.thought(late ? 'Silencio… demasiado silencio.' : '…algo viene. ¡Escóndete!'), 900);
    } else if (mine) {
      G.fear = Math.max(G.fear, 72); G.audio.sting(); G.checkpoint = { x: P.pos.x, z: P.pos.z, yaw: P.yaw };
      if (!b && boss) setTimeout(() => G.audio.growl({ x: P.pos.x + R(-20, 20), z: P.pos.z - 25 }, false, 1.8), 1500);
    }
  };
  G.closeClue = () => closeClue(); G.closeNotebook = () => closeNotebook();
  function closeClue() {
    clearInterval(G.typeI); show('clue', false); G.state = 'play'; if (!locked()) lock();
    G.afterClue(G.pendingClue.b, P, true);
    if (G.found.length === 4) setTimeout(() => G.ui.thought('Siento que me sigue más de cerca… como si supiera lo que estoy descubriendo.'), 9000);
    if (G.found.length === TL.CLUE_COUNT) setTimeout(() => G.ui.thought('No queda nada más en este lado. El río está al norte.'), 5000);
    else if (G.found.length === 3) setTimeout(() => G.ui.thought('El río está al norte… pero todavía hay cosas escondidas en el pueblo.'), 5000);
  }

  function openNotebook() {
    G.state = 'notebook'; show('notebook', true); G.audio.page();
    $('nbentries').innerHTML = G.notes.length ? G.notes.map(n => '<div class="e"><b>' + TL.CLUES[n.id].name.toUpperCase() + '</b>' + n.text + '</div>').join('') : '<div class="e">Todavía no encontré nada.</div>';
    $('nbbelief').textContent = G.found.length + ' de ' + TL.CLUE_COUNT + ' cosas encontradas. ¿Qué crees tú que pasó?';
  }
  function closeNotebook() { show('notebook', false); G.state = 'play'; G.audio.page(); }

  // ---------- Disparos y rugidos ----------
  G.onShot = function (o, dir, who) {
    who = who || P;
    if (dir.y < -0.01) { const t = -o.y / dir.y; if (t < 50) G.fx.dust(o.clone().addScaledVector(dir, t)); }
    if (who === P) { G.fear = Math.min(100, G.fear + 10); if (G.mp()) { G.net.send({ t: 'shot', o: [o.x, o.y, o.z], d: [dir.x, dir.y, dir.z] }); if (!G.net.host) return; } }
    G.lastShot = G.time; const L = G.lion; let hit = false;
    if (L.active() && L.group.visible) {
      const to = new T.Vector3(L.pos.x - o.x, 1 - o.y, L.pos.z - o.z), d = to.length();
      if (d < 45 && to.normalize().dot(dir) > Math.cos(0.3)) { G.shotsAtLion++; G.theory.monstruo += 1; }
      for (const s of L.hitSpheres()) {
        const oc = new T.Vector3().subVectors(o, s.c), b = oc.dot(dir), c = oc.lengthSq() - s.r * s.r, h = b * b - c;
        if (h < 0) continue; const tt = -b - Math.sqrt(h); if (tt < 0) continue;
        const hp = o.clone().addScaledVector(dir, tt);
        if (!TL.collide.segmentBlocked(o.x, o.z, hp.x, hp.z, hp.y, G.world.colliders)) { hit = true; G.lastHitPoint = hp; break; }
      }
      if (hit) { G.fx.blood(G.lastHitPoint); G.audio.hitLion(L.pos); if (who === P) { const c = $('cross'); c.classList.add('hit'); setTimeout(() => c.classList.remove('hit'), 280); } G.shotsHit++; L.onHit(); if (who === P) setTimeout(() => G.ui.thought(L.hits > 1 ? 'Huyó otra vez…' : 'Le di… y huyó.'), 600); else if (G.net) G.net.send({ t: 'say', m: L.hits > 1 ? 'Huyó otra vez…' : 'Le di… y huyó.' }); }
      else if (['hunt', 'leave', 'prowl', 'track'].indexOf(L.state) >= 0 && Math.hypot(L.pos.x - who.pos.x, L.pos.z - who.pos.z) < 40) { L.tgt = who; L.lastSeen = G.time; L.startChase(); }
      else if (L.state === 'ambient') L.flee();
    }
  };
  G.onRoar = function (pos, big, mild) {
    const d = Math.hypot(pos.x - P.pos.x, pos.z - P.pos.z); if (d > 42) return;
    const k = (mild ? 0.7 : big ? 2.3 : 1.6) * (1 - G.valor / 140) * (d < 20 ? 1 : 0.5);
    P.para = Math.max(P.para, k); P.shake = Math.max(P.shake, mild ? 0.5 : 1); G.fear = Math.min(100, G.fear + 20); G.aberr = mild ? 0.5 : 1;
    if (k > 0.8 && !P.hidden) G.ui.thought('No puedo moverme…', 1.6);
  };
  G.onLionGone = function () { };
  G.onLionLeftCloset = function () { setTimeout(() => { if (P.hidden) G.ui.thought('Se fue… tengo que salir de aquí. Ya.'); }, 2500); };

  // ---------- Muerte ----------
  const DEATH = {
    bite: ['Te mordió el cuello.', 'Cuando te tumbe, presiona E o ESPACIO muy rápido para soltarte. Envolverte los brazos (trapos + cinta) ayuda.'],
    pounce: ['El león te alcanzó.', 'Con poca vida un zarpazo te mata. Busca vendas. Para subir a un techo: sube a una caja, salta y mantén ESPACIO.'],
    breath: ['Te escuchó respirar.', 'Mantén ESPACIO para taparte la boca cuando esté cerca… pero suéltalo antes de ahogarte.'],
    stayed: ['Te quedaste demasiado tiempo.', 'Cuando se va, sal del armario rápido. Siempre vuelve.'],
    seen: ['Te vio entrar al armario.', 'Escóndete cuando no te esté mirando.']
  };
  // daño: el león ya no mata de un golpe (salvo con poca vida)
  G.hurt = function (amount, reason) {
    if (G.state !== 'play') return;
    G.hp = Math.max(0, G.hp - amount); G.hurtV = Math.min(1, G.hurtV + 0.5 + amount / 80); G.ui.hp();
    P.shake = Math.max(P.shake, 0.6 + amount / 60); G.aberr = 1; G.audio.hurt(); $('flash').style.opacity = 0.45;
    if (G.hp <= 0) G.caught(reason);
  };
  G.lionAttack = function (L, reason) {
    const base = reason === 'pounce' ? 38 : 62, dmg = base * (1 + G.diff() * 0.4) * (G.mp() ? 1.15 : 1);
    const tgt = L.pl ? L.pl() : P;
    if (tgt !== P && G.net) {   // zarpazo al compañero
      G.net.send({ t: 'hurt', dmg, reason, lx: L.pos.x, lz: L.pos.z });
      L.roarAnim = 1; G.audio.roar(L.pos, false);
      L.state = 'pin'; L.pinT = 3.9; L.vel = 0; L.pinWho = tgt;
      tgt.hp = Math.max(0, tgt.hp - dmg); if (tgt.hp <= 0) { tgt.downT = G.time; L.tgt = null; }
      return;
    }
    if (G.state === 'clue') closeClue(); if (G.state === 'notebook') closeNotebook();
    if (G.state !== 'play') return;
    G.takeHit(L.pos, dmg, reason, L);
  };
  // recibir el zarpazo (aquí o enviado por el anfitrión)
  // ---------- El león te tumba: forcejeo (E / ESPACIO rápido) ----------
  G.takeHit = function (lpos, dmg, reason, L) {
    if (G.state === 'clue') closeClue(); if (G.state === 'notebook') closeNotebook(); if (G.state === 'inventory') closeInv();
    if (G.state !== 'play') return;
    if (P.armor) dmg *= 0.6;
    if (P.hidden) { const c = P.hidden; P.unhide(); }
    const LL = L && L.update ? L : G.lion; // el león que se ve (en el invitado es el títere)
    if (L && L.update) { L.state = 'pin'; L.pinT = 99; L.vel = 0; }
    const f = new T.Vector3(lpos.x - P.pos.x, 0, lpos.z - P.pos.z); if (f.length() < 0.1) f.set(0, 0, -1); f.normalize();
    G.struggle = { t: 0, prog: 0.15, dmg, reason, L: LL, real: !!(L && L.update), dir: f, lim: 3.2 - G.diff() * 0.6, biteT: 0 };
    LL.pos.set(P.pos.x + f.x * 1.55, 0, P.pos.z + f.z * 1.55); // el cuerpo encima, la cara sobre ti LL.heading = Math.atan2(-f.x, -f.z); LL.group.visible = true; LL.sync();
    P.yaw = Math.atan2(-f.x, -f.z); P.mantle = null; P.vy = 0;
    G.state = 'struggle'; show('struggle', true); G.audio.roar(lpos, false); G.audio.hurt(); P.shake = 1.2; G.hurtV = 0.8; G.fear = 100;
    $('flash').style.opacity = 0.5;
  };
  function updateStruggle(dt) {
    const S = G.struggle, L = S.L; S.t += dt;
    S.prog = Math.max(0, S.prog - dt * (0.2 + G.diff() * 0.12));
    $('strf').style.width = Math.min(100, S.prog * 100) + '%'; $('strt').style.width = Math.max(0, 100 - S.t / S.lim * 100) + '%';
    // cámara en el suelo mirando al león encima
    const hp = new T.Vector3(); L.m.head.getWorldPosition(hp);
    camera.position.set(P.pos.x - S.dir.x * 0.25 + R(-0.02, 0.02) * (1 + P.shake), 0.3 + Math.sin(S.t * 9) * 0.02, P.pos.z - S.dir.z * 0.25);
    camera.lookAt(hp.x, hp.y - 0.1 + Math.sin(S.t * 3) * 0.08, hp.z); P.shake = Math.max(0.15, P.shake - dt);
    L.roarAnim = Math.max(L.roarAnim, Math.sin(S.t * 5) > 0.3 ? 0.4 : 0); if (!G.mp()) { L.t += dt; L.speed = 0; L.animate(dt); }
    L.m.head.rotation.x = 0.75 + Math.sin(S.t * 6) * 0.2; L.m.jaw.rotation.x = 0.25 + Math.max(0, Math.sin(S.t * 6)) * 0.35; L.sync();
    if (S.prog >= 1) endStruggle(true); else if (S.t >= S.lim) endStruggle(false);
  }
  function endStruggle(ok) {
    const S = G.struggle, L = S.L; show('struggle', false); G.state = 'play';
    const dmg = ok ? Math.min(S.dmg * 0.25, 14) : S.dmg;
    if (!ok) { G.audio.bite(); $('flash').style.opacity = 0.9; G.hurtV = 1; }
    if (G.hp - dmg <= 0) {
      if (S.real) { if (G.mp()) { L.state = 'recover'; L.recT = 3.5; L.tgt = null; } else L.state = 'pounce'; }
      G.hp = 0; G.ui.hp(); G.caught(S.reason === 'pounce' ? 'bite' : S.reason); return;
    }
    G.hurt(dmg, S.reason); P.para = ok ? 0.3 : 0.9; P.land = 0.5;
    // el león retrocede
    if (S.real) { L.state = 'recover'; L.recT = ok ? 2.2 : R(1.4, 2.0) * (1 - G.diff() * 0.3); L.vel = 0; L.roarAnim = 1; }
    else if (G.net) G.net.send({ t: 'freed', ok });
    const back = TL.collide.move(P.pos.x, P.pos.z, -S.dir.x * 1.2, -S.dir.z * 1.2, 0.35, 0, 1.7, G.world.colliders); P.pos.x = back.x; P.pos.z = back.z;
    G.ui.thought(ok ? '¡Me solté! ¡Corre!' : (G.hp < 35 ? '¡Me mordió… estoy sangrando mucho!' : '¡Me mordió! ¡Corre!'), 2.2);
  }
  G.takeHitOld = function (lpos, dmg, reason, L) {
    if (G.state !== 'play') return;
    if (G.hp - dmg <= 0) {
      if (L && L.update) { if (G.mp()) { L.state = 'recover'; L.recT = 3.5; L.tgt = null; } else L.state = reason === 'pounce' ? 'pounce' : 'idle'; }
      G.hp = 0; G.ui.hp(); G.caught(reason); return;
    }
    L = L || { pos: lpos };
    if (P.hidden) { const c = P.hidden; P.unhide(); P.pos.x = c.x + c.b.s * 1.6; } // te saca del armario
    // empujón hacia atrás
    const dx = P.pos.x - L.pos.x, dz = P.pos.z - L.pos.z, d = Math.hypot(dx, dz) || 1;
    const r = TL.collide.move(P.pos.x, P.pos.z, dx / d * 1.4, dz / d * 1.4, 0.35, P.pos.y, P.pos.y + 1.7, G.world.colliders); P.pos.x = r.x; P.pos.z = r.z;
    P.yaw = Math.atan2(-(L.pos.x - P.pos.x), -(L.pos.z - P.pos.z)); P.para = 0.7; P.land = 0.4;
    G.hurt(dmg, reason);
    if (L.update) { L.roarAnim = 1; G.audio.roar(L.pos, false); L.state = 'recover'; L.recT = R(1.4, 2.0) * (1 - G.diff() * 0.3); L.vel = 0; }
    G.ui.thought(G.hp < 35 ? '¡Estoy sangrando mucho… necesito vendas!' : '¡Me hirió! ¡Corre!', 2.2);
  };
  G.caught = function (reason) {
    if (G.state !== 'play') return;
    G.state = 'dying'; G.dieT = 0; G.caughtReason = reason || 'pounce';
    const L = G.lion;
    if (!P.hidden && !G.mp()) {
      const f = P.fwd(), fl = Math.hypot(f.x, f.z) || 1; L.pos.set(P.pos.x + f.x / fl * 2.7, 0, P.pos.z + f.z / fl * 2.7); L.heading = Math.atan2(P.pos.x - L.pos.x, P.pos.z - L.pos.z); L.group.visible = true; L.sync();
    }
    L.roarAnim = 2; G.audio.roar(L.pos, false); $('flash').style.opacity = 0.85; P.shake = 1.5;
  };
  function updateDying(dt) {
    G.dieT += dt; const L = G.lion; if (!G.mp()) { L.animate(dt); L.sync(); }
    if (!P.hidden) { const target = Math.atan2(-(L.pos.x - P.pos.x), -(L.pos.z - P.pos.z)); P.yaw += (target - P.yaw) * Math.min(1, dt * 6); P.pitch += (-0.25 - P.pitch) * dt * 3; P.pos.y = Math.max(0, P.pos.y - dt * 2); P.eye = Math.max(0.3, P.eye - dt * 1.5); }
    P.shake = Math.max(P.shake, 0.6); P.placeCam ? (P.hidden ? null : P.placeCam(dt, 0)) : null;
    if (P.hidden) { camera.position.x += R(-0.05, 0.05); }
    $('flash').style.opacity = Math.max(0.15, parseFloat($('flash').style.opacity) - dt * 0.5);
    if (G.dieT > 0.9) $('fade').style.opacity = 1;
    if (G.dieT > 1.9 && G.state === 'dying') {
      G.state = 'dead'; const m = DEATH[G.caughtReason] || DEATH.pounce;
      $('deadt').textContent = m[0]; $('deadh').textContent = m[1]; show('dead', true);
      if (locked()) document.exitPointerLock();
    }
  }
  function respawn() {
    show('dead', false); $('flash').style.opacity = 0; $('fade').style.opacity = 0;
    if (G.mp()) { if (G.net.host && G.lion.active()) G.lion.leave(false); } else { G.lion.off(); G.pendingHunt = null; }
    G.fear = 35; G.hp = 100; show('struggle', false); G.hurtV = 0; G.ui.hp(); G.breath = { air: 100, noise: 0, covering: false, lock: 0 };
    if (P.hidden) P.hidden.grp.visible = true;
    P.hidden = null; P.para = 0; P.shake = 0; P.vy = 0; P.mantle = null; P.eye = 1.65;
    P.pos.set(G.checkpoint.x, 0, G.checkpoint.z); P.yaw = G.checkpoint.yaw; P.pitch = 0;
    G.state = 'play'; G.nextAmbient = G.time + R(40, 70); lock(); blink();
  }

  // ---------- Final ----------
  G.startEnding = () => startEnding();
  function startEnding() {
    if (G.state === 'ending') return;
    if (G.net) G.net.send({ t: 'end' });
    if (G.state === 'clue') show('clue', false); if (G.state === 'notebook') show('notebook', false); show('dead', false);
    G.state = 'ending'; G.endT = 0; G.endKey = TL.pickEnding(G); G.ui.prompt(''); $('hud').style.display = 'none';
    if (locked()) document.exitPointerLock(); G.lion.off();
    // del otro lado del río solo se ven dos ojos en la niebla
    G.lion2.place(2, -84, 0); G.lion2.state = 'statue'; G.lion2.m.glows.forEach(g => { g.material.depthTest = false; g.renderOrder = 10; });
  }
  function updateEnding(dt) {
    const t = G.endT += dt, L2 = G.lion2;
    const hx = L2.pos.x + Math.sin(L2.heading) * 1.5, hz = L2.pos.z + Math.cos(L2.heading) * 1.5;
    const ty = Math.atan2(-(hx - P.pos.x), -(hz - P.pos.z));
    let a = ty - P.yaw; while (a > Math.PI) a -= Math.PI * 2; while (a < -Math.PI) a += Math.PI * 2;
    P.yaw += a * Math.min(1, dt * 1.5); P.pitch += (0.02 - P.pitch) * dt * 1.5;
    camera.fov += (34 - camera.fov) * dt * 0.8; camera.updateProjectionMatrix();
    camera.position.set(P.pos.x, P.pos.y + 1.65, P.pos.z); camera.rotation.set(P.pitch, P.yaw, 0, 'YXZ');
    if (t > 2.4 && G.endKey !== 'creyo' && !G.endRoar) { G.endRoar = true; L2.roarAnim = 3; G.audio.roar(L2.pos, true); P.shake = 1; G.fear = 100; }
    if (t > 7 && !G.endShown) {
      G.endShown = true; const e = TL.ENDINGS[G.endKey];
      $('endt').textContent = e.title; $('endx').textContent = e.text;
      $('ends').innerHTML = 'Pistas encontradas: ' + G.found.length + ' / ' + TL.CLUE_COUNT + '<br>Disparos al león: ' + G.shotsAtLion + ' · Impactos: ' + G.shotsHit + '<br>' + (P.shoes ? 'Pasos silenciosos · ' : '') + (P.armor ? 'Brazos envueltos · ' : '') + 'Hay 5 finales en esta versión.';
      show('ending', true);
    }
  }

  // ---------- Presentimiento, aire, HUD ----------
  function updateFear(dt) {
    let target = 8, nd = 1e9;
    for (const it of G.world.interact) { if (it.kind !== 'clue' || it.done) continue; nd = Math.min(nd, Math.hypot(it.x - P.pos.x, it.z - P.pos.z)); }
    if (nd < 14) target = Math.max(target, 12 + (1 - nd / 14) * 50);
    const L = G.lion;
    if (L.active()) {
      const dl = L.dist(P.pos); target = Math.max(target, (1 - dl / 32) * 100);
      if (['hunt', 'closet', 'return', 'chase', 'windup', 'prowl', 'track', 'pin'].indexOf(L.state) >= 0) target = Math.max(target, 62);
    }
    if (G.pendingHunt) target = Math.max(target, 70);
    G.fear += (target - G.fear) * Math.min(1, (G.fear < target ? 0.9 : 0.18) * dt);
    G.fear = clamp(G.fear, 0, 100);
  }
  function updateBreath(dt) {
    const br = G.breath;
    if (!P.hidden) { br.air = Math.min(100, br.air + 30 * dt); br.noise = 0; br.covering = false; return; }
    if (br.lock > 0) br.lock -= dt;
    br.covering = !!P.keys.Space && br.lock <= 0;
    if (br.covering) {
      br.air -= 15 * dt; br.noise = Math.max(0, br.noise - 25 * dt);
      if (br.air <= 0) { br.air = 25; br.noise = Math.min(100, br.noise + 75); br.lock = 1.2; G.audio.gasp(); G.ui.thought('¡Aire!', 1.2); }
    } else {
      br.air = Math.min(100, br.air + 25 * dt);
      br.noise = clamp(br.noise + (4 + G.fear * 0.32 - 10) * dt, 0, 100);
    }
  }
  let fpsN = 0, fpsT = 0;
  function updateHUD(dt, now) {
    $('fearf').style.width = G.fear.toFixed(1) + '%';
    $('stamf').style.width = P.stamina.toFixed(0) + '%';
    $('flash').style.opacity = Math.max(0, parseFloat($('flash').style.opacity || 0) - dt * 1.5);
    const cs = 8 + G.fear / 100 * 16 * (1 - G.valor / 160) * (P.aiming ? 0.4 : 1) + (P.speedNow > 0 ? 4 : 0);
    const cr = $('cross'); cr.style.width = cr.style.height = cs.toFixed(1) + 'px'; cr.style.margin = (-cs / 2) + 'px 0 0 ' + (-cs / 2) + 'px'; cr.style.display = P.hidden || G.state === 'struggle' ? 'none' : 'block';
    G.hurtV = Math.max(0, G.hurtV - dt * 0.7);
    $('hurt').style.opacity = Math.min(1, G.hurtV + (G.hp < 35 ? (0.25 + Math.sin(G.time * 5) * 0.12) * (1 - G.hp / 35) + 0.1 : 0)).toFixed(3);
    $('stfear').classList.toggle('hot', G.fear > 70);
    $('stam').style.opacity = P.stamina > 98 ? 0 : 1;
    const hid = !!P.hidden; $('closet').style.display = hid ? 'block' : 'none'; if (hid) $('closet').className = 'ov ' + (P.hidden.kind === 'bed' ? 'bed' : ''); $('breath').style.display = hid ? 'block' : 'none';
    if (hid) {
      $('airf').style.width = G.breath.air.toFixed(0) + '%'; $('noisef').style.width = G.breath.noise.toFixed(0) + '%';
      $('noisef').style.background = G.breath.noise > 40 ? '#d0301a' : '#c0902a';
      G.ui.prompt('');
    } else if (G.state === 'play') {
      const it = nearestInteract(); G.ui.prompt(it ? '<kbd>E</kbd>' + (it.kind === 'door' ? (it.ref.open ? 'Cerrar la puerta' : 'Abrir la puerta') : it.label) : '');
    }
    fpsN++; fpsT += dt;
    if (fpsT > 2) {
      const fps = fpsN / fpsT; $('fps').textContent = fps.toFixed(0) + ' fps · ' + Math.round(scale * 100) + '%';
      if (G.state === 'play' && !G.paused) { if (fps < 27 && G.quality === 'alta') { applyQuality('media'); try { localStorage.removeItem('thelion.quality'); } catch (e) { } } else if (fps < 27 && scale > 0.5) { scale = Math.round((scale - 0.1) * 10) / 10; resize(); } else if (fps > 58 && scale < 0.9) { scale = Math.round((scale + 0.1) * 10) / 10; resize(); } }
      G.fps = fps; fpsN = 0; fpsT = 0;
    }
  }

  // ---------- Bucle ----------
  let last = performance.now(), litF = 1;
  function loop(now) {
    requestAnimationFrame(loop);
    const dt = Math.min(0.05, (now - last) / 1000); last = now;
    tick(dt, now);
    renderer.setRenderTarget(rt); renderer.render(scene, camera);
    renderer.setRenderTarget(null); renderer.render(postScene, postCam);
  }
  function tick(dt, now) {
    const raw = dt, mp = G.mp();
    if (G.paused || G.state === 'clue' || G.state === 'notebook' || G.state === 'inventory') dt = 0;
    const wdt = mp ? raw : dt; // en línea el mundo no se detiene
    P.gun.visible = (G.state === 'play' || G.state === 'dying') && !P.hidden;
    if (G.state !== 'play' && G.state !== 'dying') { P.spot.intensity = 0; P.beam.visible = false; P.lens.visible = false; }
    G.time += wdt;
    const s = G.state;
    if (s === 'title') {
      const a = now / 1000 * 0.05; camera.position.set(Math.sin(a) * 6, 5.5, 34 + Math.cos(a) * 3); camera.lookAt(0, 2, -10);
    } else if (s === 'intro') updateIntro(dt);
    if (s === 'play') { P.update(dt); updateFear(dt); updateBreath(dt); }
    else if (mp && (s === 'clue' || s === 'notebook' || s === 'inventory')) { updateFear(wdt); }
    // el león: lo maneja el juego solo o el anfitrión; el invitado solo lo dibuja
    const sim = mp ? (s !== 'title' && s !== 'ending') : s === 'play';
    G.fx.update(raw);
    if (sim && mp && !G.net.host) G.net.puppet(wdt);
    else if (sim) {
      if (!(s === 'dying' && G.lion.state === 'pounce')) G.lion.update(wdt);
      if (G.pendingHunt && G.time >= G.pendingHunt.t && !G.lion.active()) { G.lion.hunt(G.pendingHunt.b, G.pendingHunt.who); if (G.net) G.net.send({ t: 'hunt' }); G.pendingHunt = null; }
      const pls = G.players(), out = pls.filter(p => !p.hidden && !G.world.buildingAt(p.pos.x, p.pos.z));
      if (!G.lion.active() && !G.pendingHunt && G.time > G.nextAmbient && out.length) {
        G.lion.ambient(); G.nextAmbient = G.time + R(60, 120) * (1 - G.diff() * 0.5) * (mp ? 0.7 : 1);
      }
    }
    if (G.net) G.net.update(raw);
    if (s === 'play') {

      if (P.pos.z < -60.8 && !P.hidden) {
        if (G.found.length >= 3) startEnding();
        else if (G.time > G.riverMsgT) { G.ui.thought('Todavía no entiendo qué pasó aquí. No puedo irme así.'); G.riverMsgT = G.time + 6; }
      }
    }
    if (s === 'struggle') updateStruggle(raw);
    if (s === 'dying') updateDying(dt);
    else if (s === 'ending') { updateEnding(dt); }
    if (G.lion2.state !== 'off') { G.lion2.t += dt; G.lion2.animate(dt); G.lion2.sync(); if (s === 'ending') { const k = 0.6 + Math.sin(G.time * 0.7) * 0.3; G.lion2.m.glowM.opacity = k; G.lion2.m.glows.forEach(g => g.scale.set(0.5, 0.5, 1)); } }
    G.world.update(dt, G.time, camera);
    // la luna sigue al jugador para que sus sombras siempre estén cerca
    const fp = (s === 'title' || s === 'intro') ? camera.position : P.pos;
    moonL.target.position.set(fp.x, 0, fp.z); moonL.position.set(fp.x + MOON_OFF.x, MOON_OFF.y, fp.z + MOON_OFF.z);
    // interiores más oscuros
    const inside = (s === 'play' || s === 'dying') && G.world.buildingAt(P.pos.x, P.pos.z);
    litF += ((P.hidden ? 1.5 : inside ? 0.3 : 1) - litF) * Math.min(1, dt * 2.5); hemi.intensity = 0.45 * litF; moonL.intensity = 0.5 * (inside && G.quality !== 'alta' ? litF : 1);
    if (P.hidden) { const c = P.hidden; closetL.position.set(c.x + c.b.s * 1.3, 2.1, c.z + 0.3); closetL.intensity = 1.1; } else closetL.intensity = 0;
    // postproceso
    G.aberr = Math.max(0, (G.aberr || 0) - dt * 1.2);
    const pu = postMat.uniforms; pu.uTime.value = G.time + now * 0.001;
    pu.uFear.value = (s === 'play' || s === 'dying') ? G.fear / 100 : (s === 'intro' ? 0.35 : 0.15);
    pu.uAberr.value = G.aberr + P.para * 0.4; pu.uRed.value = (s === 'play' && G.fear > 78) ? (G.fear - 78) / 22 * 0.35 * (0.6 + 0.4 * Math.sin(G.time * 7)) : 0;
    if (s === 'play' && G.hp < 35) pu.uRed.value = Math.max(pu.uRed.value, (1 - G.hp / 35) * 0.3 * (0.7 + 0.3 * Math.sin(G.time * 5)));
    if (G.audio.ready) {
      G.audio.update(dt, G.time, s === 'intro' ? (G.introT > 2 ? 0.75 : 0.5) : (s === 'title' ? 0 : G.fear / 100), G.breath.covering, clamp((P.pos.z - 18) / 14, 0, 1), s === 'intro',
        { lion: G.lion.group.visible && G.lion.state !== 'off' ? G.lion.dist(P.pos) : 99, inside: !!G.world.buildingAt(P.pos.x, P.pos.z), exert: s === 'play' ? Math.max(0, 1 - P.stamina / 60) : 0 });
      const f = new T.Vector3(); camera.getWorldDirection(f); G.audio.setListener(camera.position, f);
    }
    if (s === 'play' || s === 'dying' || s === 'struggle') updateHUD(dt, now);
  }
  requestAnimationFrame(loop);

  // ---------- Depuración / pruebas ----------
  window.__lion = {
    G,
    info() { return { state: G.state, paused: G.paused, pos: P.pos.toArray().map(v => +v.toFixed(2)), fear: +G.fear.toFixed(1), found: G.found.slice(), lion: G.lion.state, lionPos: G.lion.pos.toArray().map(v => +v.toFixed(1)), hidden: !!P.hidden, hp: Math.round(G.hp), diff: +G.diff().toFixed(2), breath: { air: +G.breath.air.toFixed(0), noise: +G.breath.noise.toFixed(0) }, theory: Object.assign({}, G.theory), fps: G.fps && +G.fps.toFixed(1), scale }; },
    start() { if (G.state === 'title') startGame(); },
    skipIntro() { beginPlay(); },
    teleport(x, z, y, yaw) { P.pos.set(x, y || 0, z); if (yaw != null) P.yaw = yaw; },
    clue(id) { const it = G.world.interact.find(i => i.id === id); if (it && !it.done) { openClue(it); closeClue(); } },
    hunt(bid) { const b = G.world.buildings.find(b => b.id === bid); G.lion.hunt(b); },
    hideIn(i) { P.hide(G.world.closets[i]); G.breath.air = 100; G.breath.noise = 0; },
    unhide() { if (P.hidden) interact(); },
    key(code, down) { P.keys[code] = !!down; if (down) P.press(code); },
    shoot() { P.press('Fire'); },
    unpause() { G.paused = false; show('pause', false); },
    respawn() { respawn(); },
    sim(sec, each) { const n = Math.round(sec * 60); for (let i = 0; i < n; i++) { tick(1 / 60, performance.now()); if (each) each(i); } return this.info(); },
    ending() { startEnding(); },
    startGame() { startGame(); }
  };
})();
