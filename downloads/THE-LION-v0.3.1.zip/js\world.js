// Mapa del Pueblo 1: pantano (sur) → calle → plaza → granero → río (norte)
(function () {
  const T = THREE;
  function R(a, b) { return a + Math.random() * (b - a); }

  // ---------- Colisiones simples (cajas alineadas) ----------
  TL.collide = {
    resolveCircle(x, z, r, feet, head, cols) {
      for (let it = 0; it < 3; it++) {
        for (let i = 0; i < cols.length; i++) {
          const b = cols[i];
          if (b.maxY <= feet + 0.38 || b.minY >= head) continue;
          const cx = Math.max(b.minX, Math.min(x, b.maxX)), cz = Math.max(b.minZ, Math.min(z, b.maxZ));
          let dx = x - cx, dz = z - cz; const d2 = dx * dx + dz * dz;
          if (d2 >= r * r) continue;
          if (d2 > 1e-8) { const d = Math.sqrt(d2), p = r - d; x += dx / d * p; z += dz / d * p; }
          else {
            const l = x - b.minX, rr = b.maxX - x, n = z - b.minZ, s = b.maxZ - z, m = Math.min(l, rr, n, s);
            if (m === l) x = b.minX - r; else if (m === rr) x = b.maxX + r; else if (m === n) z = b.minZ - r; else z = b.maxZ + r;
          }
        }
      }
      return { x, z };
    },
    // mover en pasitos cortos para no atravesar paredes delgadas cuando baja el FPS
    move(x, z, dx, dz, r, feet, head, cols) {
      const n = Math.max(1, Math.ceil(Math.hypot(dx, dz) / 0.1));
      for (let i = 0; i < n; i++) { const o = this.resolveCircle(x + dx / n, z + dz / n, r, feet, head, cols); x = o.x; z = o.z; }
      return { x, z };
    },
    support(x, z, r, feet, cols) {
      let top = 0;
      for (let i = 0; i < cols.length; i++) {
        const b = cols[i]; if (b.maxY > feet + 0.42 || b.maxY <= top) continue;
        if (x + r * 0.7 < b.minX || x - r * 0.7 > b.maxX || z + r * 0.7 < b.minZ || z - r * 0.7 > b.maxZ) continue;
        top = b.maxY;
      }
      return top;
    },
    segmentBlocked(x1, z1, x2, z2, y, cols) {
      const dx = x2 - x1, dz = z2 - z1;
      for (let i = 0; i < cols.length; i++) {
        const b = cols[i]; if (b.minY > y || b.maxY < y || b.thin) continue;
        let t0 = 0, t1 = 1;
        if (Math.abs(dx) < 1e-9) { if (x1 < b.minX || x1 > b.maxX) continue; }
        else { let a = (b.minX - x1) / dx, c = (b.maxX - x1) / dx; if (a > c) { const s = a; a = c; c = s; } t0 = Math.max(t0, a); t1 = Math.min(t1, c); if (t0 > t1) continue; }
        if (Math.abs(dz) < 1e-9) { if (z1 < b.minZ || z1 > b.maxZ) continue; }
        else { let a = (b.minZ - z1) / dz, c = (b.maxZ - z1) / dz; if (a > c) { const s = a; a = c; c = s; } t0 = Math.max(t0, a); t1 = Math.min(t1, c); if (t0 > t1) continue; }
        if (t0 > 0.02 && t0 < 0.98) return true;
      }
      return false;
    }
  };

  // Une muchas geometrías en una sola (menos llamadas de dibujo = más FPS en la HD 520)
  TL.mergeGeos = function (list) {
    let vc = 0, ic = 0;
    list.forEach(o => { vc += o.geo.attributes.position.count; ic += o.geo.index ? o.geo.index.count : o.geo.attributes.position.count; });
    const pos = new Float32Array(vc * 3), nor = new Float32Array(vc * 3), uv = new Float32Array(vc * 2), idx = new Uint32Array(ic);
    const nm = new T.Matrix3(), v = new T.Vector3(); let vo = 0, io = 0;
    list.forEach(o => {
      const g = o.geo, p = g.attributes.position, n = g.attributes.normal, u = g.attributes.uv; nm.getNormalMatrix(o.matrix);
      for (let i = 0; i < p.count; i++) {
        v.fromBufferAttribute(p, i).applyMatrix4(o.matrix); pos[(vo + i) * 3] = v.x; pos[(vo + i) * 3 + 1] = v.y; pos[(vo + i) * 3 + 2] = v.z;
        if (n) { v.fromBufferAttribute(n, i).applyMatrix3(nm).normalize(); nor[(vo + i) * 3] = v.x; nor[(vo + i) * 3 + 1] = v.y; nor[(vo + i) * 3 + 2] = v.z; }
        if (u) { uv[(vo + i) * 2] = u.getX(i); uv[(vo + i) * 2 + 1] = u.getY(i); }
      }
      if (g.index) { for (let j = 0; j < g.index.count; j++) idx[io + j] = g.index.getX(j) + vo; io += g.index.count; }
      else { for (let j = 0; j < p.count; j++) idx[io + j] = vo + j; io += p.count; }
      vo += p.count;
    });
    const out = new T.BufferGeometry();
    out.setAttribute('position', new T.BufferAttribute(pos, 3)); out.setAttribute('normal', new T.BufferAttribute(nor, 3)); out.setAttribute('uv', new T.BufferAttribute(uv, 2));
    out.setIndex(new T.BufferAttribute(idx, 1)); out.computeBoundingSphere(); return out;
  };

  TL.World = function (scene) {
    const W = this;
    W.colliders = []; W.buildings = []; W.interact = []; W.closets = []; W.updaters = []; W.doors = [];
    const BUMP = { planks: 0.05, plaster: 0.035, mud: 0.07, dirt: 0.05, roof: 0.045, stone: 0.07, hay: 0.05, bark: 0.06 };
    const mats = {};
    function mat(tex, rx, ry, color, extra) {
      const key = tex + '_' + Math.round(rx * 2) + '_' + Math.round(ry * 2) + '_' + (color || 0) + (extra ? JSON.stringify(extra) : '');
      if (!mats[key]) {
        const t = tex ? TL.tex.get(tex, rx, ry) : null;
        mats[key] = new T.MeshPhongMaterial(Object.assign({ map: t, bumpMap: t, bumpScale: BUMP[tex] || 0, color: color || 0xffffff, shininess: 8, specular: 0x0c0c0c }, extra || {}));
      }
      return mats[key];
    }
    function addCol(minX, maxX, minY, maxY, minZ, maxZ, extra) { const c = Object.assign({ minX, maxX, minY, maxY, minZ, maxZ }, extra || {}); W.colliders.push(c); return c; }
    function stat(m) { m.userData.static = true; return m; }
    function box(x, y, z, w, h, d, m, opts) {
      opts = opts || {};
      const mesh = new T.Mesh(new T.BoxGeometry(w, h, d), m); mesh.position.set(x, y + h / 2, z); scene.add(mesh);
      if (!opts.dyn) stat(mesh);
      if (opts.rot) mesh.rotation.set(opts.rot[0], opts.rot[1], opts.rot[2]);
      if (!opts.noCol) mesh.userData.col = addCol(x - w / 2, x + w / 2, y, y + h, z - d / 2, z + d / 2, opts.colExtra);
      return mesh;
    }
    function wallMat(kind, len, h) { return mat(kind, len / 2.5, h / 2.5); }
    W.box = box;

    // ---------- Cielo ----------
    const sky = new T.Mesh(new T.SphereGeometry(140, 32, 16), new T.ShaderMaterial({
      side: T.BackSide, depthWrite: false, fog: false, uniforms: { uTime: { value: 0 } },
      vertexShader: 'varying vec3 vDir; void main(){ vDir = position; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }',
      fragmentShader: [
        'uniform float uTime; varying vec3 vDir;',
        'float h(vec3 p){ return fract(sin(dot(p, vec3(12.9898,78.233,37.719))) * 43758.5453); }',
        'void main(){ vec3 d = normalize(vDir); float y = max(d.y, 0.0);',
        ' vec3 col = mix(vec3(0.039,0.059,0.078), vec3(0.008,0.012,0.028), pow(y, 0.55));',
        ' vec3 q = d * 230.0; vec3 cell = floor(q); float s = h(cell); vec3 f = fract(q) - 0.5;',
        ' float star = step(0.9968, s) * smoothstep(0.42, 0.0, length(f)) * smoothstep(0.06, 0.35, y) * (0.55 + 0.45 * sin(uTime * 1.7 + s * 60.0));',
        ' col += vec3(0.75, 0.8, 0.9) * star;',
        ' vec3 md = normalize(vec3(-40.0, 48.0, -110.0)); float m = max(dot(d, md), 0.0);',
        ' col += vec3(0.30, 0.36, 0.48) * pow(m, 90.0) + vec3(0.07, 0.09, 0.13) * pow(m, 7.0);',
        ' float cl = sin(d.x * 9.0 + uTime * 0.02) * sin(d.z * 7.0 - uTime * 0.015) * 0.5 + 0.5; col = mix(col, col * 0.6 + vec3(0.02,0.025,0.03), smoothstep(0.55, 0.9, cl) * smoothstep(0.05, 0.4, y) * 0.6);',
        ' gl_FragColor = vec4(col, 1.0); }'
      ].join('\n')
    }));
    sky.renderOrder = -10; scene.add(sky); W.sky = sky;
    const moon = new T.Mesh(new T.CircleGeometry(4, 32), new T.MeshBasicMaterial({ color: 0xdfe6f2, fog: false, depthWrite: false }));
    moon.position.set(-40, 48, -110).normalize().multiplyScalar(130); moon.lookAt(0, 0, 0); moon.renderOrder = -9; scene.add(moon);
    const halo = new T.Sprite(new T.SpriteMaterial({ map: TL.tex.glow(), color: 0x8fa4c8, fog: false, transparent: true, opacity: 0.32, blending: T.AdditiveBlending, depthWrite: false }));
    halo.position.copy(moon.position); halo.scale.set(24, 24, 1); halo.renderOrder = -8; scene.add(halo);
    W.skyParts = [sky, moon, halo];
    // bosque lejano (siluetas)
    const tl = TL.tex.treeline();
    for (let i = 0; i < 18; i++) {
      const a = i / 18 * Math.PI * 2, r = 95;
      const m = new T.Mesh(new T.PlaneGeometry(36, 13), new T.MeshBasicMaterial({ map: tl, transparent: true, fog: false, depthWrite: false, color: 0x0b1016 }));
      m.position.set(Math.cos(a) * r, 5.5, -15 + Math.sin(a) * r); m.lookAt(0, 5.5, -15); m.renderOrder = -7;
      m.material.map = tl.clone(); m.material.map.needsUpdate = true; m.material.map.offset.x = Math.random(); m.material.map.repeat.x = 0.35;
      scene.add(m); W.skyParts.push(m);
    }

    // ---------- Suelo ----------
    const ground = stat(new T.Mesh(new T.PlaneGeometry(130, 190, 1, 1), mat('mud', 32, 46, 0xb0a898, { shininess: 26, specular: 0x1e1e1e })));
    ground.rotation.x = -Math.PI / 2; ground.position.set(0, 0, -15); ground.userData.noCast = true; scene.add(ground);
    const street = stat(new T.Mesh(new T.PlaneGeometry(9, 112), mat('dirt', 2, 26, 0xb8b0a0)));
    street.rotation.x = -Math.PI / 2; street.position.set(0, 0.012, -8); street.userData.noCast = true; scene.add(street);
    // calles traseras (x = ±28) y calles que cruzan (z = 4.7 oeste, z = -6 este, z = -31 ambos lados)
    W.streets = [[-4.5, 4.5, -64, 52], [-31, -25, -50, 30], [25, 31, -50, 30], [-48, -4, 2, 7.4], [4, 48, -8.8, -3.2], [-48, 48, -34, -28]];
    W.onStreet = (x, z, m) => W.streets.some(r => x > r[0] - (m || 0) && x < r[1] + (m || 0) && z > r[2] - (m || 0) && z < r[3] + (m || 0));
    W.streets.slice(1).forEach(r => {
      const w = r[1] - r[0], d = r[3] - r[2];
      const m = stat(new T.Mesh(new T.PlaneGeometry(w, d), mat('dirt', Math.max(1, w / 4.5), Math.max(1, d / 4.5), 0xb0a898)));
      m.rotation.x = -Math.PI / 2; m.position.set((r[0] + r[1]) / 2, 0.011, (r[2] + r[3]) / 2); m.userData.noCast = true; scene.add(m);
    });

    // ---------- Agua (pantano, charcos y río) ----------
    const waterMat = new T.MeshPhongMaterial({ color: 0x0b1611, shininess: 120, specular: 0x6a7a70, transparent: true, opacity: 0.93 });
    W.puddles = [];
    function water(x, z, r, y) { const m = stat(new T.Mesh(new T.CircleGeometry(r, 20), waterMat)); m.rotation.x = -Math.PI / 2; m.position.set(x, y || 0.03, z); const k = R(0.6, 1); m.scale.set(1, k, 1); W.puddles.push({ x, z, rx: r, rz: r * k }); m.userData.noCast = true; scene.add(m); }
    [[-12, 34, 6], [-20, 44, 7], [12, 38, 5], [18, 30, 4], [-6, 47, 4], [8, 50, 6], [24, 46, 6], [-26, 30, 4]].forEach(p => water(p[0], p[1], p[2]));
    for (let i = 0; i < 12; i++) water(R(-3.5, 3.5), R(-55, 20), R(0.4, 1.1), 0.02);
    const swamp = stat(new T.Mesh(new T.PlaneGeometry(130, 30), waterMat)); swamp.rotation.x = -Math.PI / 2; swamp.position.set(0, 0.025, 68); swamp.userData.noCast = true; scene.add(swamp);
    // terraplén de tierra que cruza el pantano (por aquí llega la camioneta)
    const road = stat(new T.Mesh(new T.PlaneGeometry(5, 52), mat('dirt', 1.2, 12, 0x9a9282))); road.rotation.x = -Math.PI / 2; road.position.set(0, 0.05, 78); road.userData.noCast = true; scene.add(road);
    const river = new T.Mesh(new T.PlaneGeometry(130, 13), new T.MeshPhongMaterial({ color: 0x0c191b, shininess: 140, specular: 0x7a909a }));
    river.rotation.x = -Math.PI / 2; river.position.set(0, 0.04, -71); river.receiveShadow = true; scene.add(river);
    W.river = river;

    // ---------- Detalles reutilizables ----------
    const beamM = mat('planks', 0.5, 1, 0x6a5848);
    function windowAt(x, y, z, face) { // face: +1 mira a +x, -1 a -x
      const ox = face * 0.17;
      box(x + ox, y - 0.6, z, 0.08, 0.08, 1.1, beamM, { noCol: true }); box(x + ox, y + 0.55, z, 0.08, 0.08, 1.1, beamM, { noCol: true });
      box(x + ox, y - 0.6, z - 0.55, 0.08, 1.2, 0.08, beamM, { noCol: true }); box(x + ox, y - 0.6, z + 0.55, 0.08, 1.2, 0.08, beamM, { noCol: true });
      const g = stat(new T.Mesh(new T.PlaneGeometry(1.0, 1.1), new T.MeshPhongMaterial({ color: 0x05070a, shininess: 90, specular: 0x30363c })));
      g.position.set(x + face * 0.16, y, z); g.rotation.y = face > 0 ? Math.PI / 2 : -Math.PI / 2; scene.add(g);
      const sh = box(x + face * 0.45, y - 0.65, z - 0.85, 0.05, 1.25, 0.55, mat('planks', 0.5, 1, 0x7a6a58), { noCol: true, rot: [0, face * 0.9, R(-0.15, 0.15)] });
    }
    function porch(doorX, z, s) {
      box(doorX + s * 0.75, 2.55, z, 1.5, 0.12, 2.6, mat('roof', 1, 1), { noCol: true });
      box(doorX + s * 1.45, 0, z - 1.2, 0.12, 2.55, 0.12, beamM, { noCol: true }); box(doorX + s * 1.45, 0, z + 1.2, 0.12, 2.55, 0.12, beamM, { noCol: true });
      box(doorX + s * 0.5, 0, z, 1.0, 0.15, 2.4, mat('planks', 1, 1, 0x8a7a68), { noCol: true });
    }

    // ---------- Casas investigables ----------
    function house(o) {
      const s = o.door === 'E' ? 1 : -1, t = 0.3, hw = o.w / 2, hd = o.d / 2;
      const backX = o.x - s * hw, doorX = o.x + s * hw, kind = o.kind || 'planks';
      box(backX, 0, o.z, t, o.h, o.d, wallMat(kind, o.d, o.h));
      box(o.x, 0, o.z - hd, o.w, o.h, t, wallMat(kind, o.w, o.h));
      box(o.x, 0, o.z + hd, o.w, o.h, t, wallMat(kind, o.w, o.h));
      const g = 0.85, seg = hd - g;
      box(doorX, 0, o.z - g - seg / 2, t, o.h, seg, wallMat(kind, seg, o.h));
      box(doorX, 0, o.z + g + seg / 2, t, o.h, seg, wallMat(kind, seg, o.h));
      box(doorX, 2.3, o.z, t, o.h - 2.3, g * 2, wallMat(kind, 2, 1));
      box(o.x, 0.0, o.z, o.w - 0.1, 0.04, o.d - 0.1, mat('planks', o.w / 2, o.d / 2, 0x8a8070), { noCol: true });
      box(o.x, o.h, o.z, o.w + 0.6, 0.3, o.d + 0.6, mat('roof', o.w / 3, o.d / 3));
      // vigas de esquina, marco de puerta, ventanas y porche
      [[-1, -1], [1, -1], [-1, 1], [1, 1]].forEach(k => box(o.x + k[0] * (hw + 0.05), 0, o.z + k[1] * (hd + 0.05), 0.22, o.h, 0.22, beamM, { noCol: true }));
      box(doorX + s * 0.12, 0, o.z - g - 0.06, 0.12, 2.35, 0.12, beamM, { noCol: true }); box(doorX + s * 0.12, 0, o.z + g + 0.06, 0.12, 2.35, 0.12, beamM, { noCol: true });
      if (hd > 2.6) { windowAt(doorX, 1.6, o.z - hd * 0.6, s); windowAt(doorX, 1.6, o.z + hd * 0.6, s); }
      if (o.porch !== false) porch(doorX, o.z, s);
      if (o.peaked) {
        const r = (o.w + 0.6) / 1.732;
        const rf = stat(new T.Mesh(new T.CylinderGeometry(r, r, o.d + 0.6, 3, 1), mat('roof', 2, 2)));
        rf.rotation.x = -Math.PI / 2; rf.scale.set(1, 1, 0.6); rf.position.set(o.x, o.h + 0.3 * r, o.z); scene.add(rf);
      }
      if (o.sign) { const sg = stat(new T.Mesh(new T.PlaneGeometry(2.4, 0.6), new T.MeshLambertMaterial({ map: TL.tex.sign(o.sign) }))); sg.position.set(doorX + s * 0.17, o.h - 0.45, o.z + (hd > 3 ? 0 : 0)); sg.rotation.y = s > 0 ? Math.PI / 2 : -Math.PI / 2; if (o.h - 0.45 < 2.6) sg.position.y = 2.75; scene.add(sg); }
      // puerta con bisagra: se abre y cierra con E (el león la tumba si está cerrada)
      const dpiv = new T.Group(); dpiv.position.set(doorX, 0, o.z - g); scene.add(dpiv);
      const dm = mat('planks', 1, 1, 0x6a5444);
      const leaf = new T.Mesh(new T.BoxGeometry(0.07, 2.25, g * 2 - 0.04), dm); leaf.position.set(0, 1.125, g); dpiv.add(leaf);
      [0.5, 1.7].forEach(y => { const br = new T.Mesh(new T.BoxGeometry(0.09, 0.12, g * 2 - 0.1), mat('planks', 1, 1, 0x4a3a2a)); br.position.set(0, y, g); dpiv.add(br); });
      const knob = new T.Mesh(new T.SphereGeometry(0.035, 6, 5), new T.MeshPhongMaterial({ color: 0x6a5a3a, shininess: 60 })); knob.position.set(s * 0.06, 1.05, g * 2 - 0.18); dpiv.add(knob);
      dpiv.traverse(m => { if (m.isMesh) { m.castShadow = true; m.receiveShadow = true; } });
      const dcol = addCol(doorX - 0.12, doorX + 0.12, 0, 2.3, o.z - g, o.z + g);
      const door = { piv: dpiv, col: dcol, open: false, ang: 0, target: 0, s, x: doorX, z: o.z, colY: 2.3 };
      door.setOpen = function (v, bash) {
        door.open = v; door.target = v ? -s * (bash ? 1.75 : 1.45) : 0;
        door.col.maxY = v ? -10 : door.colY; door.col.minY = v ? -11 : 0;
      };
      W.doors.push(door);
      W.interact.push({ kind: 'door', ref: door, x: doorX, y: 1.2, z: o.z, label: 'Abrir la puerta' });
      W.updaters.push(dt => { door.ang += (door.target - door.ang) * Math.min(1, dt * (door.bashT > 0 ? 14 : 5)); dpiv.rotation.y = door.ang; if (door.bashT > 0) door.bashT -= dt; });
      const b = {
        id: o.id, name: o.name, s, minX: o.x - hw, maxX: o.x + hw, minZ: o.z - hd, maxZ: o.z + hd, hunted: false,
        doorOut: { x: doorX + s * 2.2, z: o.z }, doorIn: { x: doorX - s * 1.4, z: o.z }, pts: []
      };
      b.at = (u, v) => ({ x: backX + s * u, z: o.z + v });
      b.pts = [b.at(o.w * 0.35, -hd * 0.45), b.at(o.w * 0.35, hd * 0.45), b.at(o.w * 0.55, 0)];
      W.buildings.push(b); return b;
    }
    function closet(b, u, v) {
      const p = b.at(u, v), grp = new T.Group();
      const body = new T.Mesh(new T.BoxGeometry(0.7, 2.15, 1.3), mat('planks', 1, 1, 0x5a4636)); body.position.y = 1.075; grp.add(body);
      const top = new T.Mesh(new T.BoxGeometry(0.8, 0.12, 1.42), mat('planks', 1, 1, 0x4a3828)); top.position.y = 2.18; grp.add(top);
      const dm = mat('planks', 1, 1, 0x6e5644), d1 = new T.Mesh(new T.BoxGeometry(0.05, 1.95, 0.62), dm), d2 = d1.clone();
      d1.position.set(b.s * 0.37, 1.05, -0.33); d2.position.set(b.s * 0.37, 1.05, 0.33); grp.add(d1); grp.add(d2);
      const km = new T.MeshPhongMaterial({ color: 0x8a7040, shininess: 60, specular: 0x554433 });
      [-0.06, 0.06].forEach(k => { const kn = new T.Mesh(new T.SphereGeometry(0.03, 6, 4), km); kn.position.set(b.s * 0.41, 1.1, k); grp.add(kn); });
      grp.position.set(p.x, 0, p.z); scene.add(grp); grp.traverse(m => { if (m.isMesh) { m.castShadow = true; m.receiveShadow = true; } });
      const col = addCol(p.x - 0.35, p.x + 0.35, 0, 2.15, p.z - 0.65, p.z + 0.65);
      const c = {
        kind: 'closet', camY: 1.6, b, x: p.x, z: p.z, front: { x: p.x + b.s * 3.3, z: p.z }, hide: { x: p.x + b.s * 0.12, z: p.z }, out: { x: p.x + b.s * 1.1, z: p.z },
        lookYaw: b.s === 1 ? -Math.PI / 2 : Math.PI / 2, destroyed: false, grp, d1, d2, col
      };
      c.destroy = function () {
        c.destroyed = true; d1.rotation.y = 1.3; d1.position.x += b.s * 0.4; d2.rotation.z = 1.4; d2.position.set(b.s * 0.9, 0.2, 0.4);
        body.rotation.z = -b.s * 0.12; body.scale.set(1, 0.9, 1);
      };
      W.closets.push(c);
      W.interact.push({ kind: 'closet', ref: c, x: p.x + b.s * 0.6, y: 1.2, z: c.z, label: 'Esconderte en el armario' });
      return c;
    }
    // cama: puedes meterte debajo (ves los pies del león desde el suelo)
    function bed(b, u, v, withHide) {
      const p = b.at(u, v), grp = new T.Group(), wood = mat('planks', 1, 1, 0x4e3a2a);
      const frame = new T.Mesh(new T.BoxGeometry(2.0, 0.14, 1.1), wood); frame.position.y = 0.42; grp.add(frame);
      const mat2 = new T.Mesh(new T.BoxGeometry(1.9, 0.16, 1.0), new T.MeshPhongMaterial({ color: 0x8a8070, shininess: 4 })); mat2.position.y = 0.57; grp.add(mat2);
      const blanket = new T.Mesh(new T.BoxGeometry(1.3, 0.05, 1.06), new T.MeshPhongMaterial({ color: 0x5a2a22, shininess: 4 })); blanket.position.set(b.s * -0.3, 0.66, 0); blanket.rotation.z = 0.02; grp.add(blanket);
      const pillow = new T.Mesh(new T.BoxGeometry(0.45, 0.1, 0.75), new T.MeshPhongMaterial({ color: 0xb8ae98 })); pillow.position.set(-b.s * 0.7, 0.69, 0); grp.add(pillow);
      [[-1, -1], [1, -1], [-1, 1], [1, 1]].forEach(k => { const l = new T.Mesh(new T.BoxGeometry(0.08, 0.42, 0.08), wood); l.position.set(k[0] * 0.95, 0.21, k[1] * 0.5); grp.add(l); });
      const head = new T.Mesh(new T.BoxGeometry(0.08, 0.75, 1.1), wood); head.position.set(-b.s * 1.0, 0.65, 0); grp.add(head);
      grp.position.set(p.x, 0, p.z); scene.add(grp); grp.traverse(m => { if (m.isMesh) { m.castShadow = true; m.receiveShadow = true; } });
      addCol(p.x - 1.0, p.x + 1.0, 0, 0.72, p.z - 0.55, p.z + 0.55);
      if (!withHide) return { p, grp };
      const side = p.z > b.at(0, 0).z ? -1 : 1; // lado libre del cuarto
      const c = {
        kind: 'bed', camY: 0.26, b, x: p.x, z: p.z, front: { x: p.x, z: p.z + side * 1.6 }, hide: { x: p.x, z: p.z + side * 0.1 }, out: { x: p.x, z: p.z + side * 1.2 },
        lookYaw: side > 0 ? Math.PI : 0, destroyed: false, grp: new T.Group(), col: null
      };
      c.destroy = function () { c.destroyed = true; grp.rotation.x = side * 0.5; grp.position.y = 0.25; grp.position.z = p.z - side * 0.3; };
      W.closets.push(c);
      W.interact.push({ kind: 'closet', ref: c, x: p.x, y: 0.5, z: p.z + side * 0.6, label: 'Meterte debajo de la cama' });
      return { p, grp, c };
    }
    // caja de balas: cartón con tapa abierta y cartuchos
    function ammoBox(x, y, z, rot) {
      const g = new T.Group(), card = new T.MeshPhongMaterial({ color: 0x7a5a36, shininess: 6 });
      const bx = new T.Mesh(new T.BoxGeometry(0.2, 0.09, 0.13), card); bx.position.y = 0.045; g.add(bx);
      const lid = new T.Mesh(new T.BoxGeometry(0.2, 0.012, 0.13), new T.MeshPhongMaterial({ color: 0x8a2a1a, shininess: 6 })); lid.position.set(0, 0.11, -0.1); lid.rotation.x = -1.1; g.add(lid);
      const brass = new T.MeshPhongMaterial({ color: 0xc8a050, shininess: 90, specular: 0x886633 }), tip = new T.MeshPhongMaterial({ color: 0x8a5a3a, shininess: 60 });
      for (let i = 0; i < 5; i++) for (let j = 0; j < 3; j++) { const c = new T.Mesh(new T.CylinderGeometry(0.011, 0.011, 0.05, 6), brass); c.position.set(-0.07 + i * 0.035, 0.1, -0.035 + j * 0.035); g.add(c); const t2 = new T.Mesh(new T.ConeGeometry(0.01, 0.02, 6), tip); t2.position.set(c.position.x, 0.135, c.position.z); g.add(t2); }
      const loose = new T.Mesh(new T.CylinderGeometry(0.011, 0.011, 0.06, 6), brass); loose.rotation.z = Math.PI / 2; loose.position.set(0.16, 0.012, 0.05); g.add(loose);
      g.position.set(x, y, z); g.rotation.y = rot || 0; scene.add(g);
      W.interact.push({ kind: 'ammo', x, y: y + 0.08, z, label: 'Tomar caja de balas', mesh: g });
      return g;
    }
    // objetos para el inventario
    function item(id, x, y, z, rot) {
      const g = new T.Group();
      if (id === 'trapo') {
        const m = new T.MeshLambertMaterial({ color: [0x6a5a4a, 0x5a3a2a, 0x7a7060][Math.floor(Math.random() * 3)], side: T.DoubleSide });
        const a = new T.Mesh(new T.PlaneGeometry(0.42, 0.3, 4, 3), m); a.rotation.x = -Math.PI / 2; const pa = a.geometry.attributes.position; for (let i = 0; i < pa.count; i++) pa.setZ(i, Math.random() * 0.04); a.geometry.computeVertexNormals(); a.position.y = 0.01; g.add(a);
        const fold = new T.Mesh(new T.BoxGeometry(0.2, 0.05, 0.14), m); fold.position.set(0.05, 0.03, 0); g.add(fold);
      } else if (id === 'cinta') {
        const cb = new T.Mesh(new T.BoxGeometry(0.22, 0.14, 0.16), new T.MeshLambertMaterial({ color: 0x8a6a42 })); cb.position.y = 0.07; g.add(cb);
        const roll = new T.Mesh(new T.TorusGeometry(0.05, 0.022, 6, 12), new T.MeshPhongMaterial({ color: 0x9a9a8a, shininess: 30 })); roll.position.set(0, 0.17, 0); roll.rotation.x = Math.PI / 2; g.add(roll);
      }
      g.position.set(x, y, z); g.rotation.y = rot || R(0, 6); scene.add(g);
      W.interact.push({ kind: 'item', item: id, x, y: y + 0.1, z, label: id === 'trapo' ? 'Tomar trapos' : 'Tomar caja con cinta', mesh: g });
      return g;
    }
    function table(x, z, w, d) {
      const m = mat('planks', 1, 1, 0x6a5040);
      box(x, 0.75, z, w, 0.07, d, m, { noCol: true });
      [[-1, -1], [1, -1], [-1, 1], [1, 1]].forEach(k => box(x + k[0] * (w / 2 - 0.06), 0, z + k[1] * (d / 2 - 0.06), 0.07, 0.75, 0.07, m, { noCol: true }));
      addCol(x - w / 2, x + w / 2, 0, 0.82, z - d / 2, z + d / 2);
    }
    function chair(x, z, rot) {
      const m = mat('planks', 1, 1, 0x5a4232);
      box(x, 0.45, z, 0.45, 0.05, 0.45, m, { noCol: true, rot: [0, rot, 0] });
      box(x - Math.sin(rot) * 0.2, 0.45, z - Math.cos(rot) * 0.2, 0.45, 0.5, 0.05, m, { noCol: true, rot: [0, rot, 0] });
      [[-1, -1], [1, -1], [-1, 1], [1, 1]].forEach(k => box(x + k[0] * 0.19, 0, z + k[1] * 0.19, 0.04, 0.45, 0.04, m, { noCol: true }));
    }
    function crate(x, y, z, s) { return box(x, y, z, s || 1.1, s || 1.1, s || 1.1, mat('planks', 1, 1, 0x9a8060)); }
    function clueMesh(id, mesh, x, y, z, label) { W.interact.push({ kind: 'clue', id, x, y, z, label: label || 'Examinar', mesh }); }
    function artPlane(id, w, h) { return new T.Mesh(new T.PlaneGeometry(w, h), new T.MeshLambertMaterial({ map: TL.tex.canvas(TL.art(id)) })); }

    // A — Casa del cazador (oeste)
    const A = house({ id: 'A', name: 'Casa del cazador', x: -14, z: -4, w: 8, d: 10, h: 3.2, door: 'E' });
    closet(A, 0.5, -3);
    let p = A.at(4.2, 1.8); table(p.x, p.z, 1.4, 0.9); chair(p.x - 1.0, p.z + 0.2, Math.PI / 2 + 0.4);
    // la foto está tirada y medio escondida debajo de la cama
    const bedA = bed(A, 4.6, -4.25, true);
    { const q = A.at(4.0, -3.55); const foto = artPlane('foto', 0.3, 0.21); foto.rotation.x = -Math.PI / 2; foto.rotation.z = 0.7; foto.position.set(q.x, 0.015, q.z); scene.add(foto); clueMesh('foto', foto, q.x, 0.1, q.z, 'Algo debajo de la cama'); }
    const lamp = new T.Mesh(new T.CylinderGeometry(0.06, 0.09, 0.22, 8), new T.MeshPhongMaterial({ color: 0x3a3020, shininess: 50 })); lamp.position.set(p.x + 0.45, 0.9, p.z - 0.25); stat(lamp); scene.add(lamp);
    p = A.at(0.4, 3.6); box(p.x, 1.1, p.z, 0.4, 0.06, 1.6, mat('planks', 1, 1), { noCol: true });
    ammoBox(p.x, 1.13, p.z, 0.3);
    // vendas (curan vida)
    function bandage(x, y, z) {
      const g = new T.Group(); const wm = new T.MeshLambertMaterial({ color: 0xd8d0b8 });
      const r1 = new T.Mesh(new T.CylinderGeometry(0.06, 0.06, 0.09, 10), wm); r1.rotation.z = Math.PI / 2; g.add(r1);
      const r2 = r1.clone(); r2.position.set(0.02, 0, 0.13); r2.rotation.y = 0.6; g.add(r2);
      const st = new T.Mesh(new T.PlaneGeometry(0.08, 0.035), new T.MeshBasicMaterial({ color: 0x8a1a12 })); st.rotation.x = -Math.PI / 2; st.position.set(0, 0.062, 0); g.add(st);
      g.position.set(x, y + 0.06, z); scene.add(g);
      W.interact.push({ kind: 'heal', x, y: y + 0.1, z, label: 'Tomar vendas', mesh: g });
    }
    W.bandage = bandage;
    p = A.at(0.2, -0.5); for (let i = 0; i < 3; i++) box(p.x, 1.2 + i * 0.01, p.z - 0.4 + i * 0.4, 0.05, 1.1, 0.06, mat(null, 1, 1, 0x3a2a1a), { noCol: true });
    p = A.at(0.2, 0.6); const skin = stat(new T.Mesh(new T.PlaneGeometry(1.2, 0.9), new T.MeshLambertMaterial({ color: 0x5a4028, side: T.DoubleSide }))); skin.position.set(p.x, 1.7, p.z); skin.rotation.y = Math.PI / 2; scene.add(skin);
    crate(A.at(8.8, -3.6).x, 0, A.at(8.8, -3.6).z);
    p = A.at(0.4, 3.6); bandage(p.x, 1.13, p.z + 0.5);
    { const q = A.at(6.8, 4.3); item('trapo', q.x, 0.02, q.z); }

    // B — Casa de la niña (este)
    const B = house({ id: 'B', name: 'Casa de la niña', x: 14, z: -20, w: 8, d: 10, h: 3.2, door: 'W', kind: 'plaster' });
    closet(B, 0.5, 3);
    p = B.at(1.3, -3.4); bed(B, 1.3, -3.4, true);
    const pil = artPlane('pelo', 0.4, 0.28); pil.rotation.x = -Math.PI / 2; pil.position.set(p.x - B.s * 0.7, 0.75, p.z); scene.add(pil);
    clueMesh('pelo', pil, p.x - B.s * 0.7, 0.75, p.z, 'Mirar la almohada');
    // el dibujo se cayó entre la cama y la pared
    { const q = B.at(2.55, -4.5); const dib = artPlane('dibujo', 0.5, 0.35); dib.rotation.x = -Math.PI / 2 + 0.25; dib.rotation.z = -0.4; dib.position.set(q.x, 0.03, q.z); scene.add(dib); clueMesh('dibujo', dib, q.x, 0.15, q.z, 'Un papel en el piso'); }
    { const q = B.at(6.5, 4.2); item('trapo', q.x, 0.02, q.z); }
    p = B.at(5.5, 2.5); table(p.x, p.z, 1.0, 0.8); chair(p.x, p.z - 0.8, 0);
    const doll = new T.Group(); const dm = new T.MeshLambertMaterial({ color: 0x9a6a5a }); const dh = new T.Mesh(new T.SphereGeometry(0.06, 6, 5), dm); dh.position.y = 0.15; doll.add(dh); const db = new T.Mesh(new T.ConeGeometry(0.07, 0.16, 6), new T.MeshLambertMaterial({ color: 0x6a2020 })); db.position.y = 0.06; doll.add(db); doll.position.set(p.x, 0.79, p.z); doll.rotation.z = 1.3; scene.add(doll);
    crate(B.at(8.8, 3.6).x, 0, B.at(8.8, 3.6).z);
    p = B.at(5.5, 2.5); bandage(p.x + 0.3, 0.78, p.z - 0.2);
    // farol colgado en el porche de la niña
    const lant = new T.Mesh(new T.BoxGeometry(0.16, 0.24, 0.16), new T.MeshBasicMaterial({ color: 0xffb060 })); lant.position.set(9.0, 2.25, -18.6); scene.add(lant);
    const lantL = new T.PointLight(0xff9a40, 0.9, 10, 1.8); lantL.position.set(9.0, 2.1, -18.6); scene.add(lantL);
    W.updaters.push((dt, t) => { const f = 0.75 + Math.sin(t * 17) * 0.08 + (Math.random() < 0.02 ? -0.5 : 0); lantL.intensity = Math.max(0.1, f); lant.material.color.setScalar(0.6 + f * 0.4).multiply(new T.Color(1, 0.7, 0.4)); });

    // C — Granero (oeste, al norte)
    const C = house({ id: 'C', name: 'Granero', x: -14, z: -42, w: 10, d: 12, h: 4.0, door: 'E' });
    closet(C, 0.5, 0);
    p = C.at(4, -4); const trap = new T.Group();
    const rm = new T.MeshPhongMaterial({ color: 0x5a3a22, shininess: 40, specular: 0x443322 });
    const j1 = new T.Mesh(new T.TorusGeometry(0.32, 0.035, 6, 16, Math.PI), rm); j1.rotation.x = -0.4; trap.add(j1);
    const j2 = j1.clone(); j2.rotation.x = Math.PI + 0.4; trap.add(j2);
    const plate = new T.Mesh(new T.BoxGeometry(0.3, 0.03, 0.2), rm); trap.add(plate);
    const chain = new T.Mesh(new T.CylinderGeometry(0.015, 0.015, 0.9, 4), rm); chain.rotation.z = Math.PI / 2; chain.position.set(0.6, 0, 0); trap.add(chain);
    const hair = new T.Mesh(new T.SphereGeometry(0.08, 5, 4), new T.MeshLambertMaterial({ color: 0x241a12 })); hair.position.set(0.1, 0.05, 0.1); hair.scale.set(1.6, 0.5, 1); trap.add(hair);
    trap.position.set(p.x, 0.06, p.z); scene.add(trap);
    clueMesh('trampa', trap, p.x, 0.2, p.z);
    p = C.at(1.0, 4.2); crate(p.x, 0, p.z, 0.9);
    { const q = C.at(7, -5); bandage(q.x, 0.9, q.z); }
    item('cinta', p.x, 0.9, p.z, 0.4);
    { const q = C.at(10.8, 4.5); const book = new T.Mesh(new T.BoxGeometry(0.26, 0.04, 0.2), new T.MeshLambertMaterial({ color: 0x3a2018 })); book.position.set(q.x, 2.22, q.z); scene.add(book);
      const pg = artPlane('diario', 0.24, 0.16); pg.rotation.x = -Math.PI / 2; pg.position.set(q.x, 2.245, q.z); scene.add(pg); clueMesh('diario', book, q.x, 2.25, q.z, 'Un cuaderno allá arriba'); }
    { const q = C.at(4.5, 5.2); ammoBox(q.x, 0, q.z, 1.2); const r2 = C.at(8.2, 1.5); item('trapo', r2.x, 0.02, r2.z); }
    for (let i = 0; i < 4; i++) { const q = C.at(7 + (i % 2) * 1.3, -5 + Math.floor(i / 2) * 1.2); box(q.x, 0, q.z, 1.2, 0.9, 1.1, mat('hay', 1, 1)); }
    crate(C.at(10.8, 4.5).x, 0, C.at(10.8, 4.5).z); crate(C.at(10.8, 4.5).x, 1.1, C.at(10.8, 4.5).z); crate(C.at(10.8, 3.3).x, 0, C.at(10.8, 3.3).z);
    for (let i = 0; i < 7; i++) box(-6.5, 0, -48 - i * 1.4, 0.15, 1.3, 0.15, mat('bark', 1, 1), { noCol: true });
    box(-6.5, 1.0, -52.2, 0.08, 0.08, 8.5, mat('bark', 1, 1), { noCol: true }); box(-6.5, 0.45, -52.2, 0.08, 0.08, 8.5, mat('bark', 1, 1), { noCol: true });

    // ---------- Edificios cerrados (decorado sólido) ----------
    let solidN = 0;
    const loot = ['vendas', 'trapo', 'ammo', null, 'trapo', 'vendas', null, 'ammo', 'trapo', null, 'vendas', null, 'trapo', null];
    function solid(x, z, w, d, h, peaked, kind, sign) {
      const i = solidN++, small = w < 6;
      const b = house({ id: 'S' + i, name: sign ? sign.charAt(0) + sign.slice(1).toLowerCase() : 'Casa', x, z, w, d, h, door: x < 0 ? 'E' : 'W', kind: kind || 'planks', peaked, sign, porch: !small });
      // muebles
      if (small) { const q = b.at(0.9, d / 2 - 0.9); crate(q.x, 0, q.z, 0.8); }
      else {
        let q = b.at(w * 0.55, d * 0.22); table(q.x, q.z, 1.2, 0.8); chair(q.x - 0.8, q.z, Math.PI / 2);
        if (d >= 8 && i % 2 === 0) bed(b, Math.min(w - 2.4, 3.2), -(d / 2 - 0.75), true); else if (d >= 8) bed(b, Math.min(w - 2.4, 3.2), -(d / 2 - 0.75), false);
        if (i % 3 !== 1) closet(b, 0.5, d / 2 - 1.3);
        q = b.at(0.4, -0.4); box(q.x, 1.1, q.z, 0.35, 0.05, 1.3, mat('planks', 1, 1), { noCol: true }); // repisa
      }
      const it = loot[i % loot.length];
      if (it) { const q = small ? b.at(0.9, d / 2 - 0.9) : b.at(0.4, -0.4), y = small ? 0.8 : 1.13;
        if (it === 'ammo') ammoBox(q.x, y, q.z, 0.3); else if (it === 'vendas') bandage(q.x, y, q.z); else item('trapo', q.x, y, q.z); }
      return b;
    }
    solid(-14, 13, 8, 9, 3.6, true, null, 'CANTINA');
    solid(14, 8, 8, 10, 3.4, false, 'plaster', 'ALMACÉN'); crate(9.4, 0, 4.0); item('trapo', 9.5, 1.1, 4.0);
    solid(15, 26, 7, 8, 3.3, true);
    solid(-15, -22, 7, 8, 3.2, false, 'stone'); crate(-11, 0, -19); ammoBox(-11.1, 1.1, -19.1, 0.5);
    solid(14, -44, 9, 10, 3.6, true, 'plaster', 'CAPILLA');
    // ---- barrio oeste (calle trasera x = -28) ----
    const D = house({ id: 'D', name: 'Casa de los Ferrán', x: -38, z: -15, w: 8, d: 10, h: 3.3, door: 'E', kind: 'planks' });
    closet(D, 0.5, 3); bed(D, 4.6, -4.25, true);
    { let q = D.at(4.0, 1.5); table(q.x, q.z, 1.4, 0.9); chair(q.x - 1.0, q.z, Math.PI / 2);
      const bk = new T.Mesh(new T.BoxGeometry(0.3, 0.05, 0.22), new T.MeshLambertMaterial({ color: 0x4a1a12 })); bk.position.set(q.x - 0.2, 0.8, q.z + 0.1); bk.rotation.y = 0.4; scene.add(bk);
      clueMesh('libro', bk, q.x - 0.2, 0.82, q.z + 0.1, 'Abrir el libro');
      q = D.at(0.4, -1.5); box(q.x, 1.0, q.z, 0.4, 0.06, 1.4, mat('planks', 1, 1), { noCol: true }); ammoBox(q.x, 1.03, q.z - 0.3, 0.2);
      for (let i = 0; i < 3; i++) box(q.x + 0.05, 1.3 + i * 0.3, q.z + 0.9, 0.03, 0.03, 0.8, mat(null, 1, 1, 0x3a3a3a), { noCol: true }); // cadenas colgadas
      q = D.at(6.8, 4.2); item('trapo', q.x, 0.02, q.z); }
    solid(-38, 15, 8, 8, 3.2, false, 'stone');
    solid(-38, 27, 8, 8, 3.4, true, 'planks');
    solid(-38, -44, 8, 10, 3.2, true, 'plaster');
    // ---- barrio este (calle trasera x = 28) ----
    const E = house({ id: 'E', name: 'Casa del herrero', x: 38, z: -42, w: 8, d: 10, h: 3.3, door: 'W', kind: 'stone' });
    closet(E, 0.5, -3); bed(E, 4.6, 4.25, true);
    { let q = E.at(2.2, -1.2); box(q.x, 0, q.z, 1.0, 0.8, 0.7, mat('stone', 1, 1)); // yunque/mesón
      const col = new T.Mesh(new T.TorusGeometry(0.12, 0.03, 6, 14), new T.MeshPhongMaterial({ color: 0x5a3a1e, shininess: 10 })); col.rotation.x = Math.PI / 2; col.position.set(q.x, 0.83, q.z); scene.add(col);
      clueMesh('collar', col, q.x, 0.85, q.z, 'Examinar');
      q = E.at(6.5, -4.2); bandage(q.x, 0.02, q.z); q = E.at(0.8, 3.5); item('trapo', q.x, 0.02, q.z); }
    solid(38, -14, 8, 10, 3.6, false, 'plaster', 'HOTEL');
    solid(38, 6, 8, 9, 3.3, true, 'planks');
    solid(38, 22, 7, 8, 3.2, false, 'stone');
    crate(33.5, 0, -20); crate(33.5, 1.1, -20); crate(33.5, 0, -21.2);
    solid(-22.2, -12, 3.6, 5, 2.7, true); solid(21.8, -55, 4.6, 5, 2.7, true); solid(-22, 14, 3.6, 4.2, 2.6, false);

    // ---------- Plaza: cartel, carreta y barril con fuego ----------
    box(-5.4, 0, -12.2, 0.15, 2.2, 0.15, mat('bark', 1, 1)); box(-5.4, 0, -10.0, 0.15, 2.2, 0.15, mat('bark', 1, 1));
    box(-5.4, 1.0, -11.1, 0.1, 1.1, 2.4, mat('planks', 1, 1), { noCol: true }); box(-5.4, 2.2, -11.1, 0.5, 0.08, 2.7, mat('roof', 1, 1), { noCol: true });
    const cart = artPlane('cartel', 0.95, 0.66); cart.rotation.y = Math.PI / 2; cart.position.set(-5.33, 1.55, -11.1); scene.add(cart);
    clueMesh('cartel', cart, -5.1, 1.55, -11.1, 'Leer');
    // carreta rota
    box(-7.6, 0.45, -16.5, 1.6, 0.12, 2.6, mat('planks', 1, 1, 0x7a6450), { rot: [0, 0.3, 0.12] });
    addCol(-8.6, -6.6, 0, 1.0, -17.9, -15.1);
    const wm = mat('planks', 1, 1, 0x4a3a2a);
    [[-6.75, -15.9, 0], [-8.45, -16.5, 0.6]].forEach(w => { const wh = stat(new T.Mesh(new T.TorusGeometry(0.42, 0.06, 6, 14), wm)); wh.position.set(w[0], 0.42, w[1]); wh.rotation.set(w[2], Math.PI / 2 + 0.3, 0); scene.add(wh); });
    const barrel = stat(new T.Mesh(new T.CylinderGeometry(0.4, 0.4, 0.95, 12), mat('planks', 1, 1, 0x3a2a1c))); barrel.position.set(5.6, 0.47, -9.5); scene.add(barrel);
    addCol(5.2, 6.0, 0, 0.95, -9.9, -9.1);
    const fireL = new T.PointLight(0xff7a2a, 1.6, 15, 1.6); fireL.position.set(5.6, 1.4, -9.5); scene.add(fireL);
    const flame = new T.Mesh(new T.ConeGeometry(0.28, 0.6, 8), new T.MeshBasicMaterial({ color: 0xffa040, transparent: true, opacity: 0.85 })); flame.position.set(5.6, 1.2, -9.5); scene.add(flame);
    const fglow = new T.Sprite(new T.SpriteMaterial({ map: TL.tex.glow(), color: 0xff8a30, transparent: true, opacity: 0.7, blending: T.AdditiveBlending, depthWrite: false })); fglow.position.set(5.6, 1.3, -9.5); fglow.scale.set(2.6, 2.6, 1); scene.add(fglow);
    const NE = 40, eg = new T.BufferGeometry(), ep = new Float32Array(NE * 3), es = [];
    for (let i = 0; i < NE; i++) es.push({ y: Math.random() * 3, x: R(-0.2, 0.2), z: R(-0.2, 0.2), v: R(0.5, 1.2) });
    eg.setAttribute('position', new T.BufferAttribute(ep, 3));
    const embers = new T.Points(eg, new T.PointsMaterial({ color: 0xffa050, size: 0.05, transparent: true, blending: T.AdditiveBlending, depthWrite: false })); scene.add(embers);
    W.updaters.push((dt, t) => {
      const f = 1.3 + Math.sin(t * 13) * 0.2 + Math.sin(t * 7.3) * 0.25 + Math.random() * 0.15; fireL.intensity = f; flame.scale.set(1, 0.8 + Math.random() * 0.4, 1); fglow.material.opacity = 0.45 + f * 0.15;
      for (let i = 0; i < NE; i++) { const e = es[i]; e.y += e.v * dt; e.x += Math.sin(t * 3 + i) * dt * 0.2; if (e.y > 3.5) { e.y = 0; e.x = R(-0.2, 0.2); } ep[i * 3] = 5.6 + e.x; ep[i * 3 + 1] = 1.1 + e.y; ep[i * 3 + 2] = -9.5 + e.z; }
      eg.attributes.position.needsUpdate = true;
    });

    // ---------- Huellas (pista exterior) + mancha de la intro ----------
    const dec = new T.Mesh(new T.PlaneGeometry(4, 2), new T.MeshLambertMaterial({ map: TL.tex.canvas(TL.art('huellasDecal')), transparent: true, depthWrite: false }));
    dec.rotation.x = -Math.PI / 2; dec.rotation.z = 0.6; dec.position.set(5.5, 0.03, 26); scene.add(dec);
    clueMesh('huellas', dec, 5.5, 0.3, 26);
    const blood = new T.Mesh(new T.CircleGeometry(0.9, 14), new T.MeshPhongMaterial({ color: 0x2a0606, transparent: true, opacity: 0.85, depthWrite: false, shininess: 80, specular: 0x331111 }));
    blood.rotation.x = -Math.PI / 2; blood.position.set(-6.5, 0.031, 33.5); blood.visible = false; scene.add(blood); W.blood = blood;
    const scarf = new T.Mesh(new T.PlaneGeometry(0.6, 0.25), new T.MeshLambertMaterial({ color: 0x7a1a1a, side: T.DoubleSide })); scarf.position.set(-7.4, 0.5, 34.2); scarf.rotation.set(0.3, 0.8, 0.4); scarf.visible = false; scene.add(scarf); W.scarf = scarf;

    // ---------- Árboles muertos, juncos, pasto, piedras, cercas ----------
    const barkM = mat('bark', 1, 2);
    function branch(parent, len, rad, depth) {
      const br = new T.Mesh(new T.CylinderGeometry(rad * 0.6, rad, len, 5), barkM); br.position.y = len / 2; stat(br);
      const piv = new T.Group(); piv.add(br); parent.add(piv);
      if (depth > 0) for (let i = 0; i < 2; i++) { const c = new T.Group(); c.position.y = len * R(0.6, 1); c.rotation.set(R(-0.9, 0.9), R(0, 6.3), R(-0.9, 0.9)); piv.add(c); branch(c, len * R(0.5, 0.7), rad * 0.6, depth - 1); }
      return piv;
    }
    function tree(x, z, h) {
      const g = new T.Group(); const tr = stat(new T.Mesh(new T.CylinderGeometry(0.14, 0.34, h, 7), barkM)); tr.position.y = h / 2; g.add(tr);
      for (let i = 0; i < 4; i++) { const c = new T.Group(); c.position.y = h * R(0.45, 0.9); c.rotation.set(R(0.5, 1.1) * (Math.random() < .5 ? 1 : -1), R(0, 6.3), R(-0.3, 0.3)); g.add(c); branch(c, R(1.2, 2.2), 0.09, 1); }
      g.position.set(x, 0, z); g.rotation.y = R(0, 6); scene.add(g); addCol(x - 0.28, x + 0.28, 0, h, z - 0.28, z + 0.28, { thin: true });
    }
    [[-9, 26], [10, 18], [-20, 18], [22, 12], [-26, -16], [27, -6], [-22, -30], [24, -24], [-27, -52], [26, -52], [9, -56], [-10, -58], [20, 38], [-28, 40], [28, 30], [-4, 42], [16, -8], [-20, 6]]
      .concat([[-44, 18], [44, -22], [-44, -40], [40, 30], [-20, -40], [44, 0]])
      .filter(t => !W.onStreet(t[0], t[1], 1.5)).forEach(t => tree(t[0], t[1], R(4, 7)));
    function inst(geo, m, n, place) {
      const im = new T.InstancedMesh(geo, m, n), m4 = new T.Matrix4(), q = new T.Quaternion(), e = new T.Euler(), sc = new T.Vector3(), ps = new T.Vector3();
      for (let i = 0; i < n; i++) { place(ps, e, sc); q.setFromEuler(e); m4.compose(ps, q, sc); im.setMatrixAt(i, m4); }
      im.receiveShadow = true; scene.add(im); return im;
    }
    inst(new T.ConeGeometry(0.04, 1.4, 3), new T.MeshLambertMaterial({ color: 0x3a4424 }), 600, (ps, e, sc) => {
      let x = R(-40, 40), z = R(28, 56); if (Math.abs(x) < 3.5 && z < 46) x += x < 0 ? -4 : 4; const k = R(0.6, 1.4);
      ps.set(x, 0.7 * k, z); e.set(R(-.2, .2), 0, R(-.2, .2)); sc.set(k, k, k);
    });
    const inBuilding = (x, z) => W.colliders.some(b => !b.thin && b.maxY > 0.5 && x > b.minX - 0.3 && x < b.maxX + 0.3 && z > b.minZ - 0.3 && z < b.maxZ + 0.3);
    inst(new T.ConeGeometry(0.06, 0.45, 3), new T.MeshLambertMaterial({ color: 0x4a4628 }), 2200, (ps, e, sc) => {
      let x, z, n = 0; do { x = R(-48, 48); z = R(-62, 30); n++; } while ((W.onStreet(x, z, 0.3) || inBuilding(x, z)) && n < 20);
      const k = R(0.5, 1.3); ps.set(x, 0.2 * k, z); e.set(R(-.35, .35), R(0, 6), R(-.35, .35)); sc.set(k, k, k);
    });
    inst(new T.DodecahedronGeometry(0.22, 0), new T.MeshLambertMaterial({ color: 0x3e3a34 }), 160, (ps, e, sc) => {
      let x, z, n = 0; do { x = R(-48, 48); z = R(-62, 50); n++; } while ((W.onStreet(x, z, 0.3) || inBuilding(x, z)) && n < 20); const k = R(0.4, 1.6); ps.set(x, 0.05, z); e.set(R(0, 3), R(0, 3), R(0, 3)); sc.set(k, k * 0.6, k);
    });
    const postM = mat('bark', 1, 1);
    for (let z = 50; z > -64; z -= 3) { if (true) { box(-49, 0, z, 0.14, 1.2, 0.14, postM, { noCol: true, rot: [R(-.1, .1), 0, R(-.1, .1)] }); box(49, 0, z, 0.14, 1.2, 0.14, postM, { noCol: true, rot: [R(-.1, .1), 0, R(-.1, .1)] }); if (Math.random() < 0.7) { box(-49, 0.8, z - 1.5, 0.06, 0.1, 3, postM, { noCol: true }); box(49, 0.8, z - 1.5, 0.06, 0.1, 3, postM, { noCol: true }); } continue; } box(-31, 0, z, 0.14, 1.2, 0.14, postM, { noCol: true, rot: [R(-.1, .1), 0, R(-.1, .1)] }); box(31, 0, z, 0.14, 1.2, 0.14, postM, { noCol: true, rot: [R(-.1, .1), 0, R(-.1, .1)] }); if (Math.random() < 0.7) { box(-31, 0.8, z - 1.5, 0.06, 0.1, 3, postM, { noCol: true }); box(31, 0.8, z - 1.5, 0.06, 0.1, 3, postM, { noCol: true }); } }

    // límites invisibles
    addCol(-53, -49.5, 0, 20, -70, 60); addCol(49.5, 53, 0, 20, -70, 60);
    addCol(-55, 55, 0, 20, 52, 56, { thin: true }); addCol(-55, 55, 0, 20, -66, -63.2, { thin: true });

    // ---------- Puente roto y pueblo 2 (silueta, v0.2) ----------
    box(-1.2, 0, -64.5, 0.25, 1.6, 0.25, postM, { noCol: true }); box(1.2, 0, -64.5, 0.25, 1.6, 0.25, postM, { noCol: true });
    for (let i = 0; i < 4; i++) box(R(-0.2, 0.2), 0.26 - i * 0.05, -65.2 - i * 0.6, 2.6, 0.08, 0.35, mat('planks', 1, 1), { noCol: true, rot: [R(-.15, .15), R(-.2, .2), R(-.1, .1)] });
    for (let i = 0; i < 3; i++) box(0, 0.21, -77 + i * 0.6, 2.6, 0.08, 0.35, mat('planks', 1, 1), { noCol: true, rot: [0, 0, R(-.2, .2)] });
    // al otro lado del río no se ve nada: muro de niebla espesa
    const fogT = TL.tex.mist();
    [[-70, 0.45], [-73.5, 0.65], [-77, 0.85], [-81, 1]].forEach((f, i) => {
      const m = new T.Mesh(new T.PlaneGeometry(150, 9), new T.MeshBasicMaterial({ map: fogT, color: 0x1e2630, transparent: true, opacity: f[1] * 0.8, depthWrite: false }));
      m.position.set(0, 3.2, f[0]); m.renderOrder = 3; scene.add(m);
      const t = m.material.map = fogT.clone(); t.needsUpdate = true; t.wrapS = t.wrapT = T.RepeatWrapping; t.repeat.set(3, 1);
      W.updaters.push(dt => { t.offset.x += dt * (0.004 + i * 0.002); });
    });
    // (sin telón negro: se veía como un cuadrado en el cielo)

    // ---------- Postes de luz en la calle (pocas luces reales que se reparten entre los postes cercanos) ----------
    W.lamps = [];
    const poleM = mat('bark', 1, 2, 0x3a3028), metalM = new T.MeshPhongMaterial({ color: 0x23221f, shininess: 40 });
    const bulbM = new T.MeshBasicMaterial({ color: 0xffc070, fog: false }), offBulb = new T.MeshBasicMaterial({ color: 0x2a241c });
    function streetLamp(x, z, side, broken) {
      const g = new T.Group();
      const pole = new T.Mesh(new T.CylinderGeometry(0.07, 0.11, 4.4, 7), poleM); pole.position.y = 2.2; g.add(pole);
      const arm = new T.Mesh(new T.BoxGeometry(0.9, 0.06, 0.06), poleM); arm.position.set(-side * 0.42, 4.2, 0); g.add(arm);
      const brace = new T.Mesh(new T.BoxGeometry(0.6, 0.04, 0.04), poleM); brace.position.set(-side * 0.25, 3.95, 0); brace.rotation.z = side * 0.6; g.add(brace);
      const hood = new T.Mesh(new T.ConeGeometry(0.26, 0.2, 10, 1, true), metalM); hood.position.set(-side * 0.85, 4.08, 0); g.add(hood);
      const bulb = new T.Mesh(new T.SphereGeometry(0.075, 8, 6), broken ? offBulb : bulbM); bulb.position.set(-side * 0.85, 3.98, 0); g.add(bulb);
      let glow = null;
      if (!broken) { glow = new T.Sprite(new T.SpriteMaterial({ map: TL.tex.glow(), color: 0xffb060, transparent: true, opacity: 0.7, blending: T.AdditiveBlending, depthWrite: false, fog: false })); glow.position.copy(bulb.position); glow.scale.set(1.6, 1.6, 1); g.add(glow); }
      g.position.set(x, 0, z); scene.add(g); g.traverse(m => { if (m.isMesh) m.castShadow = true; });
      addCol(x - 0.12, x + 0.12, 0, 4.4, z - 0.12, z + 0.12, { thin: true });
      const L = { x: x - side * 0.85, y: 3.9, z, broken, glow, bulb, f: Math.random() * 10, flick: Math.random() < 0.3 };
      if (!broken) W.lamps.push(L); return L;
    }
    [[4.7, 30, 1, 0], [-4.7, 18, -1, 0], [4.7, 6, 1, 1], [-4.7, -6, -1, 0], [4.7, -18, 1, 0], [-4.7, -30, -1, 1], [4.7, -42, 1, 0], [-4.7, -53, -1, 0]]
      .concat([[-24.7, 12, -1, 0], [-24.7, -18, -1, 1], [-24.7, -44, -1, 0], [24.7, 16, 1, 0], [24.7, -18, 1, 0], [24.7, -44, 1, 1], [16, -27.7, 1, 0], [-16, -27.7, -1, 0], [38, -27.7, 1, 0], [-38, -27.7, -1, 0]])
      .forEach(l => streetLamp(l[0], l[1], l[2], !!l[3]));
    const lampLights = [0, 1, 2].map(() => { const l = new T.PointLight(0xffaa55, 0, 14, 1.6); scene.add(l); return l; });
    let lampT = 0;
    W.updaters.push((dt, t) => {
      lampT -= dt;
      if (lampT <= 0 && W.camPos) { lampT = 0.4; const c = W.camPos; const near = W.lamps.slice().sort((a, b) => Math.hypot(a.x - c.x, a.z - c.z) - Math.hypot(b.x - c.x, b.z - c.z)); lampLights.forEach((l, i) => { l.userData.lamp = near[i]; if (near[i]) l.position.set(near[i].x, near[i].y - 0.15, near[i].z); }); }
      W.lamps.forEach(L => { let f = 1; if (L.flick) { f = Math.sin(t * 23 + L.f) > 0.92 || Math.random() < 0.01 ? 0.15 : 1; } L.cur = f; L.glow.material.opacity = 0.7 * f; L.bulb.material = f > 0.5 ? bulbM : offBulb; });
      lampLights.forEach(l => { const L = l.userData.lamp; l.intensity = L ? 1.25 * (L.cur || 1) : 0; });
    });

    // ---------- Bosque en los bordes (para que no se vea vacío) ----------
    const pineCanopy = (() => { const parts = []; [[1.6, 2.2, 1.9], [1.25, 1.9, 3.0], [0.85, 1.6, 4.0], [0.45, 1.2, 4.9]].forEach(c => parts.push({ geo: new T.ConeGeometry(c[0], c[1], 7), matrix: new T.Matrix4().makeTranslation(0, c[2], 0) })); return TL.mergeGeos(parts); })();
    const canopyM = new T.MeshLambertMaterial({ color: 0x18241a }), trunkM = new T.MeshLambertMaterial({ color: 0x2a2018 });
    const forestPts = [];
    for (let i = 0; i < 420; i++) {
      const edge = Math.random(); let x, z;
      if (edge < 0.38) { x = R(51, 70); z = R(-66, 60); } else if (edge < 0.76) { x = -R(51, 70); z = R(-66, 60); }
      else if (edge < 0.88) { x = R(-70, 70); z = R(56, 72); if (Math.abs(x) < 5) continue; } else { x = R(-70, 70); z = R(-68, -64); if (Math.abs(x) < 6) continue; }
      forestPts.push([x, z, R(0.75, 1.5)]);
    }
    const trunks = new T.InstancedMesh(new T.CylinderGeometry(0.12, 0.22, 2.2, 5), trunkM, forestPts.length), cans = new T.InstancedMesh(pineCanopy, canopyM, forestPts.length);
    { const m4 = new T.Matrix4(), q = new T.Quaternion(), sc = new T.Vector3(), ps = new T.Vector3(), e = new T.Euler();
      forestPts.forEach((f, i) => { const k = f[2]; e.set(R(-.05, .05), R(0, 6), R(-.05, .05)); q.setFromEuler(e);
        sc.set(k, k, k); ps.set(f[0], 1.1 * k, f[1]); m4.compose(ps, q, sc); trunks.setMatrixAt(i, m4);
        sc.set(k * R(0.85, 1.15), k * R(0.9, 1.3), k * R(0.85, 1.15)); ps.set(f[0], 0, f[1]); m4.compose(ps, q, sc); cans.setMatrixAt(i, m4); }); }
    scene.add(trunks); scene.add(cans);
    inst(new T.DodecahedronGeometry(0.7, 0), new T.MeshLambertMaterial({ color: 0x1e2a1a }), 220, (ps, e, sc) => {
      const side = Math.random() < 0.5 ? -1 : 1; const x = side * R(49.5, 54), z = R(-64, 56), k = R(0.6, 1.4); ps.set(x, 0.3 * k, z); e.set(R(0, 3), R(0, 3), R(0, 3)); sc.set(k * 1.3, k * 0.8, k);
    });

    // ---------- Niebla baja y luciérnagas ----------
    W.mist = [];
    [[0.3, 0.12, 0.004, 0.002], [0.9, 0.06, -0.003, 0.0035]].forEach((l, i) => {
      const t = TL.tex.mist().clone(); t.needsUpdate = true; t.repeat.set(5, 7);
      const m = new T.Mesh(new T.PlaneGeometry(130, 190), new T.MeshBasicMaterial({ map: t, color: 0x5a6878, transparent: true, opacity: l[1], depthWrite: false }));
      m.rotation.x = -Math.PI / 2; m.position.set(0, l[0], -15); m.renderOrder = 2; scene.add(m); W.mist.push(m);
      W.updaters.push((dt) => { t.offset.x += l[2] * dt; t.offset.y += l[3] * dt; });
    });
    const N = 90, fg = new T.BufferGeometry(), fp = new Float32Array(N * 3), seeds = [];
    for (let i = 0; i < N; i++) seeds.push({ x: R(-30, 30), y: R(0.4, 2.5), z: R(20, 52), p: R(0, 6) });
    fg.setAttribute('position', new T.BufferAttribute(fp, 3));
    const ff = new T.Points(fg, new T.PointsMaterial({ color: 0xd9ff8a, size: 0.09, transparent: true, opacity: 0.9, blending: T.AdditiveBlending, depthWrite: false }));
    scene.add(ff);
    W.updaters.push((dt, t) => { for (let i = 0; i < N; i++) { const s = seeds[i]; fp[i * 3] = s.x + Math.sin(t * 0.3 + s.p) * 1.5; fp[i * 3 + 1] = s.y + Math.sin(t * 0.7 + s.p * 2) * 0.3; fp[i * 3 + 2] = s.z + Math.cos(t * 0.25 + s.p) * 1.5; } fg.attributes.position.needsUpdate = true; ff.material.opacity = 0.5 + Math.sin(t * 3) * 0.3; });

    // ---------- Unir geometría estática por material ----------
    scene.updateMatrixWorld(true);
    const groups = new Map(), remove = [];
    scene.traverse(o => { if (o.isMesh && o.userData.static && !o.isInstancedMesh) { const k = o.material.uuid; if (!groups.has(k)) groups.set(k, { m: o.material, list: [], noCast: !!o.userData.noCast }); groups.get(k).list.push({ geo: o.geometry, matrix: o.matrixWorld.clone() }); remove.push(o); } });
    remove.forEach(o => o.parent.remove(o));
    W.merged = [];
    groups.forEach(g => {
      const mesh = new T.Mesh(TL.mergeGeos(g.list), g.m); mesh.castShadow = !g.noCast && !g.m.transparent; mesh.receiveShadow = true;
      mesh.frustumCulled = false; scene.add(mesh); W.merged.push(mesh);
    });
    scene.traverse(o => { if (o.isMesh && !o.userData.noShadow && o.material && !o.material.transparent && !(o.material.isMeshBasicMaterial) && !o.isInstancedMesh && W.merged.indexOf(o) < 0) { o.castShadow = true; o.receiveShadow = true; } });

    // puntos de aparición del león (en la niebla)
    W.spawns = [{ x: 0, z: -60 }, { x: 28, z: -14 }, { x: -28, z: -14 }, { x: 28, z: 20 }, { x: -28, z: 22 }, { x: 46, z: -31 }, { x: -46, z: -31 }, { x: 46, z: -6 }, { x: -46, z: 4.7 }];
    // red de calles para que el león sepa ir de un lado a otro
    W.nodes = []; const nid = {};
    function node(x, z) { const k = x + ',' + z; if (nid[k] == null) { nid[k] = W.nodes.length; W.nodes.push({ x, z, n: [] }); } return nid[k]; }
    function line(pts) { for (let i = 1; i < pts.length; i++) { const a = node(pts[i - 1][0], pts[i - 1][1]), b = node(pts[i][0], pts[i][1]); W.nodes[a].n.push(b); W.nodes[b].n.push(a); } }
    line([[0, 48], [0, 36], [0, 26], [0, 16], [0, 4.7], [0, -6], [0, -18], [0, -31], [0, -44], [0, -58]]);
    line([[-28, 26], [-28, 14], [-28, 4.7], [-28, -6], [-28, -18], [-28, -31], [-28, -46]]);
    line([[28, 26], [28, 14], [28, -6], [28, -18], [28, -31], [28, -46]]);
    line([[0, 4.7], [-10, 4.7], [-20, 4.7], [-28, 4.7], [-38, 4.7], [-46, 4.7]]);
    line([[0, -6], [10, -6], [20, -6], [28, -6], [38, -6], [46, -6]]);
    line([[-46, -31], [-38, -31], [-28, -31], [-18, -31], [-8, -31], [0, -31], [8, -31], [18, -31], [28, -31], [38, -31], [46, -31]]);
    // camino por calles (Dijkstra) desde (ax,az) a (bx,bz)
    W.streetPath = function (ax, az, bx, bz) {
      const vis = (x, z, nd) => !TL.collide.segmentBlocked(x, z, nd.x, nd.z, 1.0, W.colliders);
      const near = (x, z) => { let best = -1, bd = 1e9; W.nodes.forEach((nd, i) => { const d = Math.hypot(nd.x - x, nd.z - z); if (d < bd && (d < 3 || vis(x, z, nd))) { bd = d; best = i; } }); if (best < 0) W.nodes.forEach((nd, i) => { const d = Math.hypot(nd.x - x, nd.z - z); if (d < bd) { bd = d; best = i; } }); return best; };
      const A = near(ax, az), B = near(bx, bz), dist = W.nodes.map(() => 1e9), prev = W.nodes.map(() => -1), done = W.nodes.map(() => false);
      dist[A] = 0;
      for (;;) { let u = -1; dist.forEach((d, i) => { if (!done[i] && d < 1e9 && (u < 0 || d < dist[u])) u = i; }); if (u < 0 || u === B) break; done[u] = true;
        W.nodes[u].n.forEach(v => { const d = dist[u] + Math.hypot(W.nodes[u].x - W.nodes[v].x, W.nodes[u].z - W.nodes[v].z); if (d < dist[v]) { dist[v] = d; prev[v] = u; } }); }
      const out = []; for (let v = B; v >= 0; v = prev[v]) { out.unshift({ x: W.nodes[v].x, z: W.nodes[v].z }); if (v === A) break; }
      return out;
    };

    // ¿hay agua bajo este punto? (pantano o charco) → pasos que salpican
    W.wetAt = function (x, z) {
      if (z > 53) return true;
      for (const p of W.puddles) { const a = (x - p.x) / p.rx, b = (z - p.z) / p.rz; if (a * a + b * b < 1) return true; }
      return false;
    };
    // ondas en el agua al pisar
    const ripG = new T.RingGeometry(0.75, 1, 24), rips = [];
    for (let i = 0; i < 8; i++) { const m = new T.Mesh(ripG, new T.MeshBasicMaterial({ color: 0x9fb4c0, transparent: true, opacity: 0, depthWrite: false })); m.rotation.x = -Math.PI / 2; m.visible = false; m.userData.noShadow = true; scene.add(m); rips.push({ m, t: 9 }); }
    let ripI = 0;
    W.ripple = function (x, z, big) { const r = rips[ripI++ % rips.length]; r.t = 0; r.big = big ? 1.6 : 1; r.m.position.set(x, 0.05, z); r.m.visible = true; };
    W.updaters.push(dt => rips.forEach(r => { if (r.t > 1.2) { r.m.visible = false; return; } r.t += dt; const k = r.t / 1.2; r.m.scale.setScalar((0.1 + k * 0.7) * r.big); r.m.material.opacity = (1 - k) * 0.35; }));

    W.buildingAt = function (x, z) { for (const b of W.buildings) if (x > b.minX && x < b.maxX && z > b.minZ && z < b.maxZ) return b; return null; };
    W.update = function (dt, t, cam) {
      if (cam) W.camPos = cam.position;
      W.updaters.forEach(f => f(dt, t));
      sky.material.uniforms.uTime.value = t;
      if (cam) { W.skyParts.forEach(s => { if (!s.userData.base) s.userData.base = s.position.clone(); s.position.set(s.userData.base.x + cam.position.x, s.userData.base.y, s.userData.base.z + cam.position.z); }); }
    };
  };
})();
