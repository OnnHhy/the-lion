// THE LION — datos del juego (pistas, libreta, teorías, finales)
// Para agregar contenido en nuevas versiones, se edita SOLO este archivo.
window.TL = window.TL || {};
TL.VERSION = 'v0.3.1';

TL.THEORIES = {
  monstruo: 'Creo que ese león es un asesino. Hay que detenerlo.',
  familia: 'Creo que no hay un solo león. Y que se cuidan entre ellos.',
  humanos: 'Creo que la gente de este pueblo esconde algo. Algo le hicieron.',
  nada: 'Todavía no sé qué creer.'
};

// Cada pista: varios textos. Se usa el que tenga MÁS condiciones cumplidas (pistas ya encontradas).
// w = cuánto empuja cada teoría ese pensamiento.
TL.CLUES = {
  // Los textos SOLO describen lo que el personaje ve. Las conclusiones las saca quien juega.
  huellas: {
    name: 'Huellas en el barro', place: 'Orilla del pantano',
    lines: [
      { if: [], w: { familia: 2 }, text: 'Huellas de garras en el barro. Unas son enormes, hondas. Otras, más chicas, van al lado. Las dos van hacia el pueblo.' }
    ]
  },
  cartel: {
    name: 'Cartel de recompensa', place: 'Plaza',
    lines: [
      { if: [], w: { monstruo: 2, humanos: 1 }, text: '«SE BUSCA. Piel del león de la ciénaga. Recompensa: $300». Abajo, una firma borrosa: «Hnos. F.»' }
    ]
  },
  foto: {
    name: 'Fotografía vieja', place: 'Casa del cazador',
    lines: [
      { if: [], w: { humanos: 2, monstruo: 1 }, text: 'Tres hombres con rifles. Delante, un león grande con una cadena al cuello. Atrás dice: «Hnos. Ferrán — la cacería».' }
    ]
  },
  dibujo: {
    name: 'Dibujo de una niña', place: 'Casa de la niña',
    lines: [
      { if: [], w: { familia: 3, monstruo: -1 }, text: 'Un dibujo con crayones: una niña, un león grande y uno pequeño. Arriba, con letra torcida: «MIS AMIGOS».' }
    ]
  },
  pelo: {
    name: 'Pelos en la almohada', place: 'Casa de la niña',
    lines: [
      { if: [], w: { familia: 2, monstruo: 1 }, text: 'Pelos gruesos y dorados en la almohada. Muchos. La cama está hundida, como si algo pesado durmiera aquí.' }
    ]
  },
  trampa: {
    name: 'Trampa oxidada', place: 'Granero',
    lines: [
      { if: [], w: { humanos: 2, familia: 1 }, text: 'Una trampa de acero cerrada, con sangre seca. Atrapado en los dientes hay pelo oscuro, casi negro.' }
    ]
  },
  libro: {
    name: 'Libro de cuentas', place: 'Casa de los Ferrán',
    lines: [
      { if: [], w: { humanos: 3, familia: 1 }, text: 'Un libro de cuentas. «Cachorro (vendido) — $120», dos veces. «Cadenas nuevas». Y abajo, tachado: «Piel del grande — $300 ?»' }
    ]
  },
  collar: {
    name: 'Collar de cuero', place: 'Casa del herrero',
    lines: [
      { if: [], w: { familia: 3, monstruo: -1 }, text: 'Un collar de cuero pequeño, roto a mordidas. Tiene una medalla con una palabra grabada a mano: «SOL».' }
    ]
  },
  diario: {
    name: 'Página de un diario', place: 'Granero',
    lines: [
      { if: [], w: { humanos: 3 }, text: '«Mañana lo hacemos cruzar otra vez. El viejo ya no se levanta como antes. — F.»' }
    ]
  }
};
TL.CLUE_COUNT = Object.keys(TL.CLUES).length;

// Finales de v0.1 (conclusiones parciales al llegar al río)
TL.ENDINGS = {
  creyo: { title: 'SIN DISPARAR', text: 'Encontraste todo y nunca disparaste. En la niebla del río, algo grande respira. Te mira. Y esta vez no ruge.' },
  cazador: { title: 'EL DISPARO', text: 'Le disparaste. Llegas al río con el rifle caliente. Del otro lado, en la niebla, algo ruge más fuerte que el león que heriste.' },
  rugido: { title: 'EL MIEDO', text: 'Llegaste al río corriendo, sin entender del todo qué pasó en el pueblo. Del otro lado, en la niebla, algo ruge.' },
  huellas: { title: 'LAS HUELLAS', text: 'Las huellas siguen hasta el agua y se pierden. Del otro lado, en la niebla, algo enorme espera.' },
  pueblo: { title: 'LO QUE CALLA EL PUEBLO', text: 'Fotos, trampas, una recompensa, un diario. Llegas al río. Del otro lado, la niebla. Y un rugido que no viene del pueblo.' }
};

TL.pickLine = function (id, found) {
  const c = TL.CLUES[id]; let best = c.lines[0], bestN = -1;
  c.lines.forEach(l => {
    if (l.if.every(x => found.indexOf(x) >= 0) && l.if.length > bestN) { best = l; bestN = l.if.length; }
  });
  return best;
};

TL.dominant = function (th) {
  let k = 'nada', v = 0;
  ['monstruo', 'familia', 'humanos'].forEach(t => { if (th[t] > v) { v = th[t]; k = t; } });
  return k;
};

TL.pickEnding = function (G) {
  const d = TL.dominant(G.theory);
  if (G.found.length >= TL.CLUE_COUNT && G.shotsAtLion === 0) return 'creyo';
  if (G.shotsHit > 0 && (d === 'monstruo' || d === 'nada')) return 'cazador';
  if (d === 'familia') return 'huellas';
  if (d === 'humanos') return 'pueblo';
  return G.shotsHit > 0 ? 'cazador' : 'rugido';
};
