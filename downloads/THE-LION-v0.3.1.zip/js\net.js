// Multijugador en línea (2 PCs) con PeerJS.
// El ANFITRIÓN maneja al león y el mundo; el INVITADO manda su posición y ve al león que le llega.
// Se conectan con un código corto (ej. LX7P2). Necesita internet solo para jugar en línea.
(function () {
  const T = THREE, $ = id => document.getElementById(id);
  function R(a, b) { return a + Math.random() * (b - a); }
  const PREFIX = 'thelion-v031-';
  const CH = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  // STUN (gratis, de Google) + TURN público de respaldo por si los routers no se dejan conectar directo
  const ICE = { iceServers: [
    { urls: 'stun:stun.l.google.com:19302' }, { urls: 'stun:stun1.l.google.com:19302' },
    { urls: ['turn:openrelay.metered.ca:80', 'turn:openrelay.metered.ca:443', 'turn:openrelay.metered.ca:443?transport=tcp'], username: 'openrelayproject', credential: 'openrelayproject' }
  ] };

  // ---------- Modelo del compañero (investigador con sombrero, abrigo, rifle y linterna) ----------
  function makeAvatar(scene) {
    const h = TL.makeHuman({ skin: 0xb08068, cloth: 0x3a2c20, pants: 0x24211e, hair: 0x2a1e14, coat: true, hat: true, hairStyle: 'short' });
    const g = h.g;
    // rifle en las manos, apuntando adelante
    const rifle = new T.Group(); rifle.position.set(0.1, 0.34, 0.28); h.spine.add(rifle);
    const st = new T.Mesh(new T.BoxGeometry(0.06, 0.09, 0.95), new T.MeshPhongMaterial({ color: 0x3e2716 })); rifle.add(st);
    const lens = new T.Sprite(new T.SpriteMaterial({ map: TL.tex.glow(), color: 0xfff0c8, transparent: true, blending: T.AdditiveBlending, depthWrite: false, fog: false })); lens.position.set(0, -0.03, 0.5); lens.scale.set(0.35, 0.35, 1); rifle.add(lens);
    const beamG = new T.ConeGeometry(1.6, 8, 16, 1, true); beamG.translate(0, -4, 0);
    const beam = new T.Mesh(beamG, new T.MeshBasicMaterial({ color: 0xffe8b0, transparent: true, opacity: 0.05, blending: T.AdditiveBlending, depthWrite: false, side: T.DoubleSide, fog: false }));
    beam.rotation.x = -Math.PI / 2; beam.position.set(0, -0.03, 0.5); rifle.add(beam);
    // nombre encima
    const cv = document.createElement('canvas'); cv.width = 256; cv.height = 64;
    const tag = new T.Sprite(new T.SpriteMaterial({ map: new T.CanvasTexture(cv), transparent: true, depthTest: false, fog: false })); tag.position.y = 2.25; tag.scale.set(1.2, 0.3, 1); tag.renderOrder = 9; g.add(tag);
    g.traverse(m => { if (m.isMesh && m !== beam) m.castShadow = true; });
    g.visible = false; scene.add(g);
    function setName(n) { const x = cv.getContext('2d'); x.clearRect(0, 0, 256, 64); x.font = '600 26px Segoe UI, sans-serif'; x.textAlign = 'center'; x.fillStyle = 'rgba(0,0,0,.55)'; x.fillText(n, 129, 41); x.fillStyle = '#f0e2c0'; x.fillText(n, 128, 40); tag.material.map.needsUpdate = true; }
    return { g, h, head: h.head, rifle, beam, lens, tag, setName, phase: 0 };
  }

  TL.Net = function (G) {
    const N = this; N.G = G; N.on = false; N.host = false; N.conn = null; N.peer = null; N.sendT = 0; N.pings = []; N.lsnap = null;
    N.remote = { pos: new T.Vector3(0, 0, 40), tpos: new T.Vector3(0, 0, 40), yaw: 0, tyaw: 0, pitch: 0, hidden: null, hiddenAt: -99, crouch: false, light: true,
      noise: 0, nr: 0, hp: 100, state: 'title', speed: 0, name: 'Compañero', stepAcc: 0, noiseRadius() { return this.nr; } };
    N.av = makeAvatar(G.scene); N.av.setName('Compañero');
    try { N.myName = localStorage.getItem('thelion.name') || ''; } catch (e) { N.myName = ''; }
  };
  const N = TL.Net.prototype;

  N.remoteActive = function () { const r = this.remote; return this.on && ['play', 'clue', 'notebook'].indexOf(r.state) >= 0 && r.hp > 0; };
  N.send = function (m) { if (this.on && this.conn && this.conn.open) { try { this.conn.send(m); } catch (e) { } } };
  N.msg = function (t, bad) { const el = $('netMsg'); el.textContent = t; el.className = bad ? 'bad' : ''; };

  // ---------- Crear / unirse ----------
  N.createRoom = function () {
    if (typeof Peer === 'undefined') { this.msg('No se pudo cargar la conexión (falta vendor/peerjs.min.js).', true); return; }
    this.reset(); this.host = true;
    const code = Array.from({ length: 5 }, () => CH[Math.floor(Math.random() * CH.length)]).join('');
    this.code = code; this.msg('Creando la partida…');
    const peer = this.peer = new Peer(PREFIX + code, { config: ICE, debug: 1 });
    peer.on('open', () => { $('codeOut').textContent = code; $('codeBox').style.display = 'block'; this.msg('Esperando a tu compañero… (deja esta ventana abierta)'); });
    peer.on('connection', conn => { if (this.conn && this.conn.open) { conn.close(); return; } this.bind(conn); });
    peer.on('error', e => { if (e.type === 'unavailable-id') { this.createRoom(); return; } this.msg(errText(e), true); });
    peer.on('disconnected', () => { if (!this.on) this.msg('Se perdió la conexión con el servidor. Intenta de nuevo.', true); });
  };
  N.joinRoom = function (code) {
    if (typeof Peer === 'undefined') { this.msg('No se pudo cargar la conexión (falta vendor/peerjs.min.js).', true); return; }
    code = (code || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
    if (code.length < 4) { this.msg('Escribe el código que te pasó tu amigo.', true); return; }
    this.reset(); this.host = false; this.msg('Buscando la partida ' + code + '…');
    const peer = this.peer = new Peer(undefined, { config: ICE, debug: 1 });
    peer.on('open', () => { const conn = peer.connect(PREFIX + code, { reliable: true, serialization: 'json' }); this.bind(conn);
      setTimeout(() => { if (!this.on) this.msg('No responde. Revisa el código y que tu amigo tenga la partida abierta.', true); }, 12000); });
    peer.on('error', e => this.msg(errText(e), true));
  };
  function errText(e) {
    const t = e && e.type;
    if (t === 'peer-unavailable') return 'No encontré esa partida. Revisa el código.';
    if (t === 'network' || t === 'server-error' || t === 'socket-error') return 'Sin conexión al servidor. ¿Tienes internet?';
    if (t === 'browser-incompatible') return 'Este navegador no sirve para jugar en línea. Usa Chrome o Edge.';
    return 'Error de conexión (' + (t || 'desconocido') + ').';
  }
  N.reset = function () { try { if (this.conn) this.conn.close(); if (this.peer) this.peer.destroy(); } catch (e) { } this.conn = null; this.peer = null; this.on = false; $('codeBox').style.display = 'none'; };
  N.bind = function (conn) {
    this.conn = conn;
    conn.on('open', () => {
      this.on = true; this.myName = ($('nmIn').value || '').trim().slice(0, 14) || (this.host ? 'Jugador 1' : 'Jugador 2');
      try { localStorage.setItem('thelion.name', this.myName); } catch (e) { }
      this.send({ t: 'hello', name: this.myName, v: TL.VERSION });
      if (this.host) this.hookHost();
    });
    conn.on('data', m => this.onData(m));
    conn.on('close', () => this.lost());
    conn.on('error', () => this.lost());
  };
  N.lost = function () {
    if (!this.on) return; this.on = false; const G = this.G;
    this.av.g.visible = false; $('mate').style.display = 'none';
    if (G.state === 'title') { this.msg('Tu compañero se desconectó.', true); return; }
    G.ui.thought('Se cortó la conexión con ' + this.remote.name + '. Sigues solo.', 4);
    if (!this.host) { G.lion.off(); this.lsnap = null; }
    this.host = true; // ahora este juego manda (modo solo)
  };

  // el anfitrión reenvía al invitado lo que hace el león (sonidos, rugidos, armarios rotos)
  N.hookHost = function () {
    if (this.hooked) return; this.hooked = true;
    const G = this.G, A = G.audio, self = this;
    const near = pos => pos && G.lion.active() && Math.hypot(pos.x - G.lion.pos.x, pos.z - G.lion.pos.z) < 3;
    ['growl', 'roar', 'sniff', 'lionBreath'].forEach(n => {
      const f = A[n]; A[n] = function (pos) { const a = Array.prototype.slice.call(arguments, 1); if (near(pos)) self.send({ t: 'snd', n, x: pos.x, z: pos.z, a }); return f.apply(A, arguments); };
    });
    const sm = A.smash; A.smash = function () { if (G.lion.state === 'smash') self.send({ t: 'snd', n: 'smashAt', x: G.lion.pos.x, z: G.lion.pos.z, a: [] }); return sm.apply(A, arguments); };
    const roar = G.onRoar; G.onRoar = function (pos, big, mild) { self.send({ t: 'roar', x: pos.x, z: pos.z, big: !!big, mild: !!mild }); return roar.apply(G, arguments); };
    const lsm = G.lion.smash; G.lion.smash = function (c) { self.send({ t: 'smash', ci: G.world.closets.indexOf(c) }); return lsm.call(this, c); };
    G.onDoorBash = d => self.send({ t: 'door', i: G.world.doors.indexOf(d), o: true, b: true });
    const left = G.onLionLeftCloset; G.onLionLeftCloset = function () { self.send({ t: 'left' }); return left.apply(G, arguments); };
  };

  // ---------- Mensajes ----------
  N.onData = function (m) {
    const G = this.G, r = this.remote; if (!m || !m.t) return;
    switch (m.t) {
      case 'hello':
        r.name = (m.name || 'Compañero').slice(0, 14); this.av.setName(r.name); $('mateN').textContent = r.name;
        if (m.v !== TL.VERSION) this.msg('Ojo: tu amigo tiene otra versión (' + m.v + '). Usen la misma.', true);
        else this.msg('¡' + r.name + ' está conectado! Empezando…');
        if (this.host) setTimeout(() => { this.send({ t: 'start' }); this.start(); }, 1500);
        break;
      case 'start': this.start(); break;
      case 'st': {
        r.tpos.set(m.p[0], m.p[1], m.p[2]); r.tyaw = m.yaw; r.pitch = m.pitch; r.crouch = !!m.cr; r.light = !!m.li; r.noise = m.nz || 0; r.nr = m.nr || 0;
        r.hp = m.hp; r.speed = m.sp || 0; r.aim = !!m.aim;
        if (r.state !== m.s && (m.s === 'play' && (r.state === 'title' || r.state === 'intro' || r.state === 'dead'))) r.pos.copy(r.tpos);
        r.state = m.s;
        const h = m.hid >= 0 ? G.world.closets[m.hid] : null;
        if (h !== r.hidden) { if (h) r.hiddenAt = G.time; if (r.hidden && !r.hidden.destroyed) r.hidden.grp.visible = true; r.hidden = h; if (h) { h.grp.visible = true; r.pos.copy(r.tpos); } }
        break;
      }
      case 'ln': this.lsnap = m; break;
      case 'snd': {
        const pos = { x: m.x, z: m.z };
        if (m.n === 'smashAt') G.audio.smash(); else if (G.audio[m.n]) G.audio[m.n].apply(G.audio, [pos].concat(m.a || []));
        break;
      }
      case 'roar': G.onRoar({ x: m.x, z: m.z }, m.big, m.mild); if (G.lion.group.visible) G.lion.roarAnim = 1.2; break;
      case 'found': {
        const line = G.applyFound(m.id); if (!line) break;
        G.audio.page(); G.fear = Math.max(G.fear, 55);
        G.ui.thought(r.name + ' encontró: «' + TL.CLUES[m.id].name + '». Revísalo en tu libreta (TAB).', 4.5);
        if (this.host) { const it = G.world.interact.find(i => i.kind === 'clue' && i.id === m.id); G.afterClue(it ? G.world.buildingAt(it.x, it.z) : null, r, false); }
        break;
      }
      case 'take': { const it = G.world.interact[m.i]; if (it && !it.done) { it.done = true; if (it.mesh) it.mesh.visible = false; } break; }
      case 'smash': { const c = G.world.closets[m.ci]; if (c && !c.destroyed) c.destroy(); break; }
      case 'hurt': G.takeHit({ x: m.lx, z: m.lz }, m.dmg, m.reason, null); break;
      case 'shot': {
        G.audio.shotFar({ x: m.o[0], y: m.o[1], z: m.o[2] });
        if (this.host) G.onShot(new T.Vector3(m.o[0], m.o[1], m.o[2]), new T.Vector3(m.d[0], m.d[1], m.d[2]).normalize(), r);
        break;
      }
      case 'say': G.ui.thought(m.m, 2.5); break;
      case 'door': { const d = G.world.doors[m.i]; if (d && d.open !== m.o) { d.setOpen(m.o, m.b); if (m.b) { d.bashT = 0.3; G.audio.doorBash(d); } else G.audio.door(d, m.o); } break; }
      case 'freed': if (this.host && G.lion.state === 'pin') { G.lion.state = 'recover'; G.lion.recT = m.ok ? 2.2 : 1.6; G.lion.roarAnim = 1; } break;
      case 'left': if (G.player.hidden) setTimeout(() => { if (G.player.hidden) G.ui.thought('Se fue… tengo que salir de aquí. Ya.'); }, 2500); break;
      case 'end': if (G.state !== 'ending' && G.state !== 'title') G.startEnding(); break;
      case 'ping': this.addPing(m.x, m.y, m.z, false); break;
    }
  };

  N.start = function () {
    const G = this.G; if (G.state !== 'title') return;
    $('online').style.display = 'none'; $('mate').style.display = 'block'; $('mateN').textContent = this.remote.name;
    G.startGame();
  };

  // ---------- Señal «¡aquí!» (tecla Q) ----------
  N.addPing = function (x, y, z, mine) {
    const el = document.createElement('div'); el.className = 'pingMk' + (mine ? ' mine' : ''); el.innerHTML = '<i></i><span>' + (mine ? 'AQUÍ' : this.remote.name.toUpperCase()) + '</span>';
    document.body.appendChild(el); this.pings.push({ el, p: new T.Vector3(x, y, z), t: 0 });
    this.G.audio.ping({ x, y, z });
  };

  // ---------- Cada cuadro ----------
  N.update = function (dt) {
    const G = this.G, r = this.remote, av = this.av, P = G.player, cam = G.camera;
    if (!this.on) { this.pings.forEach(p => p.el.remove()); this.pings = []; return; }
    // compañero: suavizar movimiento
    const k = Math.min(1, dt * 10);
    if (r.pos.distanceTo(r.tpos) > 8) r.pos.copy(r.tpos); else r.pos.lerp(r.tpos, k);
    let dy = r.tyaw - r.yaw; while (dy > Math.PI) dy -= Math.PI * 2; while (dy < -Math.PI) dy += Math.PI * 2; r.yaw += dy * k;
    const vis = ['play', 'clue', 'notebook', 'dying'].indexOf(r.state) >= 0 && !r.hidden;
    av.g.visible = vis;
    if (vis) {
      av.g.position.copy(r.pos); av.g.rotation.y = r.yaw + Math.PI;
      const sp = r.speed; av.phase += dt * sp * 1.9;
      const H = av.h; TL.poseWalk(H, av.phase, Math.min(1, sp / 3), sp > 4.5);
      // sostiene el rifle con las dos manos
      H.armR.root.rotation.set(-1.0, 0, -0.25); H.armR.joint.rotation.x = -0.7; H.armL.root.rotation.set(-1.25, 0, 0.45); H.armL.joint.rotation.x = -0.5;
      if (r.crouch) { H.hips.position.y = 0.6; H.legL.root.rotation.x = H.legR.root.rotation.x = -1.2; H.legL.joint.rotation.x = H.legR.joint.rotation.x = 1.9; }
      H.spine.rotation.x += -r.pitch * 0.25 + (r.crouch ? 0.3 : 0); av.head.rotation.x = -r.pitch * 0.5;
      av.rifle.rotation.x = -r.pitch * 0.6 + (r.state === 'dying' ? 1 : 0);
      av.beam.visible = r.light && r.state === 'play' && G.quality !== 'baja'; av.lens.visible = r.light;
      if (r.state === 'dying') { av.g.rotation.z = Math.min(1.5, (av.g.rotation.z || 0) + dt * 2); } else av.g.rotation.z = 0;
      // sus pasos se escuchan
      if (sp > 0.5 && r.state === 'play') { r.stepAcc += sp * dt; if (r.stepAcc > (sp > 5 ? 2.3 : r.crouch ? 1.2 : 1.8)) { r.stepAcc = 0; const w = G.world.wetAt(r.pos.x, r.pos.z); G.audio.stepAt(r.pos, w); if (w) G.world.ripple(r.pos.x, r.pos.z); } }
    }
    // mandar mi estado (15 por segundo)
    this.sendT -= dt;
    if (this.sendT <= 0) {
      this.sendT = 1 / 15;
      this.send({ t: 'st', p: [+P.pos.x.toFixed(2), +P.pos.y.toFixed(2), +P.pos.z.toFixed(2)], yaw: +P.yaw.toFixed(3), pitch: +P.pitch.toFixed(3), cr: P.crouch ? 1 : 0, li: P.light ? 1 : 0,
        nz: Math.round(G.breath.noise), nr: +P.noiseRadius().toFixed(1), hp: Math.round(G.hp), s: G.state, sp: +P.speedNow.toFixed(1), hid: P.hidden ? G.world.closets.indexOf(P.hidden) : -1 });
      if (this.host) { const L = G.lion; this.send({ t: 'ln', x: +L.pos.x.toFixed(2), z: +L.pos.z.toFixed(2), y: +L.crouchY.toFixed(2), h: +L.heading.toFixed(3), v: +L.vel.toFixed(2), st: L.state, vis: L.active() && L.group.visible ? 1 : 0, ra: +L.roarAnim.toFixed(2), sa: +L.sniffAnim.toFixed(2) }); }
    }
    // señal Q
    if (G.state === 'play' && P.consume('KeyQ')) {
      const f = P.fwd(), o = cam.position; let t = 14; if (f.y < -0.02) t = Math.min(t, o.y / -f.y);
      const x = o.x + f.x * t, y = Math.max(0.3, o.y + f.y * t), z = o.z + f.z * t;
      this.addPing(x, y, z, true); this.send({ t: 'ping', x, y, z });
    }
    // HUD del compañero
    const d = Math.hypot(r.pos.x - P.pos.x, r.pos.z - P.pos.z);
    const st = r.state === 'dying' || r.state === 'dead' || r.hp <= 0 ? 'CAÍDO' : r.hidden ? 'ESCONDIDO' : r.state === 'intro' ? 'EN LA INTRO' : r.state === 'clue' ? 'LEYENDO UNA PISTA' : Math.round(d) + ' m';
    $('mateS').textContent = st; $('mateHp').style.width = Math.max(0, r.hp) + '%';
    this.mark($('mateMk'), new T.Vector3(r.pos.x, r.pos.y + (r.crouch ? 1.6 : 2.0), r.pos.z), ['play', 'clue', 'notebook', 'dying', 'dead'].indexOf(r.state) >= 0 && d > 3 && G.state === 'play', Math.round(d) + ' m');
    this.pings = this.pings.filter(p => { p.t += dt; if (p.t > 5) { p.el.remove(); return false; } this.mark(p.el, p.p, G.state === 'play', null); p.el.style.opacity = Math.min(1, (5 - p.t) * 1.5); return true; });
  };
  const tmp = new THREE.Vector3();
  N.mark = function (el, pos, show, label) {
    if (!show) { el.style.display = 'none'; return; }
    tmp.copy(pos).project(this.G.camera);
    if (tmp.z > 1 || tmp.x < -1.1 || tmp.x > 1.1 || tmp.y < -1.1 || tmp.y > 1.1) { el.style.display = 'none'; return; }
    el.style.display = 'block'; el.style.left = ((tmp.x + 1) / 2 * innerWidth) + 'px'; el.style.top = ((1 - tmp.y) / 2 * innerHeight) + 'px';
    if (label != null) { const s = el.querySelector('span'); if (s) s.textContent = label; }
  };

  // ---------- Invitado: dibujar el león que manda el anfitrión ----------
  N.puppet = function (dt) {
    const G = this.G, L = G.lion, s = this.lsnap; if (!s) return;
    if (!s.vis) { if (L.group.visible) { L.group.visible = false; L.state = 'off'; } return; }
    if (!L.group.visible) { L.group.visible = true; L.pos.set(s.x, 0, s.z); L.heading = L.lastHeading = s.h; }
    L.state = s.st; const k = Math.min(1, dt * 10);
    if (Math.hypot(s.x - L.pos.x, s.z - L.pos.z) > 6) L.pos.set(s.x, 0, s.z); else { L.pos.x += (s.x - L.pos.x) * k; L.pos.z += (s.z - L.pos.z) * k; }
    let a = s.h - L.heading; while (a > Math.PI) a -= Math.PI * 2; while (a < -Math.PI) a += Math.PI * 2; L.heading += a * k;
    L.speed = s.v; L.vel = s.v; L.t += dt; L.roarAnim = Math.max(L.roarAnim, s.ra); L.sniffAnim = Math.max(L.sniffAnim, s.sa);
    L.animate(dt); L.sync();
  };

  // ---------- Menú «Jugar en línea» ----------
  TL.initNet = function (G) {
    const net = G.net = new TL.Net(G);
    $('nmIn').value = net.myName;
    const tog = () => { const o = $('online'); const open = o.style.display !== 'block'; o.style.display = open ? 'block' : 'none'; $('btnOnline').classList.toggle('sel', open); $('ctrls').style.display = 'none'; $('btnCtrl').classList.remove('sel'); G.audio.ui(true); };
    $('btnOnline').addEventListener('mousedown', e => { e.stopPropagation(); tog(); });
    $('btnCtrl').addEventListener('mousedown', () => { $('online').style.display = 'none'; $('btnOnline').classList.remove('sel'); });
    $('btnHost').addEventListener('mousedown', e => { e.stopPropagation(); G.audio.ui(true); net.createRoom(); });
    $('btnJoin').addEventListener('mousedown', e => { e.stopPropagation(); G.audio.ui(true); net.joinRoom($('codeIn').value); });
    $('codeIn').addEventListener('keydown', e => { if (e.key === 'Enter') net.joinRoom($('codeIn').value); });
    $('btnCopy').addEventListener('mousedown', e => { e.stopPropagation(); try { navigator.clipboard.writeText(net.code); net.msg('Código copiado. Pásaselo por WhatsApp.'); } catch (err) { } });
    ['online'].forEach(id => $(id).addEventListener('mousedown', e => e.stopPropagation()));
  };
  if (TL.G) TL.initNet(TL.G);
})();
