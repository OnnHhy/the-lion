// Jugador en primera persona: moverse, correr, agacharse, saltar, trepar, linterna y rifle viejo
(function () {
  const T = THREE;
  function R(a, b) { return a + Math.random() * (b - a); }

  TL.Player = function (G) {
    const P = this; this.G = G; const cam = G.camera;
    P.pos = new T.Vector3(0, 0, 40); P.vy = 0; P.yaw = 0; P.pitch = 0; P.onGround = true; P.eye = 1.65;
    P.crouch = false; P.stamina = 100; P.hidden = null; P.hiddenAt = -99; P.mantle = null; P.para = 0; P.light = true;
    P.keys = {}; P.pressed = {}; P.aiming = false; P.loaded = 1; P.reserve = 2; P.reloadT = 0; P.recoil = 0;
    P.bobT = 0; P.stepAcc = 0; P.speedNow = 0; P.shake = 0; P.sprinting = false;
    P.bobAmp = 0; P.land = 0; P.swayX = 0; P.swayY = 0; P.lastYaw = 0; P.lastPitch = 0; P.trem = new T.Vector3(); P.fallStart = 0;

    // linterna (montada en el rifle)
    P.spot = new T.SpotLight(0xfff0d0, 2.4, 30, 0.42, 0.55, 1.2);
    P.spot.position.set(0.12, -0.12, -0.8); P.spot.target.position.set(0.05, -0.2, -6);
    cam.add(P.spot); cam.add(P.spot.target);
    P.muzzle = new T.PointLight(0xffc070, 0, 12, 2); P.muzzle.position.set(0.2, -0.1, -1); cam.add(P.muzzle);
    // haz de luz visible en la niebla
    const bg = new T.ConeGeometry(1.9, 9, 24, 1, true); bg.translate(0, -4.5, 0);
    P.beam = new T.Mesh(bg, new T.ShaderMaterial({
      uniforms: { uOp: { value: 0.11 } }, transparent: true, depthWrite: false, blending: T.AdditiveBlending, side: T.DoubleSide, fog: false,
      vertexShader: 'varying vec3 vN; varying vec3 vP; varying float vY; void main(){ vN = normalize(normalMatrix * normal); vec4 mv = modelViewMatrix * vec4(position,1.0); vP = mv.xyz; vY = uv.y; gl_Position = projectionMatrix * mv; }',
      fragmentShader: 'uniform float uOp; varying vec3 vN; varying vec3 vP; varying float vY; void main(){ float f = abs(dot(vN, normalize(-vP))); float a = pow(f, 2.5) * pow(vY, 2.2) * uOp; gl_FragColor = vec4(vec3(1.0, 0.93, 0.78) * a, 1.0); }'
    }));
    P.beam.rotation.x = Math.PI / 2 - 0.035; P.beam.position.set(0.12, -0.12, -0.75); P.beam.renderOrder = 5; cam.add(P.beam);

    // rifle de palanca + manos (en primera persona)
    const gun = new T.Group();
    const woodT = TL.tex.get('planks', 1, 1);
    const wood = new T.MeshPhongMaterial({ color: 0x6a4024, map: woodT, shininess: 35, specular: 0x2a1a10 });
    const blued = new T.MeshPhongMaterial({ color: 0x1c1d20, shininess: 70, specular: 0x5a6068 });
    const brassM = new T.MeshPhongMaterial({ color: 0x9a7a40, shininess: 80, specular: 0x8a7040 });
    // culata con forma (perfil extruido)
    const sh = new T.Shape(); sh.moveTo(0, 0.02); sh.lineTo(0.16, 0.03); sh.lineTo(0.42, -0.02); sh.lineTo(0.44, -0.12); sh.lineTo(0.40, -0.13); sh.lineTo(0.16, -0.06); sh.lineTo(0.02, -0.05); sh.lineTo(0, 0.02);
    const sg = new T.ExtrudeGeometry(sh, { depth: 0.05, bevelEnabled: true, bevelThickness: 0.008, bevelSize: 0.008, bevelSegments: 2 }); sg.translate(0, 0, -0.025); sg.rotateY(-Math.PI / 2);
    const stock = new T.Mesh(sg, wood); stock.position.set(0, 0.0, 0.08); gun.add(stock);
    const recv = new T.Mesh(new T.BoxGeometry(0.052, 0.085, 0.2), blued); recv.position.set(0, 0.012, -0.02); gun.add(recv);
    const side = new T.Mesh(new T.BoxGeometry(0.054, 0.05, 0.12), brassM); side.position.set(0, 0.0, -0.03); gun.add(side);
    const fore = new T.Mesh(new T.BoxGeometry(0.048, 0.05, 0.3), wood); fore.position.set(0, 0.005, -0.27); gun.add(fore);
    const barrel = new T.Mesh(new T.CylinderGeometry(0.012, 0.014, 0.66, 10), blued); barrel.rotation.x = Math.PI / 2; barrel.position.set(0, 0.04, -0.45); gun.add(barrel);
    const tube = new T.Mesh(new T.CylinderGeometry(0.01, 0.01, 0.52, 8), blued); tube.rotation.x = Math.PI / 2; tube.position.set(0, 0.016, -0.4); gun.add(tube);
    [-0.42, -0.62].forEach(z => { const band = new T.Mesh(new T.CylinderGeometry(0.02, 0.02, 0.018, 10), blued); band.rotation.x = Math.PI / 2; band.position.set(0, 0.03, z); gun.add(band); });
    const fsight = new T.Mesh(new T.BoxGeometry(0.004, 0.018, 0.01), blued); fsight.position.set(0, 0.06, -0.76); gun.add(fsight);
    const rsight = new T.Mesh(new T.BoxGeometry(0.03, 0.014, 0.006), blued); rsight.position.set(0, 0.066, -0.16); gun.add(rsight);
    const hammer = new T.Mesh(new T.BoxGeometry(0.01, 0.03, 0.02), blued); hammer.position.set(0, 0.065, 0.07); hammer.rotation.x = -0.4; gun.add(hammer);
    const lever = new T.Mesh(new T.TorusGeometry(0.035, 0.007, 6, 12, Math.PI * 1.3), blued); lever.position.set(0, -0.05, 0.02); lever.rotation.set(0, Math.PI / 2, 0.6); gun.add(lever);
    // linterna atada bajo el cañón
    const lamp = new T.Mesh(new T.CylinderGeometry(0.022, 0.026, 0.11, 10), blued); lamp.rotation.x = Math.PI / 2; lamp.position.set(0.0, -0.035, -0.46); gun.add(lamp);
    const strap = new T.Mesh(new T.BoxGeometry(0.06, 0.012, 0.02), new T.MeshLambertMaterial({ color: 0x3a2a1a })); strap.position.set(0, -0.012, -0.46); gun.add(strap);
    const lens = new T.Mesh(new T.CircleGeometry(0.02, 10), new T.MeshBasicMaterial({ color: 0xfff4d0 })); lens.position.set(0, -0.035, -0.516); lens.rotation.y = Math.PI; gun.add(lens);
    const flash = new T.Mesh(new T.ConeGeometry(0.05, 0.22, 6), new T.MeshBasicMaterial({ color: 0xffd080, transparent: true, opacity: 0 }));
    flash.rotation.x = -Math.PI / 2; flash.position.set(0, 0.04, -0.9); gun.add(flash);
    // manos y mangas
    P.skinM = new T.MeshPhongMaterial({ color: 0xa8745a, shininess: 12 }); P.wrapM = new T.MeshPhongMaterial({ color: 0x8a7a62, shininess: 2 });
    P.handMeshes = [];
    const sleeveM = new T.MeshPhongMaterial({ color: 0x3a2c20, shininess: 6 });
    function hand(x, y, z, rz, grip) {
      const h = new T.Group(); h.position.set(x, y, z); h.rotation.z = rz;
      const palm = new T.Mesh(new T.BoxGeometry(0.075, 0.03, 0.085), P.skinM); h.add(palm); P.handMeshes.push(palm);
      for (let i = 0; i < 4; i++) { const f = new T.Mesh(new T.CapsuleGeometry(0.009, 0.035, 3, 6), P.skinM); f.position.set(-0.028 + i * 0.019, grip ? -0.03 : -0.01, -0.035); f.rotation.x = grip ? 1.3 : 0.4; h.add(f); P.handMeshes.push(f); }
      const th = new T.Mesh(new T.CapsuleGeometry(0.01, 0.03, 3, 6), P.skinM); th.position.set(0.04, 0.005, -0.01); th.rotation.set(0.3, 0, -0.9); h.add(th); P.handMeshes.push(th);
      const sl = new T.Mesh(new T.CylinderGeometry(0.045, 0.05, 0.3, 10), sleeveM); sl.rotation.x = Math.PI / 2 - 0.25; sl.position.set(0, -0.03, 0.17); h.add(sl);
      const cuff = new T.Mesh(new T.CylinderGeometry(0.04, 0.04, 0.05, 10), P.skinM); cuff.rotation.x = Math.PI / 2 - 0.25; cuff.position.set(0, -0.012, 0.035); h.add(cuff); P.handMeshes.push(cuff);
      gun.add(h); return h;
    }
    P.handL = hand(-0.035, -0.025, -0.27, 0.5, true); P.handR = hand(0.02, -0.04, 0.03, -0.3, true);
    gun.traverse(m => { if (m.isMesh) { m.renderOrder = 6; } });
    P.gun = gun; P.flash = flash; P.lens = lens; P.boltM = lever;
    cam.add(gun); gun.position.set(0.2, -0.2, -0.38);
    P.shoes = false; P.armor = false; P.inspect = null; P.tremT = Math.random() * 10;
  };
  const P = TL.Player.prototype;

  P.fwd = function () { return new T.Vector3(-Math.sin(this.yaw) * Math.cos(this.pitch), Math.sin(this.pitch), -Math.cos(this.yaw) * Math.cos(this.pitch)); };
  P.noiseRadius = function () {
    const s = this.speedNow; if (s < 0.2) return 0;
    const k = this.shoes ? 0.55 : 1;
    if (this.crouch) return 2.2 * k; if (this.sprinting) return 12 * k; return 5.5 * k;
  };
  P.press = function (code) { this.pressed[code] = true; };
  P.consume = function (code) { const v = this.pressed[code]; this.pressed[code] = false; return v; };

  P.hide = function (c) {
    this.G.audio.door(c, true); this.hidden = c; this.hiddenAt = this.G.time; c.grp.visible = c.kind !== 'closet'; this.pressed = {}; this.pos.set(c.hide.x, 0, c.hide.z); this.yaw = c.lookYaw; this.pitch = c.kind === 'bed' ? 0.02 : -0.05;
    this.G.audio.thud();
  };
  P.unhide = function () {
    const c = this.hidden; this.hidden = null; c.grp.visible = true; this.pressed = {}; this.pos.set(c.out.x, 0, c.out.z); this.yaw = c.lookYaw;
  };

  P.update = function (dt) {
    const G = this.G, k = this.keys, cols = G.world.colliders, cam = G.camera;
    this.para = Math.max(0, this.para - dt); this.recoil = Math.max(0, this.recoil - dt * 4); this.shake = Math.max(0, this.shake - dt * 1.4);
    if (this.flash.material.opacity > 0) this.flash.material.opacity = Math.max(0, this.flash.material.opacity - dt * 14);
    this.muzzle.intensity = Math.max(0, this.muzzle.intensity - dt * 60);
    this.spot.intensity = this.light && !this.hidden ? 1.9 + (Math.random() < 0.004 ? -2 : 0) : 0; this.lens.visible = this.light;
    this.beam.visible = this.spot.intensity > 1 && G.quality !== 'baja' && G.state === 'play';

    // armario
    if (this.hidden) {
      const c = this.hidden;
      const yr = c.kind === 'bed' ? 0.7 : 0.35;
      this.yaw = Math.max(c.lookYaw - yr, Math.min(c.lookYaw + yr, this.yaw)); this.pitch = Math.max(c.kind === 'bed' ? -0.1 : -0.3, Math.min(c.kind === 'bed' ? 0.12 : 0.25, this.pitch));
      cam.position.set(c.hide.x, c.camY || 1.6, c.hide.z); cam.rotation.set(this.pitch, this.yaw, 0, 'YXZ');
      this.gun.visible = false; this.speedNow = 0; this.sprinting = false;
      return;
    }
    this.gun.visible = true;

    // teclado para mirar (alternativa)
    if (k.ArrowLeft) this.yaw += dt * 2.2; if (k.ArrowRight) this.yaw -= dt * 2.2;
    if (k.ArrowUp) this.pitch += dt * 1.6; if (k.ArrowDown) this.pitch -= dt * 1.6;
    this.pitch = Math.max(-1.45, Math.min(1.45, this.pitch));

    // trepando
    if (this.mantle) {
      const m = this.mantle; m.t += dt / m.dur; const e = Math.min(1, m.t);
      this.pos.x = m.from.x + (m.to.x - m.from.x) * e; this.pos.z = m.from.z + (m.to.z - m.from.z) * e;
      this.pos.y = m.from.y + (m.to.y - m.from.y) * Math.min(1, e * 1.6);
      if (e >= 1) { this.mantle = null; this.vy = 0; this.pressed = {}; }
      this.land = Math.sin(e * Math.PI) * 0.12; this.placeCam(dt, 0); return;
    }

    // movimiento
    this.crouch = !!k.KeyC;
    let ix = 0, iz = 0; if (k.KeyW) iz += 1; if (k.KeyS) iz -= 1; if (k.KeyA) ix -= 1; if (k.KeyD) ix += 1;
    const moving = ix || iz;
    this.sprinting = !!(k.ShiftLeft || k.ShiftRight) && moving && iz > 0 && !this.crouch && this.stamina > 2 && !this.aiming;
    let speed = this.crouch ? 1.6 : this.sprinting ? 5.8 : 3.2; if (this.aiming) speed = Math.min(speed, 2.0);
    if (this.para > 0) speed *= 0.12;
    this.stamina = Math.max(0, Math.min(100, this.stamina + (this.sprinting ? -22 : 14) * dt));
    const len = Math.hypot(ix, iz) || 1; ix /= len; iz /= len;
    const fx = -Math.sin(this.yaw), fz = -Math.cos(this.yaw), rx = Math.cos(this.yaw), rz = -Math.sin(this.yaw);
    const vx = (fx * iz + rx * ix) * speed, vz = (fz * iz + rz * ix) * speed;
    this.speedNow = moving ? speed : 0;
    const head = this.pos.y + (this.crouch ? 1.1 : 1.75);
    const r = TL.collide.move(this.pos.x, this.pos.z, vx * dt, vz * dt, 0.35, this.pos.y, head, cols);
    this.pos.x = r.x; this.pos.z = r.z;

    // vertical
    const sup = TL.collide.support(this.pos.x, this.pos.z, 0.35, this.pos.y, cols);
    if (sup > this.pos.y && sup - this.pos.y < 0.42 && this.vy <= 0) { this.pos.y = sup; }
    if (this.pos.y > sup + 0.001 || this.vy > 0) {
      this.vy -= 18 * dt; this.pos.y += this.vy * dt;
      if (this.pos.y <= sup) {
        const v = -this.vy;
        if (v > 7) G.audio.thud();
        if (v > 3) this.land = Math.min(0.5, v * 0.025);
        if (v > 11 && G.hurt) G.hurt((v - 11) * 9, 'fall');
        this.pos.y = sup; this.vy = 0;
      }
    }
    this.onGround = this.pos.y - sup < 0.02 && this.vy <= 0;

    // saltar / trepar
    if (this.consume('Space') && this.para <= 0) {
      if (!this.tryMantle(cols, false) && this.onGround && this.stamina > 8) { this.vy = 6.0; this.stamina -= 8; }
    } else if (k.Space && !this.onGround && this.para <= 0 && this.vy < 2.5) this.tryMantle(cols, true); // agarrarse en el aire

    // pasos
    if (moving && this.onGround && this.para <= 0) {
      this.stepAcc += speed * dt; const stride = this.sprinting ? 2.3 : this.crouch ? 1.2 : 1.8;
      if (this.stepAcc > stride) {
        this.stepAcc = 0; const wet = G.world.wetAt(this.pos.x, this.pos.z);
        G.audio.step(this.sprinting && !this.shoes, this.pos.z > 24, wet, this.shoes, !wet && !!G.world.buildingAt(this.pos.x, this.pos.z));
        if (wet) { G.world.ripple(this.pos.x + R(-0.2, 0.2), this.pos.z + R(-0.2, 0.2), this.sprinting); this.splashT = G.time; }
      }
      this.bobT += dt * speed * 1.75;
    }

    // rifle
    this.aiming = !!G.mouseRight;
    if (this.reloadT > 0) { this.reloadT -= dt; if (this.reloadT <= 0) { this.loaded = 1; this.reserve--; G.ui.ammo(); } }
    if (this.consume('Fire')) this.fire();
    if (this.consume('KeyR') && this.loaded === 0 && this.reserve > 0 && this.reloadT <= 0) { this.reloadT = 1.5; G.audio.bolt(); }
    if (this.consume('KeyF')) { this.light = !this.light; G.audio.click(true); }

    this.updInspect(dt);
    this.placeCam(dt, moving ? 1 : 0);
  };

  // Trepar: desde el suelo solo cosas bajas (cajas, cercas, ~1.2 m).
  // Para un techo hay que subir a algo, SALTAR y mantener ESPACIO para agarrarse del borde. Cansa.
  P.tryMantle = function (cols, air) {
    if (this.stamina < 22 || this.crouch) return false;
    const fx = -Math.sin(this.yaw), fz = -Math.cos(this.yaw), maxRise = air ? 1.45 : 1.2;
    if (Math.cos(this.pitch) < 0.3) return false;
    for (let dist = 0.45; dist <= 0.95; dist += 0.25) {
      const px = this.pos.x + fx * dist, pz = this.pos.z + fz * dist;
      const column = cols.filter(b => !b.thin && px >= b.minX && px <= b.maxX && pz >= b.minZ && pz <= b.maxZ);
      let top = -1;
      column.forEach(b => { if (b.minY <= this.pos.y + 1.0 && b.maxY > this.pos.y + 0.45) top = Math.max(top, b.maxY); });
      if (top < 0) continue;
      let grew = true; while (grew) { grew = false; column.forEach(b => { if (b.minY <= top + 0.06 && b.maxY > top) { top = b.maxY; grew = true; } }); }
      const rise = top - this.pos.y;
      if (rise >= 0.45 && rise <= maxRise) {
        const tx = this.pos.x + fx * (dist + 0.45), tz = this.pos.z + fz * (dist + 0.45), ty = top;
        // espacio libre arriba
        const blocked = cols.some(b => tx > b.minX - 0.3 && tx < b.maxX + 0.3 && tz > b.minZ - 0.3 && tz < b.maxZ + 0.3 && b.minY < ty + 1.7 && b.maxY > ty + 0.05);
        if (blocked) continue;
        const dur = 0.45 + rise * 0.35 + (air ? 0.3 : 0);
        this.mantle = { t: 0, dur, from: this.pos.clone(), to: new T.Vector3(tx, ty, tz) }; this.stamina -= 10 + rise * 14; this.vy = 0;
        this.G.audio.whoosh(); if (air || rise > 1) this.G.audio.grunt(); return true;
      }
    }
    return false;
  };

  P.fire = function () {
    const G = this.G;
    if (this.hidden || this.reloadT > 0 || this.mantle || this.inspect) return;
    if (this.loaded <= 0) { G.audio.click(false); G.ui.thought(this.reserve > 0 ? 'Está vacío… [R] para recargar.' : 'No me quedan balas.'); return; }
    this.loaded = 0; G.audio.gunshot(); this.recoil = 1; this.shake = Math.max(this.shake, 0.25);
    this.flash.material.opacity = 1; this.muzzle.intensity = 4;
    const fear = G.fear / 100, valor = G.valor / 100;
    const spread = (0.004 + fear * 0.05 * (1 - valor * 0.6)) * (this.aiming ? 0.5 : 1.6);
    const dir = this.fwd(); dir.x += R(-spread, spread); dir.y += R(-spread, spread); dir.z += R(-spread, spread); dir.normalize();
    G.onShot(G.camera.position.clone(), dir);
    G.ui.ammo();
    this.pitch += 0.05;
  };

  // mirar las manos (después de envolverse los brazos): las levanta y las gira de derecha a izquierda
  P.startInspect = function (dur) {
    if (!this.inspHands) {
      const g = new T.Group(), mk = (x) => { const h = new T.Group(); const palm = new T.Mesh(new T.BoxGeometry(0.09, 0.03, 0.1), this.wrapM); h.add(palm);
        for (let i = 0; i < 4; i++) { const f = new T.Mesh(new T.CapsuleGeometry(0.011, 0.045, 3, 6), this.skinM); f.position.set(-0.033 + i * 0.022, 0, -0.075); h.add(f); }
        const arm = new T.Mesh(new T.CylinderGeometry(0.045, 0.055, 0.32, 10), this.wrapM); arm.rotation.x = Math.PI / 2; arm.position.z = 0.2; h.add(arm);
        for (let i = 0; i < 4; i++) { const b = new T.Mesh(new T.TorusGeometry(0.052, 0.006, 4, 12), new T.MeshPhongMaterial({ color: 0x9a9a8a, shininess: 40 })); b.position.z = 0.08 + i * 0.07; h.add(b); }
        h.position.set(x, -0.18, -0.38); g.add(h); return h; };
      this.inspL = mk(-0.13); this.inspR = mk(0.13); g.traverse(m => { if (m.isMesh) m.renderOrder = 6; }); this.G.camera.add(g); this.inspHands = g;
    }
    this.inspect = { t: 0, dur: dur || 3 }; this.inspHands.visible = true;
  };
  P.updInspect = function (dt) {
    const I = this.inspect; if (!I) return; I.t += dt; const k = I.t / I.dur;
    const up = Math.min(1, I.t * 3) * Math.min(1, (I.dur - I.t) * 3);
    this.inspHands.position.y = -0.25 * (1 - up);
    const rot = Math.sin(k * Math.PI * 2) * 0.9;
    this.inspL.rotation.set(0.2, 0, rot + 0.4); this.inspR.rotation.set(0.2, 0, rot - 0.4);
    this.inspL.position.x = -0.13 + Math.sin(k * Math.PI * 2) * 0.04; this.inspR.position.x = 0.13 + Math.sin(k * Math.PI * 2) * 0.04;
    if (I.t >= I.dur) { this.inspect = null; this.inspHands.visible = false; }
  };
  P.placeCam = function (dt, moving) {
    const G = this.G, cam = G.camera;
    const targetEye = this.crouch ? 1.0 : 1.65; this.eye += (targetEye - this.eye) * Math.min(1, dt * 10);
    // balanceo al caminar: sube suave y baja con cada paso, el cuerpo se inclina un poco al lado del pie
    const run = this.sprinting ? 1.5 : this.crouch ? 0.55 : 1;
    this.bobAmp += ((moving && this.onGround ? run : 0) - this.bobAmp) * Math.min(1, dt * 6);
    if (!moving) this.bobT += dt * 1.2 * this.bobAmp;
    const A = this.bobAmp * (this.aiming ? 0.35 : 1);
    const bob = -Math.abs(Math.cos(this.bobT)) * 0.05 * A + 0.025 * A, bobX = Math.sin(this.bobT) * 0.028 * A, roll = Math.sin(this.bobT) * 0.012 * A;
    this.land += (0 - this.land) * Math.min(1, dt * 7);
    const fear = G.fear / 100, t = G.time, scare = Math.max(0, fear - 0.35) / 0.65 * (1 - G.valor / 170);
    // respiración (se ve en la mira) y temblor de manos cuando el miedo sube
    const breathe = Math.sin(t * (1.4 + fear * 2.6)) * (0.004 + fear * 0.01) * (this.aiming ? 0.5 : 1);
    const sway = fear * (1 - G.valor / 160) * 0.01 + (this.aiming ? 0 : 0.0015);
    // temblor natural: mezcla de ondas (no saltos al azar); más fuerte al apuntar que a la cadera
    const tremor = scare * scare * (this.aiming ? 0.016 : 0.006); this.tremT += dt;
    const tt = this.tremT;
    this.trem.x = (Math.sin(tt * 9.1) * 0.5 + Math.sin(tt * 14.3 + 1) * 0.3 + Math.sin(tt * 23.7 + 2) * 0.2) * tremor;
    this.trem.y = (Math.sin(tt * 8.3 + 3) * 0.5 + Math.sin(tt * 15.9) * 0.3 + Math.sin(tt * 21.1 + 4) * 0.2) * tremor;
    const sx = Math.sin(t * 1.7) * sway + this.trem.x, sy = Math.cos(t * 1.3) * sway + breathe + this.trem.y;
    const sh = this.shake * 0.08;
    cam.position.set(this.pos.x + Math.cos(this.yaw) * bobX + R(-sh, sh), this.pos.y + this.eye + bob - this.land + R(-sh, sh), this.pos.z - Math.sin(this.yaw) * bobX);
    cam.rotation.set(this.pitch + sy + this.recoil * 0.06 - this.land * 0.15, this.yaw + sx, roll + this.trem.x * 0.6, 'YXZ');
    // el arma se queda un poco atrás al girar (inercia)
    let dyaw = this.yaw - this.lastYaw; while (dyaw > Math.PI) dyaw -= Math.PI * 2; while (dyaw < -Math.PI) dyaw += Math.PI * 2;
    this.lastYaw = this.yaw; const dp = this.pitch - this.lastPitch; this.lastPitch = this.pitch;
    this.swayX += (Math.max(-0.06, Math.min(0.06, dyaw * 1.5)) - this.swayX) * Math.min(1, dt * 10);
    this.swayY += (Math.max(-0.05, Math.min(0.05, -dp * 1.2)) - this.swayY) * Math.min(1, dt * 10);
    // rifle: cadera / apuntar / recarga
    const g = this.gun, aim = this.aiming && this.reloadT <= 0;
    // apuntar: mira centrada; correr: rifle cruzado y abajo; cadera: relajado
    const sprint = this.sprinting && !aim;
    let tx = aim ? 0 : sprint ? 0.12 : 0.2, ty = aim ? -0.088 : sprint ? -0.3 : -0.2, tz = aim ? -0.3 : sprint ? -0.36 : -0.38;
    if (this.inspect) { tx = 0.25; ty = -0.6; tz = -0.3; }
    const hand = scare * scare * (this.aiming ? 0.004 : 0.0025), hx = Math.sin(tt * 11.7) * hand, hy = Math.sin(tt * 13.3 + 2) * hand;
    g.position.x += (tx + bobX * 0.5 + this.swayX + hx - g.position.x) * Math.min(1, dt * 10);
    g.position.y += (ty + bob * 0.5 + this.swayY + breathe * 0.6 + hy - (this.reloadT > 0 ? 0.08 : 0) - g.position.y) * Math.min(1, dt * 10);
    g.position.z += (tz + this.recoil * 0.09 - g.position.z) * Math.min(1, dt * 18);
    const rz = (this.reloadT > 0 ? 0.45 : 0) + roll * 1.5 + this.swayX * 1.2 + hx * 3 + (sprint ? 0.55 : 0);
    const rx = this.recoil * 0.22 + (sprint ? -0.32 : 0) + hy * 2;
    const ry = sprint ? 0.65 : 0;
    g.rotation.z += (rz - g.rotation.z) * Math.min(1, dt * 10); g.rotation.x += (rx - g.rotation.x) * Math.min(1, dt * 10); g.rotation.y += (ry - g.rotation.y) * Math.min(1, dt * 8);
    this.boltM.rotation.z = 0.6 + (this.reloadT > 0.4 && this.reloadT < 1.2 ? 0.8 : 0);
    const fovT = aim ? 48 : 72; cam.fov += (fovT - cam.fov) * Math.min(1, dt * 10); cam.updateProjectionMatrix();
  };
})();
