// Imágenes reales de las pistas (se llenan con img/hacer-pistas-js.py). Vacío = se usan los dibujos por código.
window.TL = window.TL || {};
TL.CLUE_IMG = TL.CLUE_IMG || {};
