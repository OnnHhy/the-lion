// Todos los sonidos se sintetizan aquí (WebAudio). Sin archivos, sin costo.
(function () {
  function R(a, b) { return a + Math.random() * (b - a); }

  TL.Audio = function () {
    const A = this; let ctx = null;
    A.ready = false;

    A.init = function () {
      if (A.ready) return;
      ctx = A.ctx = new (window.AudioContext || window.webkitAudioContext)();
      A.master = ctx.createGain(); A.master.gain.value = 0.9;
      const comp = ctx.createDynamicsCompressor(); comp.threshold.value = -14; comp.ratio.value = 4;
      A.master.connect(comp); comp.connect(ctx.destination);
      const len = ctx.sampleRate * 2, buf = ctx.createBuffer(1, len, ctx.sampleRate), d = buf.getChannelData(0);
      for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
      A.noise = buf;
      // reverb
      const il = ctx.sampleRate * 2.6, ir = ctx.createBuffer(2, il, ctx.sampleRate);
      for (let c = 0; c < 2; c++) { const ch = ir.getChannelData(c); for (let i = 0; i < il; i++) ch[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / il, 3.2); }
      A.verb = ctx.createConvolver(); A.verb.buffer = ir; A.verbOut = ctx.createGain(); A.verbOut.gain.value = 0.5;
      A.verb.connect(A.verbOut); A.verbOut.connect(A.master);
      A.dist = curve(40); A.distSoft = curve(8);
      startAmbient(); startDrone(); startBreath(); startStrings(); startPresence();
      A.ready = true;
    };
    A.resume = function () { if (ctx && ctx.state !== 'running') ctx.resume(); };

    function curve(k) { const n = 2048, c = new Float32Array(n); for (let i = 0; i < n; i++) { const x = i * 2 / n - 1; c[i] = (1 + k) * x / (1 + k * Math.abs(x)); } return c; }
    function noise(loop) { const s = ctx.createBufferSource(); s.buffer = A.noise; s.loop = !!loop; if (loop) s.loopStart = 0; return s; }
    function gain(v) { const g = ctx.createGain(); g.gain.value = v; return g; }
    function filt(type, f, q) { const b = ctx.createBiquadFilter(); b.type = type; b.frequency.value = f; if (q != null) b.Q.value = q; return b; }
    function osc(type, f) { const o = ctx.createOscillator(); o.type = type; o.frequency.value = f; return o; }
    function out(node, pos, verb) {
      let last = node;
      if (pos) {
        const p = ctx.createPanner(); p.panningModel = 'equalpower'; p.distanceModel = 'inverse'; p.refDistance = 3; p.rolloffFactor = 1.1; p.maxDistance = 80;
        if (p.positionX) { p.positionX.value = pos.x; p.positionY.value = (pos.y || 0) + 1; p.positionZ.value = pos.z; } else p.setPosition(pos.x, (pos.y || 0) + 1, pos.z);
        node.connect(p); last = p;
      }
      last.connect(A.master);
      if (verb) { const s = gain(verb); last.connect(s); s.connect(A.verb); }
    }
    function env(g, t, a, peak, hold, rel) {
      g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(peak, t + a);
      g.gain.setValueAtTime(peak, t + a + hold); g.gain.exponentialRampToValueAtTime(0.0001, t + a + hold + rel);
    }

    A.setListener = function (pos, fwd) {
      if (!ctx) return; const L = ctx.listener;
      if (L.positionX) {
        L.positionX.value = pos.x; L.positionY.value = pos.y; L.positionZ.value = pos.z;
        L.forwardX.value = fwd.x; L.forwardY.value = fwd.y; L.forwardZ.value = fwd.z; L.upX.value = 0; L.upY.value = 1; L.upZ.value = 0;
      } else { L.setPosition(pos.x, pos.y, pos.z); L.setOrientation(fwd.x, fwd.y, fwd.z, 0, 1, 0); }
    };

    // ---------- Ambiente ----------
    let wind, windG, drone, droneG, breathF, breathG;
    function startAmbient() {
      const n = noise(true); const f = filt('lowpass', 420, 0.7); windG = gain(0.09);
      const lfo = osc('sine', 0.06), lg = gain(260); lfo.connect(lg); lg.connect(f.frequency); lfo.start();
      n.connect(f); f.connect(windG); out(windG, null, 0.2); n.start();
      wind = f;
    }
    function startDrone() {
      droneG = gain(0.0001);
      const o1 = osc('sine', 43), o2 = osc('sine', 64.4), o3 = osc('triangle', 87.2), g3 = gain(0.25);
      o1.connect(droneG); o2.connect(droneG); o3.connect(g3); g3.connect(droneG);
      const n = noise(true), nf = filt('lowpass', 120), ng = gain(0.5); n.connect(nf); nf.connect(ng); ng.connect(droneG);
      out(droneG, null, 0.3); o1.start(); o2.start(); o3.start(); n.start();
    }
    function startBreath() {
      const n = noise(true); breathF = filt('bandpass', 900, 1.2); breathG = gain(0.0001);
      n.connect(breathF); breathF.connect(breathG); out(breathG, null, 0.05); n.start();
    }

    // cuerdas de tensión: dos notas que chocan (semitono) y un brillo agudo; suben con el miedo y la cercanía del león
    let strG, strF, strHi;
    function startStrings() {
      strG = gain(0.0001); strF = filt('lowpass', 400, 0.8);
      [[110, 0], [116.54, 4], [164.8, -3], [55, 2]].forEach(f => { const o = osc('sawtooth', f[0]); o.detune.value = f[1]; const lf = osc('sine', 0.13 + Math.random() * 0.1), lg = gain(3); lf.connect(lg); lg.connect(o.detune); o.connect(strF); o.start(); lf.start(); });
      strF.connect(strG); out(strG, null, 0.7);
      strHi = gain(0.0001); [1760, 1864.7].forEach(f => { const o = osc('sine', f), tr = osc('sine', 5.5), tg = gain(0.4); const og = gain(0.5); tr.connect(tg); tg.connect(og.gain); o.connect(og); og.connect(strHi); o.start(); tr.start(); });
      out(strHi, null, 0.9);
    }
    // presencia del león: un ronroneo grave que se siente cuando está cerca en la oscuridad
    let presG, presO;
    function startPresence() {
      presG = gain(0.0001); presO = osc('sawtooth', 32); const lf = osc('sine', 3.2), lg = gain(0.5), am = gain(0.6);
      lf.connect(lg); lg.connect(am.gain); const f = filt('lowpass', 90, 1.5); presO.connect(f); f.connect(am); am.connect(presG); out(presG, null, 0.1); presO.start(); lf.start();
    }
    // sonidos lejanos del pueblo
    function owl() { const t = ctx.currentTime, p = R(-1, 1); [0, 0.45, 0.62].forEach((d, i) => { const o = osc('sine', i ? 380 : 410), g = gain(0.0001), sp = ctx.createStereoPanner ? ctx.createStereoPanner() : null; o.frequency.setValueAtTime(i ? 390 : 420, t + d); o.frequency.linearRampToValueAtTime(i ? 350 : 380, t + d + 0.3); o.connect(g); if (sp) { sp.pan.value = p; g.connect(sp); out(sp, null, 0.6); } else out(g, null, 0.6); env(g, t + d, 0.05, 0.025, 0.12, 0.15); o.start(t + d); o.stop(t + d + 0.5); }); }
    function dog() { const t = ctx.currentTime, o = osc('sawtooth', 520), f = filt('bandpass', 900, 3), g = gain(0.0001), v = osc('sine', 6), vg = gain(12); v.connect(vg); vg.connect(o.frequency);
      o.frequency.setValueAtTime(480, t); o.frequency.linearRampToValueAtTime(620, t + 0.8); o.frequency.linearRampToValueAtTime(430, t + 2.6); o.connect(f); f.connect(g); out(g, null, 1.2); env(g, t, 0.4, 0.012, 1.6, 0.8); o.start(t); v.start(t); o.stop(t + 3.2); v.stop(t + 3.2); }
    function gust() { const t = ctx.currentTime, n = noise(), f = filt('bandpass', 500, 0.6), g = gain(0.0001); f.frequency.setValueAtTime(300, t); f.frequency.linearRampToValueAtTime(900, t + 1.5); f.frequency.linearRampToValueAtTime(350, t + 3.5); n.connect(f); f.connect(g); out(g, null, 0.4); env(g, t, 1.2, 0.07, 0.8, 1.6); n.start(t, 0, 4); }
    function shutter() { const t = ctx.currentTime, n = noise(), f = filt('bandpass', R(600, 1100), 2), g = gain(0.0001); n.connect(f); f.connect(g); out(g, null, 1.0); env(g, t, 0.003, R(0.06, 0.14), 0.02, 0.2); n.start(t, R(0, 1), 0.3); }
    function chains() { const t = ctx.currentTime; for (let i = 0; i < 6; i++) { const s0 = t + i * R(0.05, 0.12), o = osc('triangle', R(2200, 3600)), g = gain(0.0001); o.connect(g); out(g, null, 0.9); env(g, s0, 0.002, 0.012, 0.01, 0.15); o.start(s0); o.stop(s0 + 0.2); } }

    let nextCricket = 0, nextCreak = 6, nextFrog = 2, breathPhase = 0, nextBeat = 0, nextEvent = 12;
    // fear 0..1, covering bool, nearSwamp 0..1, ex = { lion: distancia al león (o 99), inside: dentro de casa, exert: cansancio 0..1 }
    A.update = function (dt, t, fear, covering, nearSwamp, girl, ex) {
      if (!A.ready) return; const now = ctx.currentTime; ex = ex || {};
      const ld = ex.lion == null ? 99 : ex.lion, near = Math.max(0, 1 - ld / 25);
      strG.gain.setTargetAtTime(0.0001 + Math.pow(Math.max(fear, near), 2) * 0.05, now, 0.8); strF.frequency.setTargetAtTime(300 + fear * 1400, now, 0.5);
      strHi.gain.setTargetAtTime(0.0001 + Math.pow(near, 3) * 0.02, now, 0.6);
      presG.gain.setTargetAtTime(0.0001 + Math.pow(Math.max(0, 1 - ld / 12), 2) * 0.35, now, 0.3);
      // eventos lejanos: más silencio cuando hay miedo
      if (t > nextEvent) { nextEvent = t + R(10, 22) * (1 + fear * 1.5); if (fear < 0.75) { const r = Math.random(); if (r < 0.25) owl(); else if (r < 0.45) dog(); else if (r < 0.7) gust(); else if (r < 0.88) shutter(); else chains(); } }
      droneG.gain.setTargetAtTime(0.0001 + fear * fear * 0.22, now, 0.4);
      // respiración
      breathPhase += dt * (0.28 + fear * 0.85);
      const cyc = Math.sin(breathPhase * Math.PI * 2);
      breathPhase += dt * (ex.exert || 0) * 0.6;
      let amp = (0.012 + fear * 0.09 + (ex.exert || 0) * 0.07) * (0.35 + 0.65 * Math.max(0, cyc));
      if (covering) amp *= 0.12;
      breathF.frequency.setTargetAtTime(girl ? 1700 : (covering ? 380 : (cyc > 0 ? 1000 : 700)), now, 0.1);
      breathG.gain.setTargetAtTime(Math.max(0.0001, amp), now, 0.08);
      // latido
      if (fear > 0.22 && t >= nextBeat) {
        A.heartbeat(0.12 + fear * 0.75);
        nextBeat = t + 60 / (58 + fear * 95);
      }
      // grillos (se callan con miedo)
      if (t > nextCricket) { nextCricket = t + R(0.3, 1.4); if (Math.random() > fear * 1.2) cricket(); }
      if (t > nextFrog) { nextFrog = t + R(1.5, 4); if (nearSwamp > 0.1 && Math.random() > fear) frog(nearSwamp); }
      if (t > nextCreak) { nextCreak = t + R(9, 22); creak(); }
    };
    function cricket() {
      const t = ctx.currentTime, p = ctx.createStereoPanner ? ctx.createStereoPanner() : null, g = gain(0.0001), f = R(4200, 5200), o = osc('sine', f);
      o.connect(g); if (p) { p.pan.value = R(-1, 1); g.connect(p); out(p); } else out(g);
      const v = R(0.006, 0.02); for (let i = 0; i < 3; i++) { const s = t + i * 0.07; g.gain.setValueAtTime(0.0001, s); g.gain.exponentialRampToValueAtTime(v, s + 0.01); g.gain.exponentialRampToValueAtTime(0.0001, s + 0.05); }
      o.start(t); o.stop(t + 0.3);
    }
    function frog(v) {
      const t = ctx.currentTime, o = osc('square', R(90, 140)), f = filt('lowpass', 500), g = gain(0.0001);
      o.connect(f); f.connect(g); const p = ctx.createStereoPanner ? ctx.createStereoPanner() : null; if (p) { p.pan.value = R(-1, 1); g.connect(p); out(p, null, 0.2); } else out(g);
      for (let i = 0; i < 3; i++) { const s = t + i * 0.12; g.gain.setValueAtTime(0.0001, s); g.gain.exponentialRampToValueAtTime(0.03 * v, s + 0.02); g.gain.exponentialRampToValueAtTime(0.0001, s + 0.09); }
      o.start(t); o.stop(t + 0.5);
    }
    function creak() {
      const t = ctx.currentTime, o = osc('sawtooth', R(110, 180)), f = filt('bandpass', R(500, 900), 6), g = gain(0.0001);
      o.frequency.linearRampToValueAtTime(R(80, 240), t + 0.8); o.connect(f); f.connect(g); out(g, null, 0.6);
      env(g, t, 0.15, R(0.02, 0.05), 0.4, 0.4); o.start(t); o.stop(t + 1.2);
    }

    // ---------- Efectos ----------
    A.heartbeat = function (v) {
      const t = ctx.currentTime;
      [0, 0.24].forEach((d, i) => {
        const o = osc('sine', 62), g = gain(0.0001); o.frequency.setValueAtTime(70, t + d); o.frequency.exponentialRampToValueAtTime(38, t + d + 0.14);
        o.connect(g); out(g); env(g, t + d, 0.012, v * (i ? 0.6 : 1), 0.02, 0.15); o.start(t + d); o.stop(t + d + 0.3);
      });
    };
    A.step = function (loud, mud, splash, soft, wood) {
      const t = ctx.currentTime;
      if (splash) { A.splash(null, loud ? 1 : 0.7); return; }
      if (wood) { // tablas huecas: golpe sordo + crujido a veces
        const k = (loud ? 1.3 : 1) * (soft ? 0.35 : 1);
        const o = osc('sine', R(120, 160)), g = gain(0.0001); o.frequency.exponentialRampToValueAtTime(70, t + 0.12); o.connect(g); out(g, null, 0.25); env(g, t, 0.004, 0.22 * k, 0.01, 0.12); o.start(t); o.stop(t + 0.2);
        const n = noise(), f = filt('bandpass', R(250, 400), 1.2), ng = gain(0.0001); n.connect(f); f.connect(ng); out(ng, null, 0.25); env(ng, t, 0.004, 0.12 * k, 0.01, 0.08); n.start(t, R(0, 1.5), 0.15);
        if (Math.random() < 0.25 && !soft) { const c = osc('sawtooth', R(140, 200)), cf = filt('bandpass', R(600, 900), 8), cg = gain(0.0001); c.frequency.linearRampToValueAtTime(R(110, 250), t + 0.35); c.connect(cf); cf.connect(cg); out(cg, null, 0.3); env(cg, t + 0.05, 0.05, 0.03, 0.15, 0.15); c.start(t); c.stop(t + 0.45); }
        return;
      }
      const n = noise(), f = filt('lowpass', mud ? 450 : R(600, 900)), g = gain(0.0001);
      n.connect(f); f.connect(g); out(g, null, 0.05); env(g, t, 0.01, (loud ? 0.16 : 0.08) * R(0.8, 1.1) * (soft ? 0.35 : 1), 0.02, 0.09);
      n.start(t, R(0, 1.5), 0.2);
      if (mud) { const o = osc('sine', R(300, 500)), g2 = gain(0.0001); o.frequency.exponentialRampToValueAtTime(120, t + 0.1); o.connect(g2); out(g2); env(g2, t + 0.02, 0.01, 0.02, 0.01, 0.06); o.start(t); o.stop(t + 0.2); }
    };
    // pisar un charco: golpe de agua + gotas que caen
    A.splash = function (pos, v) {
      const t = ctx.currentTime; v = v || 1;
      const n = noise(), f = filt('bandpass', R(900, 1300), 0.8), g = gain(0.0001);
      f.frequency.setValueAtTime(R(1500, 2000), t); f.frequency.exponentialRampToValueAtTime(500, t + 0.18);
      n.connect(f); f.connect(g); out(g, pos, 0.15); env(g, t, 0.006, 0.22 * v, 0.03, 0.16); n.start(t, R(0, 1.5), 0.3);
      const lo = noise(), lf = filt('lowpass', 380), lg = gain(0.0001); lo.connect(lf); lf.connect(lg); out(lg, pos); env(lg, t, 0.005, 0.2 * v, 0.02, 0.1); lo.start(t, R(0, 1.5), 0.2);
      const drops = 3 + Math.floor(Math.random() * 4);
      for (let i = 0; i < drops; i++) {
        const s = t + 0.05 + Math.random() * 0.28, o = osc('sine', R(700, 1600)), og = gain(0.0001);
        o.frequency.setValueAtTime(R(500, 900), s); o.frequency.exponentialRampToValueAtTime(R(1400, 2600), s + 0.04);
        o.connect(og); out(og, pos); env(og, s, 0.003, 0.035 * v, 0.005, 0.04); o.start(s); o.stop(s + 0.08);
      }
    };
    // pisada del león: almohadilla pesada + grava (se oye cuando se acerca)
    A.lionStep = function (pos, w, run, wet) {
      const t = ctx.currentTime; w = w || 1;
      if (wet) { A.splash(pos, 0.9 * w); }
      const o = osc('sine', 75), g = gain(0.0001); o.frequency.exponentialRampToValueAtTime(32, t + 0.14); o.connect(g); out(g, pos, 0.1);
      env(g, t, 0.006, (run ? 0.55 : 0.32) * w, 0.01, 0.16); o.start(t); o.stop(t + 0.25);
      const n = noise(), f = filt('lowpass', run ? 700 : 480), ng = gain(0.0001); n.connect(f); f.connect(ng); out(ng, pos, 0.05);
      env(ng, t, 0.008, (run ? 0.28 : 0.16) * w, 0.02, 0.12); n.start(t, R(0, 1.5), 0.2);
      if (Math.random() < 0.5) { const c = noise(), cf = filt('bandpass', R(1800, 3000), 3), cg = gain(0.0001); c.connect(cf); cf.connect(cg); out(cg, pos); env(cg, t + 0.03, 0.004, 0.05 * w, 0.01, 0.05); c.start(t + 0.03, R(0, 1.5), 0.1); }
    };
    // respiración del león (jadeo al correr, resoplido al caminar)
    A.lionBreath = function (pos, run, big) {
      const t = ctx.currentTime, n = noise(), f = filt('bandpass', run ? 600 : 380, 1.2), g = gain(0.0001);
      const o = osc('sawtooth', big ? 52 : 68), of = filt('lowpass', 220), og = gain(0.0001);
      n.connect(f); f.connect(g); out(g, pos, 0.2); o.connect(of); of.connect(og); out(og, pos);
      const d = run ? 0.22 : 0.55; env(g, t, d * 0.3, run ? 0.25 : 0.14, d * 0.3, d * 0.5); env(og, t, d * 0.3, run ? 0.12 : 0.06, d * 0.2, d * 0.5);
      n.start(t, R(0, 1.5), d + 0.3); o.start(t); o.stop(t + d + 0.3);
    };
    // zarpazo + quejido del jugador
    A.hurt = function () {
      const t = ctx.currentTime;
      const n = noise(), f = filt('highpass', 1200), g = gain(0.0001); n.connect(f); f.connect(g); out(g, null, 0.3);
      f.frequency.setValueAtTime(3500, t); f.frequency.exponentialRampToValueAtTime(800, t + 0.15); env(g, t, 0.003, 0.5, 0.02, 0.12); n.start(t, R(0, 1), 0.25);
      const o = osc('sawtooth', 210), of = filt('bandpass', 800, 2), og = gain(0.0001); o.frequency.setValueAtTime(240, t + 0.08); o.frequency.exponentialRampToValueAtTime(130, t + 0.5);
      o.connect(of); of.connect(og); out(og, null, 0.2); env(og, t + 0.08, 0.02, 0.18, 0.12, 0.3); o.start(t + 0.08); o.stop(t + 0.7);
      A.thud();
    };
    A.grunt = function () {
      const t = ctx.currentTime, o = osc('sawtooth', 150), f = filt('bandpass', 700, 2.5), g = gain(0.0001); o.frequency.exponentialRampToValueAtTime(105, t + 0.25);
      const n = noise(), nf = filt('bandpass', 900, 1), ng = gain(0.0001); n.connect(nf); nf.connect(ng); out(ng);
      o.connect(f); f.connect(g); out(g); env(g, t, 0.03, 0.07, 0.08, 0.15); env(ng, t, 0.03, 0.08, 0.1, 0.15); o.start(t); o.stop(t + 0.4); n.start(t, R(0, 1), 0.4);
    };
    A.heal = function () {
      const t = ctx.currentTime;
      [0, 0.12, 0.26].forEach(d => { const n = noise(), f = filt('bandpass', R(2500, 4000), 2), g = gain(0.0001); n.connect(f); f.connect(g); out(g); env(g, t + d, 0.01, 0.07, 0.04, 0.08); n.start(t + d, R(0, 1.5), 0.2); });
    };
    A.ui = function (hi) {
      if (!ctx) return; const t = ctx.currentTime, o = osc('sine', hi ? 880 : 520), g = gain(0.0001); o.connect(g); out(g, null, 0.2);
      o.frequency.exponentialRampToValueAtTime(hi ? 1320 : 390, t + 0.08); env(g, t, 0.005, 0.05, 0.01, 0.1); o.start(t); o.stop(t + 0.15);
    };
    A.growl = function (pos, big, dur) {
      const t = ctx.currentTime; dur = dur || R(1.4, 2.4);
      const o = osc('sawtooth', big ? 46 : 60), o2 = osc('sawtooth', big ? 47.3 : 61.8);
      const lfo = osc('sine', R(7, 12)), lg = gain(big ? 5 : 7); lfo.connect(lg); lg.connect(o.frequency); lg.connect(o2.frequency);
      const n = noise(), nf = filt('lowpass', 300), ng = gain(0.6); n.connect(nf); nf.connect(ng);
      const sh = ctx.createWaveShaper(); sh.curve = A.distSoft; const lp = filt('lowpass', big ? 600 : 850), g = gain(0.0001);
      o.connect(sh); o2.connect(sh); ng.connect(sh); sh.connect(lp); lp.connect(g); out(g, pos, 0.4);
      env(g, t, 0.3, big ? 0.55 : 0.4, dur - 0.6, 0.4);
      [o, o2, lfo].forEach(x => { x.start(t); x.stop(t + dur + 0.1); }); n.start(t, R(0, 1), dur + 0.1);
    };
    A.roar = function (pos, big) {
      const t = ctx.currentTime, dur = big ? 3.2 : 2.5;
      const f0 = big ? 125 : 165, f1 = big ? 52 : 72;
      const o = osc('sawtooth', f0), o2 = osc('sawtooth', f0 * 1.04), o3 = osc('square', f0 / 2);
      [o, o2, o3].forEach((x, i) => { x.frequency.setValueAtTime(x.frequency.value * 0.8, t); x.frequency.linearRampToValueAtTime(x.frequency.value, t + 0.35); x.frequency.exponentialRampToValueAtTime(f1 * (i === 1 ? 1.04 : i === 2 ? 0.5 : 1), t + dur); });
      const n = noise(), bp = filt('bandpass', 1400, 0.8); bp.frequency.setValueAtTime(1600, t); bp.frequency.exponentialRampToValueAtTime(350, t + dur);
      const ng = gain(1.2); n.connect(bp); bp.connect(ng);
      const sh = ctx.createWaveShaper(); sh.curve = A.dist; const lp = filt('lowpass', 2200), g = gain(0.0001);
      o.connect(sh); o2.connect(sh); o3.connect(sh); ng.connect(sh); sh.connect(lp); lp.connect(g); out(g, pos, 0.9);
      g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(big ? 0.95 : 0.8, t + 0.25);
      g.gain.setValueAtTime(big ? 0.9 : 0.75, t + dur * 0.45); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
      [o, o2, o3].forEach(x => { x.start(t); x.stop(t + dur + 0.05); }); n.start(t, 0, dur + 0.05);
    };
    A.sniff = function (pos) {
      const t = ctx.currentTime;
      for (let i = 0; i < 3; i++) {
        const n = noise(), f = filt('bandpass', R(1500, 2600), 1.5), g = gain(0.0001); n.connect(f); f.connect(g); out(g, pos, 0.1);
        const s = t + i * R(0.16, 0.22); env(g, s, 0.03, 0.35, 0.03, 0.08); n.start(s, R(0, 1.5), 0.2);
      }
    };
    A.gunshot = function () {
      const t = ctx.currentTime, n = noise(), f = filt('lowpass', 9000), g = gain(0.0001);
      f.frequency.setValueAtTime(9000, t); f.frequency.exponentialRampToValueAtTime(260, t + 0.45);
      n.connect(f); f.connect(g); out(g, null, 1.4); env(g, t, 0.002, 1.0, 0.02, 0.5); n.start(t, 0, 0.7);
      const o = osc('sine', 90), g2 = gain(0.0001); o.frequency.exponentialRampToValueAtTime(35, t + 0.25); o.connect(g2); out(g2); env(g2, t, 0.003, 0.9, 0.02, 0.3); o.start(t); o.stop(t + 0.4);
      const dl = ctx.createDelay(); dl.delayTime.value = 0.42; const fb = gain(0.28), dg = gain(0.25), df = filt('lowpass', 900);
      g.connect(dl); dl.connect(df); df.connect(fb); fb.connect(dl); df.connect(dg); dg.connect(A.master);
    };
    A.click = function (hi) {
      const t = ctx.currentTime, o = osc('square', hi ? 2400 : 1400), g = gain(0.0001), f = filt('highpass', 800);
      o.connect(f); f.connect(g); out(g); env(g, t, 0.002, 0.06, 0.005, 0.03); o.start(t); o.stop(t + 0.06);
    };
    A.bolt = function () {
      const t = ctx.currentTime;
      [0, 0.18, 0.55, 0.75].forEach((d, i) => { const n = noise(), f = filt('bandpass', i % 2 ? 2600 : 1800, 3), g = gain(0.0001); n.connect(f); f.connect(g); out(g); env(g, t + d, 0.004, 0.18, 0.01, 0.06); n.start(t + d, R(0, 1.5), 0.1); });
    };
    A.sting = function () {
      const t = ctx.currentTime, g = gain(0.0001), lp = filt('lowpass', 300);
      lp.frequency.setValueAtTime(300, t); lp.frequency.exponentialRampToValueAtTime(3000, t + 0.12); lp.frequency.exponentialRampToValueAtTime(600, t + 2.5);
      [110, 116.5, 155.6, 233].forEach(f => { const o = osc('sawtooth', f); o.connect(lp); o.start(t); o.stop(t + 3); });
      [1900, 2013].forEach(f => { const o = osc('sine', f), og = gain(0.08); o.connect(og); og.connect(g); o.start(t); o.stop(t + 2.5); });
      lp.connect(g); out(g, null, 0.8); env(g, t, 0.02, 0.32, 0.25, 2.3);
      const n = noise(), nf = filt('lowpass', 200), ng = gain(0.0001); n.connect(nf); nf.connect(ng); out(ng); env(ng, t, 0.005, 0.9, 0.05, 0.6); n.start(t, 0, 0.8);
    };
    A.smash = function () {
      const t = ctx.currentTime;
      const n = noise(), f = filt('lowpass', 2500), g = gain(0.0001); n.connect(f); f.connect(g); out(g, null, 0.6); env(g, t, 0.003, 1.0, 0.1, 0.6); n.start(t, 0, 1);
      for (let i = 0; i < 5; i++) { const s = t + i * R(0.05, 0.12), o = osc('triangle', R(70, 160)), og = gain(0.0001); o.frequency.exponentialRampToValueAtTime(40, s + 0.2); o.connect(og); out(og); env(og, s, 0.003, 0.5, 0.01, 0.2); o.start(s); o.stop(s + 0.3); }
    };
    A.gasp = function () {
      const t = ctx.currentTime, n = noise(), f = filt('bandpass', 1300, 1), g = gain(0.0001); n.connect(f); f.connect(g); out(g, null, 0.2);
      f.frequency.setValueAtTime(900, t); f.frequency.linearRampToValueAtTime(1700, t + 0.35); env(g, t, 0.05, 0.4, 0.15, 0.3); n.start(t, 0, 0.7);
    };
    A.page = function () {
      const t = ctx.currentTime, n = noise(), f = filt('highpass', 2500), g = gain(0.0001); n.connect(f); f.connect(g); out(g); env(g, t, 0.02, 0.06, 0.05, 0.12); n.start(t, R(0, 1), 0.3);
    };
    A.thud = function () {
      const t = ctx.currentTime, o = osc('sine', 110), g = gain(0.0001); o.frequency.exponentialRampToValueAtTime(30, t + 0.3); o.connect(g); out(g, null, 0.3); env(g, t, 0.005, 0.8, 0.02, 0.35); o.start(t); o.stop(t + 0.5);
    };
    A.whoosh = function () {
      const t = ctx.currentTime, n = noise(), f = filt('bandpass', 400, 1), g = gain(0.0001); f.frequency.exponentialRampToValueAtTime(2500, t + 0.4); n.connect(f); f.connect(g); out(g, null, 0.3); env(g, t, 0.2, 0.3, 0.05, 0.2); n.start(t, 0, 0.6);
    };
    // compañero en línea: disparo lejano, pasos y señal
    A.shotFar = function (pos) {
      const t = ctx.currentTime, n = noise(), f = filt('lowpass', 5000), g = gain(0.0001);
      f.frequency.setValueAtTime(5000, t); f.frequency.exponentialRampToValueAtTime(220, t + 0.5);
      n.connect(f); f.connect(g); out(g, pos, 1.6); env(g, t, 0.003, 1.6, 0.02, 0.6); n.start(t, 0, 0.8);
    };
    A.stepAt = function (pos, wet) {
      if (wet) { A.splash(pos, 0.6); return; }
      const t = ctx.currentTime, n = noise(), f = filt('lowpass', R(500, 800)), g = gain(0.0001);
      n.connect(f); f.connect(g); out(g, pos, 0.05); env(g, t, 0.01, 0.35, 0.02, 0.09); n.start(t, R(0, 1.5), 0.2);
    };
    A.ping = function (pos) {
      const t = ctx.currentTime;
      [0, 0.12].forEach((d, i) => { const o = osc('sine', i ? 1320 : 990), g = gain(0.0001); o.connect(g); out(g, pos, 0.3); env(g, t + d, 0.005, 0.12, 0.03, 0.25); o.start(t + d); o.stop(t + d + 0.4); });
    };
    // puertas: rechinido al abrir, golpe cuando el león la tumba
    A.door = function (pos, open) {
      const t = ctx.currentTime, o = osc('sawtooth', open ? R(170, 220) : R(120, 160)), f = filt('bandpass', R(700, 1100), 7), g = gain(0.0001);
      o.frequency.linearRampToValueAtTime(open ? R(260, 340) : R(90, 120), t + 0.6); o.connect(f); f.connect(g); out(g, pos, 0.4);
      env(g, t, 0.08, 0.06, 0.35, 0.25); o.start(t); o.stop(t + 0.9);
      if (!open) { const n = noise(), nf = filt('lowpass', 500), ng = gain(0.0001); n.connect(nf); nf.connect(ng); out(ng, pos, 0.3); env(ng, t + 0.55, 0.005, 0.3, 0.02, 0.15); n.start(t + 0.55, 0, 0.3); }
    };
    A.doorBash = function (pos) {
      const t = ctx.currentTime, n = noise(), f = filt('lowpass', 1800), g = gain(0.0001); n.connect(f); f.connect(g); out(g, pos, 0.6); env(g, t, 0.003, 0.9, 0.05, 0.4); n.start(t, 0, 0.6);
      const o = osc('triangle', 80), og = gain(0.0001); o.frequency.exponentialRampToValueAtTime(35, t + 0.3); o.connect(og); out(og, pos, 0.3); env(og, t, 0.003, 0.8, 0.02, 0.3); o.start(t); o.stop(t + 0.4);
    };
    // tela y cinta (inventario)
    A.cloth = function () {
      const t = ctx.currentTime; for (let i = 0; i < 4; i++) { const n = noise(), f = filt('bandpass', R(1500, 3000), 0.8), g = gain(0.0001); n.connect(f); f.connect(g); out(g); const s0 = t + i * R(0.12, 0.22); env(g, s0, 0.04, 0.05, 0.06, 0.1); n.start(s0, R(0, 1.5), 0.3); }
    };
    A.tape = function () {
      const t = ctx.currentTime, n = noise(), f = filt('highpass', 2500), g = gain(0.0001); n.connect(f); f.connect(g); out(g);
      g.gain.setValueAtTime(0.0001, t); for (let i = 0; i < 14; i++) g.gain.setValueAtTime(i % 2 ? 0.02 : 0.09, t + i * 0.035); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.6); n.start(t, R(0, 1.5), 0.7);
    };
    A.bite = function () {
      const t = ctx.currentTime, n = noise(), f = filt('lowpass', 900), g = gain(0.0001); n.connect(f); f.connect(g); out(g, null, 0.3); env(g, t, 0.005, 0.8, 0.15, 0.4); n.start(t, 0, 0.8);
      [0, 0.06].forEach(d => { const c = noise(), cf = filt('bandpass', 2400, 4), cg = gain(0.0001); c.connect(cf); cf.connect(cg); out(cg); env(cg, t + d, 0.002, 0.5, 0.01, 0.05); c.start(t + d, R(0, 1), 0.1); });
      A.roar(null, false);
    };
    A.hitLion = function (pos) {
      const t = ctx.currentTime, n = noise(), f = filt('bandpass', 700, 1.5), g = gain(0.0001); n.connect(f); f.connect(g); out(g, pos, 0.2); env(g, t, 0.002, 0.6, 0.02, 0.12); n.start(t, R(0, 1), 0.2);
    };
    // motor de la camioneta: devuelve un control para subir/bajar revoluciones
    A.engine = function (pos) {
      const t = ctx.currentTime, o = osc('sawtooth', 34), o2 = osc('square', 17), f = filt('lowpass', 260, 2), g = gain(0.0001), lfo = osc('sine', 9), lg = gain(5);
      lfo.connect(lg); lg.connect(o.frequency); const n = noise(true), nf = filt('bandpass', 180, 1), ng = gain(0.5); n.connect(nf); nf.connect(ng); ng.connect(f);
      o.connect(f); const g2 = gain(0.5); o2.connect(g2); g2.connect(f); f.connect(g);
      const p = ctx.createPanner(); p.panningModel = 'equalpower'; p.distanceModel = 'inverse'; p.refDistance = 4; p.rolloffFactor = 1;
      g.connect(p); p.connect(A.master); const vs = gain(0.25); p.connect(vs); vs.connect(A.verb);
      g.gain.setTargetAtTime(0.32, t, 0.4); [o, o2, lfo].forEach(x => x.start(t)); n.start(t);
      return {
        set(rpm, x, z) { const now = ctx.currentTime; o.frequency.setTargetAtTime(30 + rpm * 40, now, 0.2); o2.frequency.setTargetAtTime(15 + rpm * 20, now, 0.2); f.frequency.setTargetAtTime(220 + rpm * 500, now, 0.2);
          if (p.positionX) { p.positionX.value = x; p.positionY.value = 1; p.positionZ.value = z; } else p.setPosition(x, 1, z); },
        stop() { const now = ctx.currentTime; o.frequency.setTargetAtTime(14, now, 0.15); g.gain.setTargetAtTime(0.0001, now + 0.25, 0.15); [o, o2, lfo].forEach(x => x.stop(now + 1.4)); n.stop(now + 1.4); }
      };
    };
    A.carDoor = function (open) {
      const t = ctx.currentTime;
      if (open) { const o = osc('sawtooth', 300), f = filt('bandpass', 900, 6), g = gain(0.0001); o.frequency.linearRampToValueAtTime(220, t + 0.25); o.connect(f); f.connect(g); out(g, null, 0.3); env(g, t, 0.02, 0.05, 0.15, 0.1); o.start(t); o.stop(t + 0.4); }
      else { const n = noise(), f = filt('lowpass', 900), g = gain(0.0001); n.connect(f); f.connect(g); out(g, null, 0.5); env(g, t, 0.003, 0.7, 0.03, 0.25); n.start(t, 0, 0.4); const o = osc('sine', 90), og = gain(0.0001); o.frequency.exponentialRampToValueAtTime(40, t + 0.2); o.connect(og); out(og); env(og, t, 0.003, 0.6, 0.02, 0.2); o.start(t); o.stop(t + 0.3); }
    };
    A.silenceAll = function (on) { if (A.ready) A.master.gain.setTargetAtTime(on ? 0.0001 : 0.9, ctx.currentTime, 0.3); };
  };
})();
