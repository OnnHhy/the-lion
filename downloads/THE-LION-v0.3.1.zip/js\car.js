// Camioneta vieja del investigador (llega por el terraplén del pantano y queda estacionada con los faros prendidos)
(function () {
  const T = THREE;
  function ph(c, sh, sp) { return new T.MeshPhongMaterial({ color: c, shininess: sh || 30, specular: sp || 0x333333 }); }
  TL.makeCar = function (scene) {
    const g = new T.Group(), body = ph(0x3a4a42, 60, 0x556660), dark = ph(0x15171a, 20), chrome = ph(0x9a9a94, 120, 0xcccccc), glass = ph(0x0a1016, 140, 0x8899aa), rust = ph(0x5a3a26, 8);
    const add = (m, x, y, z) => { m.position.set(x, y, z); g.add(m); return m; };
    // chasis y caja (el auto mira hacia -z)
    add(new T.Mesh(new T.BoxGeometry(1.7, 0.18, 4.4), dark), 0, 0.42, 0);
    const hood = add(new T.Mesh(new T.BoxGeometry(1.25, 0.42, 1.5), body), 0, 0.82, -1.35);
    hood.geometry.translate(0, 0, 0); const hp = hood.geometry.attributes.position; for (let i = 0; i < hp.count; i++) if (hp.getY(i) > 0 && hp.getZ(i) < 0) hp.setY(i, hp.getY(i) - 0.08); hood.geometry.computeVertexNormals();
    add(new T.Mesh(new T.BoxGeometry(1.6, 0.85, 1.25), body), 0, 1.0, -0.05); // cabina
    add(new T.Mesh(new T.BoxGeometry(1.5, 0.08, 1.3), body), 0, 1.47, -0.05); // techo
    add(new T.Mesh(new T.BoxGeometry(1.42, 0.42, 0.04), glass), 0, 1.2, -0.69).rotation.x = -0.25; // parabrisas
    [-1, 1].forEach(s => add(new T.Mesh(new T.BoxGeometry(0.04, 0.36, 0.9), glass), s * 0.81, 1.18, -0.05));
    add(new T.Mesh(new T.BoxGeometry(1.7, 0.5, 1.7), rust), 0, 0.78, 1.35); // caja de carga
    add(new T.Mesh(new T.BoxGeometry(1.5, 0.45, 1.6), dark), 0, 0.84, 1.35);
    // guardabarros redondeados
    const fg = new T.CylinderGeometry(0.46, 0.46, 0.32, 16, 1, false, 0, Math.PI); fg.rotateZ(Math.PI / 2); fg.rotateX(Math.PI / 2);
    [[-0.78, -1.35], [0.78, -1.35], [-0.86, 1.4], [0.86, 1.4]].forEach(p => add(new T.Mesh(fg, body), p[0], 0.5, p[1]));
    // ruedas
    const wheels = [], tg = new T.CylinderGeometry(0.36, 0.36, 0.24, 18); tg.rotateZ(Math.PI / 2);
    [[-0.8, -1.35], [0.8, -1.35], [-0.84, 1.4], [0.84, 1.4]].forEach(p => {
      const w = new T.Group(); w.position.set(p[0], 0.36, p[1]); g.add(w);
      w.add(new T.Mesh(tg, dark)); const hub = new T.Mesh(new T.CylinderGeometry(0.14, 0.14, 0.26, 10), chrome); hub.rotation.z = Math.PI / 2; w.add(hub);
      const sp = new T.Mesh(new T.BoxGeometry(0.27, 0.05, 0.5), dark); w.add(sp); wheels.push(w);
    });
    // parrilla, parachoques y faros redondos
    add(new T.Mesh(new T.BoxGeometry(0.8, 0.36, 0.06), chrome), 0, 0.75, -2.1);
    add(new T.Mesh(new T.BoxGeometry(1.8, 0.1, 0.12), chrome), 0, 0.5, -2.22);
    add(new T.Mesh(new T.BoxGeometry(1.8, 0.1, 0.12), chrome), 0, 0.5, 2.22);
    const lampM = new T.MeshBasicMaterial({ color: 0xfff0c0, fog: false }), glowM = new T.SpriteMaterial({ map: TL.tex.glow(), color: 0xfff0c8, transparent: true, opacity: 0.9, blending: T.AdditiveBlending, depthWrite: false, fog: false });
    const glows = [];
    [-0.6, 0.6].forEach(x => {
      const ring = add(new T.Mesh(new T.CylinderGeometry(0.15, 0.15, 0.12, 14), chrome), x, 0.92, -2.02); ring.rotation.x = Math.PI / 2;
      const l = add(new T.Mesh(new T.CircleGeometry(0.12, 14), lampM), x, 0.92, -2.09); l.rotation.y = Math.PI;
      const gl = new T.Sprite(glowM); gl.position.set(x, 0.92, -2.15); gl.scale.set(1.4, 1.4, 1); g.add(gl); glows.push(gl);
    });
    const beamG = new T.ConeGeometry(1.8, 9, 18, 1, true); beamG.translate(0, -4.5, 0);
    // haz suave: más fuerte cerca del faro y en los bordes, se desvanece (igual que la linterna)
    const beamM = new T.ShaderMaterial({ uniforms: { uOp: { value: 0.07 } }, transparent: true, depthWrite: false, blending: T.AdditiveBlending, side: T.DoubleSide, fog: false,
      vertexShader: 'varying vec3 vN; varying vec3 vP; varying float vY; void main(){ vN = normalize(normalMatrix * normal); vec4 mv = modelViewMatrix * vec4(position,1.0); vP = mv.xyz; vY = uv.y; gl_Position = projectionMatrix * mv; }',
      fragmentShader: 'uniform float uOp; varying vec3 vN; varying vec3 vP; varying float vY; void main(){ float f = abs(dot(vN, normalize(-vP))); float a = pow(f, 2.5) * pow(vY, 2.4) * uOp * smoothstep(0.5, 4.0, length(vP)); gl_FragColor = vec4(vec3(1.0, 0.94, 0.8) * a, 1.0); }' });
    const beams = [-0.6, 0.6].map(x => { const b = new T.Mesh(beamG, beamM); b.rotation.x = Math.PI / 2 + 0.06; b.position.set(x, 0.92, -2.1); g.add(b); return b; });
    // luz real de los faros (una sola para las dos)
    const spot = new T.SpotLight(0xfff0d0, 0, 34, 0.55, 0.5, 1.2); spot.position.set(0, 0.95, -2.1); spot.target.position.set(0, 0, -16); g.add(spot); g.add(spot.target);
    g.traverse(m => { if (m.isMesh && m.material !== beamM && m.material !== lampM) { m.castShadow = true; m.receiveShadow = true; } });
    scene.add(g);
    const car = { g, wheels, spot, beams, glows, lightsOn: false };
    car.lights = function (on) { car.lightsOn = on; spot.intensity = on ? 2.2 : 0; beams.forEach(b => b.visible = on); glows.forEach(gl => gl.visible = on); lampM.color.set(on ? 0xfff0c0 : 0x3a3830); };
    car.lights(false);
    return car;
  };
})();
