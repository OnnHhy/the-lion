// El león: modelo low-poly + cerebro (cazar, buscar, olfatear armario, perseguir, huir)
(function () {
  const T = THREE;
  function R(a, b) { return a + Math.random() * (b - a); }
  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }

  function shade(hex, k) { const c = new T.Color(hex); if (k < 0) c.multiplyScalar(1 + k); else c.lerp(new T.Color(0xf0dcb0), k); return c.getHex(); }

  // León v2: cuerpo con volumen, pelaje, melena de mechones, mandíbula, ojos que reflejan la linterna
  TL.makeLion = function (o) {
    const g = new T.Group();
    const furT = TL.tex.fur(o.body, shade(o.body, -0.4), shade(o.body, 0.12));
    const maneT = TL.tex.fur(o.mane, shade(o.mane, -0.45), shade(o.mane, 0.2), true);
    const mb = new T.MeshPhongMaterial({ map: furT, bumpMap: furT, bumpScale: 0.015, shininess: 5, specular: 0x141414 });
    const mm = new T.MeshPhongMaterial({ map: maneT, bumpMap: maneT, bumpScale: 0.03, shininess: 3, specular: 0x0a0a0a, flatShading: true });
    const dark = new T.MeshPhongMaterial({ color: 0x120a08, shininess: 60, specular: 0x333333 });
    function sph(r, sx, sy, sz, x, y, z, m, parent) { const s = new T.Mesh(new T.SphereGeometry(r, 16, 12), m || mb); s.scale.set(sx, sy, sz); s.position.set(x, y, z); (parent || g).add(s); return s; }

    const body = new T.Group(); g.add(body);
    // torso de una sola pieza: esfera deformada con perfil de león (pecho ancho, cintura, cadera)
    const tg = new T.SphereGeometry(1, 40, 26), tp = tg.attributes.position, v = new T.Vector3();
    const gs = (x, m, s) => Math.exp(-((x - m) * (x - m)) / s);
    for (let i = 0; i < tp.count; i++) {
      v.fromBufferAttribute(tp, i); const t = v.y, k = Math.sqrt(Math.max(0, 1 - t * t));
      const nx = k > 1e-4 ? v.x / k : 0, ny = k > 1e-4 ? v.z / k : 0;
      const prof = 0.4 + 0.1 * gs(t, 0.5, 0.09) - 0.06 * gs(t, -0.05, 0.12) + 0.075 * gs(t, -0.6, 0.06);
      const end = Math.pow(k, 0.55);
      let X = nx * prof * end * 0.9, Y = ny * prof * end * 1.08;
      if (Y < 0) Y *= 1 + 0.18 * gs(t, 0.45, 0.15) - 0.12 * gs(t, -0.15, 0.1);
      tp.setXYZ(i, -X, Y + 1.08 + 0.07 * t, t * 1.18);
    }
    tg.computeVertexNormals();
    const torso = new T.Mesh(tg, mb); body.add(torso);
    furT.repeat.set(3, 2);
    const neck = new T.Mesh(new T.CylinderGeometry(0.3, 0.44, 0.7, 18), mb); neck.position.set(0, 1.36, 0.95); neck.rotation.x = 0.95; body.add(neck);

    const head = new T.Group(); head.position.set(0, 1.52, 1.2); head.scale.setScalar(1.1); g.add(head);
    sph(0.29, 1, 0.92, 1.05, 0, 0.04, 0.05, mb, head);         // cráneo
    sph(0.19, 1.35, 0.45, 0.8, 0, 0.16, 0.2, mb, head);        // frente
    sph(0.17, 1.15, 0.85, 1.35, 0, -0.08, 0.36, mb, head);     // hocico
    [-1, 1].forEach(s => sph(0.1, 1, 0.9, 1, s * 0.085, -0.12, 0.45, mb, head)); // bigoteras
    const nose = new T.Mesh(new T.ConeGeometry(0.07, 0.07, 3), dark); nose.rotation.set(Math.PI / 2, 0, Math.PI); nose.position.set(0, -0.01, 0.56); head.add(nose);
    const jaw = new T.Group(); jaw.position.set(0, -0.14, 0.16); head.add(jaw);
    sph(0.11, 1.0, 0.5, 1.6, 0, -0.07, 0.18, mb, jaw);
    const mouth = new T.Mesh(new T.BoxGeometry(0.16, 0.05, 0.25), new T.MeshLambertMaterial({ color: 0x3a0a0a })); mouth.position.set(0, -0.03, 0.17); jaw.add(mouth);
    [-1, 1].forEach(s => { const f = new T.Mesh(new T.ConeGeometry(0.018, 0.07, 5), new T.MeshPhongMaterial({ color: 0xd8ccb0, shininess: 40 })); f.position.set(s * 0.06, -0.02, 0.3); f.rotation.x = Math.PI; jaw.add(f); });
    [-1, 1].forEach(s => sph(0.075, 1, 1, 0.45, s * 0.19, 0.27, -0.02, mb, head)); // orejas
    // ojos con reflejo (tapetum) — brillan más cuando la linterna los apunta
    const eyeM = new T.MeshBasicMaterial({ color: o.eye || 0xffd34a, fog: false });
    const glowM = new T.SpriteMaterial({ map: TL.tex.glow(), color: o.eye || 0xffd34a, fog: false, transparent: true, opacity: 0.3, blending: T.AdditiveBlending, depthWrite: false });
    const glows = [];
    [-1, 1].forEach(s => {
      const e = new T.Mesh(new T.SphereGeometry(0.034, 8, 6), eyeM); e.position.set(s * 0.11, 0.07, 0.29); e.scale.set(1, 0.7, 1); head.add(e);
      const lid = sph(0.045, 1.3, 0.5, 0.8, s * 0.11, 0.1, 0.28, mb, head); lid.rotation.z = -s * 0.3;
      const gl = new T.Sprite(glowM); gl.position.set(s * 0.11, 0.07, 0.33); gl.scale.set(0.2, 0.2, 1); head.add(gl); glows.push(gl);
    });
    // melena: núcleo + mechones unidos en una sola malla
    const tufts = [], cone = new T.ConeGeometry(0.16, 1, 6), up = new T.Vector3(0, 1, 0), mx = new T.Matrix4(), q = new T.Quaternion();
    const nT = o.scars ? 80 : 60, lenK = o.scars ? 1.3 : 1, sweep = new T.Vector3(0, -0.45, -0.85);
    for (let i = 0; i < nT; i++) {
      const n = new T.Vector3(R(-1, 1), R(-1, 1), R(-1, 0.3)); if (n.length() < 0.3) continue; n.normalize();
      if (n.z > 0.05 && Math.abs(n.x) < 0.55 && n.y > -0.45) continue; // dejar la cara libre
      const d = n.clone().multiplyScalar(0.55).add(sweep).normalize();   // mechones peinados hacia atrás y abajo
      const len = R(0.2, 0.38) * lenK * (n.y < -0.3 ? 1.35 : 1);
      q.setFromUnitVectors(up, d);
      const base = n.clone().multiplyScalar(0.38).add(new T.Vector3(0, -0.02, -0.14));
      mx.compose(base.addScaledVector(d, len * 0.35), q, new T.Vector3(R(0.8, 1.3), len, R(0.6, 1.0)));
      tufts.push({ geo: cone, matrix: mx.clone() });
    }
    const mg = new T.IcosahedronGeometry(0.44, 3), mp = mg.attributes.position, u = new T.Vector3();
    const seed = Math.random() * 10;
    for (let i = 0; i < mp.count; i++) {
      u.fromBufferAttribute(mp, i).normalize();
      const nz = Math.sin(u.x * 9 + seed) * Math.sin(u.y * 8 + seed * 2) * Math.sin(u.z * 10) * 0.5 + 0.5;
      let rr = 0.44 * (1 + nz * 0.3 + (u.z < 0 ? -u.z * 0.18 : 0));
      const p = u.clone().multiplyScalar(rr); p.x *= 1.15; p.y *= u.y < 0 ? 1.45 : 1.15; p.z = p.z * 1.0 - 0.1;
      mp.setXYZ(i, p.x, p.y, p.z);
    }
    mg.computeVertexNormals();
    const maneCore = new T.Mesh(mg, mm); maneCore.position.set(0, -0.04, -0.16); head.add(maneCore);
    const maneT2 = new T.Mesh(TL.mergeGeos(tufts), mm); head.add(maneT2);
    // patas
    const legs = [];
    function legGeo(front) {
      const lg = new T.CylinderGeometry(1, 1, 1, 14, 12, true), lp = lg.attributes.position, w = new T.Vector3();
      for (let i = 0; i < lp.count; i++) {
        w.fromBufferAttribute(lp, i); const s = 0.5 - w.y; // 0 arriba, 1 abajo
        const r = front ? (0.2 - 0.12 * Math.pow(s, 0.7) + 0.035 * gs(s, 0.95, 0.004)) : (0.22 - 0.145 * Math.pow(s, 0.6) + 0.035 * gs(s, 0.95, 0.004));
        let z = front ? 0.04 * Math.sin(Math.PI * s) : -0.08 * Math.sin(Math.PI * s * 1.1) + 0.04 * s;
        if (s > 0.9) z += (s - 0.9) * 0.9;
        lp.setXYZ(i, w.x * r, -s * 1.08, w.z * r * (s > 0.9 ? 1.4 : 1) + z);
      }
      lg.computeVertexNormals(); return lg;
    }
    const fLeg = legGeo(true), hLeg = legGeo(false);
    [[-0.25, 0.62, 0, 1], [0.25, 0.62, Math.PI, 1], [-0.27, -0.72, Math.PI, 0], [0.27, -0.72, 0, 0]].forEach(l => {
      const piv = new T.Group(); piv.position.set(l[0], 1.08, l[1]); g.add(piv);
      piv.add(new T.Mesh(l[3] ? fLeg : hLeg, mb));
      sph(l[3] ? 0.2 : 0.22, 0.8, l[3] ? 1.4 : 1.75, l[3] ? 1.05 : 1.3, l[0] > 0 ? -0.03 : 0.03, 0.0, l[3] ? 0 : -0.03, mb, piv);
      sph(l[3] ? 0.075 : 0.08, 1.2, 0.7, 1.6, 0, -1.04, 0.1, mb, piv);
      piv.userData.off = l[2]; piv.userData.front = l[3]; legs.push(piv);
    });
    // cola en 3 segmentos
    const tail = new T.Group(); tail.position.set(0, 1.2, -1.05); g.add(tail); const segs = [];
    let parent = tail;
    for (let i = 0; i < 3; i++) { const sg = new T.Group(); if (i) sg.position.y = -0.33; parent.add(sg); const c = new T.Mesh(new T.CylinderGeometry(0.035 - i * 0.006, 0.05 - i * 0.008, 0.34, 6), mb); c.position.y = -0.17; sg.add(c); segs.push(sg); parent = sg; }
    sph(0.07, 1, 1.5, 1, 0, -0.4, 0, mm, parent);
    tail.rotation.x = 0.45;
    if (o.scars) {
      const sm = new T.MeshLambertMaterial({ color: 0x9a7a6a });
      for (let i = 0; i < 14; i++) { const s = new T.Mesh(new T.BoxGeometry(0.018, 0.02, R(0.22, 0.5)), sm); const a = R(-1.2, 1.2); s.position.set(Math.sin(a) * 0.43, 1.05 + Math.cos(a) * 0.38, R(-0.9, 0.6)); s.rotation.set(R(-.5, .5), R(-.5, .5), a); body.add(s); }
      [[0.1, 0.12, 0.33, 0.4], [-0.14, 0.02, 0.3, -0.3]].forEach(f => { const fs = new T.Mesh(new T.BoxGeometry(0.015, 0.2, 0.015), sm); fs.position.set(f[0], f[1], f[2]); fs.rotation.z = f[3]; head.add(fs); });
      const torn = new T.Mesh(new T.BoxGeometry(0.03, 0.05, 0.05), new T.MeshLambertMaterial({ color: 0x3a1a12 })); torn.position.set(0.2, 0.33, -0.02); head.add(torn);
    }
    g.traverse(m => { if (m.isMesh) { m.castShadow = true; } });
    g.scale.setScalar(o.scale || 1);
    return { group: g, head, jaw, legs, tail, tailSegs: segs, body, glows, glowM };
  };

  TL.Lion = function (G, opts) {
    this.G = G; this.o = opts; this.m = TL.makeLion(opts); this.group = this.m.group;
    G.scene.add(this.group); this.group.visible = false;
    this.pos = new T.Vector3(); this.heading = 0; this.speed = 0; this.state = 'off'; this.path = []; this.pause = 0;
    this.phase = 0; this.t = 0; this.b = null; this.lastSeen = -99; this.hits = 0; this.nextSniff = 0;
    this.roarAnim = 0; this.sniffAnim = 0; this.moveSpeed = 3; this.scale = opts.scale || 1;
    this.vel = 0; this.animSpd = 0; this.cyc = 0; this.lastU = [0, 0, 0, 0]; this.turnRate = 0; this.lastHeading = 0; this.crouchY = 0;
    this.nextBreath = 0; this.nextRumble = 0; this.recT = 0;
  };
  const L = TL.Lion.prototype;
  // dificultad: 0 al inicio, 1 con todas las pistas (más rápido, ve más lejos, olfatea más tiempo)
  function D(G) { return G.diff ? G.diff() : 0; }
  // multijugador: el león puede cazar a cualquiera de los jugadores
  function PLS(G) { return G.players ? G.players() : [G.player]; }
  function noiseOf(G, pl) { return pl === G.player ? G.breath.noise : (pl.noise || 0); }
  L.pl = function () {
    const list = PLS(this.G);
    if (this.tgt && list.indexOf(this.tgt) >= 0) return this.tgt;
    let best = this.G.player, bd = 1e9; list.forEach(p => { const d = this.dist(p.pos); if (d < bd) { bd = d; best = p; } });
    return (this.tgt = best);
  };
  L.minDist = function (x, z) { let m = 1e9; PLS(this.G).forEach(p => { m = Math.min(m, Math.hypot(x - p.pos.x, z - p.pos.z)); }); return m === 1e9 ? 99 : m; };

  L.place = function (x, z, h) { this.pos.set(x, 0, z); this.heading = this.lastHeading = h || 0; this.vel = 0; this.group.visible = true; this.sync(); };
  L.off = function () { this.state = 'off'; this.group.visible = false; this.path = []; this.watch = null; if (this.G.onLionGone) this.G.onLionGone(); };
  L.active = function () { return this.state !== 'off'; };
  L.goPath = function (pts, speed) { this.path = pts.map(p => ({ x: p.x, z: p.z, pause: p.pause || 0 })); this.moveSpeed = speed; this.pause = 0; };
  L.dist = function (p) { return Math.hypot(p.x - this.pos.x, p.z - this.pos.z); };
  L.turnTo = function (target, dt, rate) { let a = target - this.heading; while (a > Math.PI) a -= Math.PI * 2; while (a < -Math.PI) a += Math.PI * 2; this.heading += a * Math.min(1, dt * (rate || 6)); };
  L.moveDir = function (dx, dz, speed, dt) {
    // acelera y frena como un animal pesado (no arranca de golpe)
    this.vel += (speed - this.vel) * Math.min(1, dt * (speed > this.vel ? 2.2 : 5));
    const v = this.vel;
    const r = TL.collide.move(this.pos.x, this.pos.z, dx * v * dt, dz * v * dt, 0.55, 0, 1.3, this.G.world.colliders);
    this.pos.x = r.x; this.pos.z = r.z; this.speed = v; this._moved = true;
  };
  L.step = function (dt) {
    if (this.pause > 0) { this.pause -= dt; this.speed = 0; this.sniffAnim = 0.3; return !this.path.length && this.pause <= 0; }
    if (!this.path.length) { this.speed = 0; return true; }
    const p = this.path[0], dx = p.x - this.pos.x, dz = p.z - this.pos.z, d = Math.hypot(dx, dz);
    if (d < 0.45) {
      this.path.shift();
      if (p.pause) { this.pause = p.pause; this.G.audio.sniff(this.pos); }
      return !this.path.length && !p.pause;
    }
    this.turnTo(Math.atan2(dx, dz), dt); this.moveDir(dx / d, dz / d, this.moveSpeed, dt); return false;
  };
  // ruta por la calle y puertas
  L.route = function (tx, tz) {
    const W = this.G.world, lb = W.buildingAt(this.pos.x, this.pos.z), tb = W.buildingAt(tx, tz), pts = [];
    let cur = { x: this.pos.x, z: this.pos.z };
    if (lb && lb !== tb) { pts.push(lb.doorIn, lb.doorOut); cur = lb.doorOut; }
    if (!lb || lb !== tb) {
      const end = tb ? tb.doorOut : { x: tx, z: tz };
      const blocked = TL.collide.segmentBlocked(cur.x, cur.z, end.x, end.z, 1.0, W.colliders);
      if (W.streetPath && (blocked || Math.hypot(end.x - cur.x, end.z - cur.z) > 24)) W.streetPath(cur.x, cur.z, end.x, end.z).forEach(p => pts.push(p));
      else if (!W.streetPath && (Math.abs(cur.x) > 4.5 || Math.abs(end.x) > 4.5)) pts.push({ x: clamp(cur.x, -4, 4), z: cur.z }, { x: clamp(end.x, -4, 4), z: end.z });
      if (tb) pts.push(tb.doorOut, tb.doorIn);
    }
    pts.push({ x: tx, z: tz });
    return pts;
  };

  L.perceive = function () {
    const list = PLS(this.G), cur = this.pl();
    if (this.perceiveOne(cur)) return true;
    for (const p of list) if (p !== cur && this.perceiveOne(p)) { this.tgt = p; return true; }
    return false;
  };
  L.perceiveOne = function (pl) {
    const G = this.G; if (!pl || pl.hidden || (pl === G.player && G.state !== 'play')) return false;
    if (pl.pos.y > 2.2 && G.time - (this.prowlEnd || -99) < 25) return false;
    const dx = pl.pos.x - this.pos.x, dz = pl.pos.z - this.pos.z, d = Math.hypot(dx, dz);
    if (d > (pl.light ? 40 : 28)) return false;
    const y = pl.pos.y > 2 ? pl.pos.y + 1.0 : 1.1;
    const los = !TL.collide.segmentBlocked(this.pos.x, this.pos.z, pl.pos.x, pl.pos.z, y, G.world.colliders);
    const noise = pl.noiseRadius();
    if (d < noise && (los || d < noise * 0.55)) return true;
    const dot = (dx * Math.sin(this.heading) + dz * Math.cos(this.heading)) / (d || 1);
    if (dot < 0.2) return false;
    let sight = (pl.crouch ? 7 : 12) + D(G) * 5; if (pl.light) sight += 18; if (pl.pos.y > 2) sight = Math.min(sight, pl.light ? 16 : 11);
    return d < sight && los;
  };

  // ----- Órdenes -----
  L.hunt = function (b, who) {
    this.tgt = who || this.G.player;
    const G = this.G;
    const sp = G.world.spawns.filter(s => this.minDist(s.x, s.z) > 16)
      .sort((a, c) => Math.hypot(a.x - b.doorOut.x, a.z - b.doorOut.z) - Math.hypot(c.x - b.doorOut.x, c.z - b.doorOut.z));
    const s = sp.length ? sp[Math.random() < 0.7 ? 0 : Math.min(1, sp.length - 1)] : G.world.spawns[0];
    this.place(s.x, s.z, 0); this.b = b; this.hits = 0;
    const inner = b.pts.slice().sort(() => Math.random() - 0.5).slice(0, 2 + (Math.random() < 0.5 ? 1 : 0)).map(p => ({ x: p.x, z: p.z, pause: R(1.2, 2.2) }));
    const pts = this.route(b.doorIn.x, b.doorIn.z).concat(inner);
    this.goPath(pts, 4.0 + D(G) * 1.3); this.state = 'hunt';
    G.audio.growl(this.pos, false, 2.2); G.audio.growl(null, false, 1.6);
  };
  L.ambient = function () {
    const far = this.G.world.spawns.filter(s => this.minDist(s.x, s.z) > 22);
    if (far.length < 2) return false;
    far.sort(() => Math.random() - 0.5);
    this.place(far[0].x, far[0].z, 0); this.goPath(this.route(far[1].x, far[1].z), 2.8); this.state = 'ambient';
    this.G.audio.growl(this.pos, false, 1.8); return true;
  };
  L.leave = function (watch) {
    const G = this.G, pl = this.pl();
    const sp = G.world.spawns.slice().sort((a, b) => this.minDist(b.x, b.z) - this.minDist(a.x, a.z))[0];
    this.goPath(this.route(sp.x, sp.z), 3.2); this.state = 'leave';
    this.watch = watch ? pl.hidden : null; this.leftAt = G.time;
  };
  L.startChase = function () {
    this.state = 'windup'; this.windT = 0.9; this.roarAnim = 1.2;
    this.G.audio.roar(this.pos, false); this.G.onRoar(this.pos, false, true);
  };
  L.flee = function () {
    const G = this.G;
    const sp = G.world.spawns.slice().sort((a, b) => this.minDist(b.x, b.z) - this.minDist(a.x, a.z))[0];
    this.goPath(this.route(sp.x, sp.z), 8.5); this.state = 'flee';
  };
  L.smash = function (c) {
    this.state = 'smash'; this.smashT = 0.55; this.target = c; this.roarAnim = 1;
    this.G.audio.smash(); this.G.audio.roar(this.pos, false); c.destroy();
  };
  L.onHit = function () {
    this.hits++; this.state = 'stagger'; this.stagT = 0.7; this.roarAnim = 1;
    this.G.audio.roar(this.pos, false);
  };
  L.hitSpheres = function () {
    const s = this.scale, fx = Math.sin(this.heading), fz = Math.cos(this.heading);
    return [
      { c: new T.Vector3(this.pos.x - fx * 0.1 * s, 1.0 * s, this.pos.z - fz * 0.1 * s), r: 0.75 * s },
      { c: new T.Vector3(this.pos.x + fx * 1.15 * s, 1.4 * s, this.pos.z + fz * 1.15 * s), r: 0.5 * s }
    ];
  };

  L.update = function (dt) {
    if (this.state === 'off') return;
    const G = this.G; let pl = this.pl(); this.t += dt; this._moved = false;
    // se le escucha respirar y gruñir bajito cuando está cerca
    const dl = this.minDist(this.pos.x, this.pos.z);
    if (this.group.visible && dl < 30 && this.t > this.nextBreath) {
      const run = this.vel > 4.5; G.audio.lionBreath(this.pos, run, this.scale > 1.2);
      this.nextBreath = this.t + (run ? R(0.4, 0.6) : R(1.6, 2.8));
    }
    if (this.group.visible && dl < 40 && this.t > this.nextRumble && ['hunt', 'leave', 'ambient', 'prowl'].indexOf(this.state) >= 0) {
      G.audio.growl(this.pos, this.scale > 1.2, R(1.0, 1.6)); this.nextRumble = this.t + R(7, 13) * (1 - D(G) * 0.35);
    }
    // vigilante: si se atasca, salta el punto o desaparece en la niebla
    this.wdT = (this.wdT || 0) + dt;
    if (this.wdT > 3) {
      const moved = this.wdPos ? Math.hypot(this.pos.x - this.wdPos.x, this.pos.z - this.wdPos.z) : 99;
      const walking = this.path.length && this.pause <= 0 && ['ambient', 'leave', 'flee', 'hunt', 'return', 'closet', 'track'].indexOf(this.state) >= 0;
      if (walking && moved < 0.6) {
        if (['ambient', 'leave', 'flee'].indexOf(this.state) >= 0 && dl > 12) { this.off(); return; }
        this.path.shift();
      }
      this.wdT = 0; this.wdPos = { x: this.pos.x, z: this.pos.z };
    }
    switch (this.state) {
      case 'ambient':
        if (this.step(dt)) { this.off(); break; }
        if (PLS(G).some(p => !p.hidden && this.dist(p.pos) < 14)) { this.roarAnim = 1; G.audio.growl(this.pos, false, 1); this.flee(); }
        break;
      case 'hunt':
        if (this.perceive()) { this.lastSeen = G.time; this.startChase(); break; }
        if (this.step(dt)) {
          const hid = PLS(G).find(p => p.hidden && p.hidden.b === this.b && !p.hidden.destroyed);
          if (hid) { this.tgt = pl = hid; }
          if (hid) {
            this.state = 'closet'; this.target = pl.hidden; this.goPath(this.route(pl.hidden.front.x, pl.hidden.front.z), 2.4);
            this.closetT = 0; this.closetDur = R(6, 8.5) + D(G) * 3;
          } else this.leave(false);
        }
        break;
      case 'closet': {
        const c = this.target;
        if (!pl.hidden) { this.lastSeen = G.time; this.startChase(); break; }
        if (this.path.length) { this.step(dt); break; }
        this.turnTo(Math.atan2(c.x - this.pos.x, c.z - this.pos.z), dt); this.speed = 0;
        this.closetT += dt; this.sniffAnim = 0.4;
        if (G.time > this.nextSniff) { G.audio.sniff(this.pos); this.nextSniff = G.time + R(0.8, 1.5); }
        if (noiseOf(G, pl) > 55 - D(G) * 15) { G.caughtReason = 'breath'; this.smash(c); break; }
        if (this.closetT > this.closetDur) { this.roarAnim = 1.2; G.audio.roar(this.pos, false); G.onRoar(this.pos, false); this.leave(true); G.onLionLeftCloset(); }
        break;
      }
      case 'leave':
        if (this.perceive()) { this.lastSeen = G.time; this.startChase(); break; }
        const stayer = this.watch && PLS(G).find(p => p.hidden === this.watch);
        if (stayer && G.time - this.leftAt > 9 - D(G) * 3.5) {
          this.tgt = pl = stayer;
          this.state = 'return'; this.reason = 'stayed'; this.target = this.watch; this.goPath(this.route(this.watch.front.x, this.watch.front.z), 6.5);
          G.audio.growl(this.pos, false, 1.2); break;
        }
        if (this.step(dt)) this.off();
        break;
      case 'return':
        if (!pl.hidden) { this.lastSeen = G.time; this.startChase(); break; }
        if (this.step(dt)) { G.caughtReason = this.reason || 'stayed'; this.smash(this.target); }
        break;
      case 'windup':
        this.windT -= dt; this.speed = 0;
        this.turnTo(Math.atan2(pl.pos.x - this.pos.x, pl.pos.z - this.pos.z), dt, 8);
        if (this.windT <= 0) { this.state = 'chase'; }
        break;
      case 'chase': this.updChase(dt); break;
      case 'track': {
        // te perdió de vista pero sigue tu rastro (olfato): no se rinde hasta que te escondas en una casa
        if (this.perceive()) { this.lastSeen = G.time; this.state = 'chase'; G.audio.growl(this.pos, this.scale > 1.2, 0.9); break; }
        if (pl.hidden || pl.pos.y > 2.2) { this.updChase(dt); break; }
        this.trackT -= dt;
        if (this.trackT <= 0 || !this.path.length) { this.trackT = 1.4; this.goPath(this.route(pl.pos.x, pl.pos.z), 4.4 + D(G) * 1.1); }
        if (this.dist(pl.pos) < 3.2) { this.lastSeen = G.time; this.state = 'chase'; break; }
        if (G.time > this.nextSniff) { G.audio.sniff(this.pos); this.nextSniff = G.time + R(1.5, 2.5); this.sniffAnim = 0.5; }
        this.step(dt);
        break;
      }
      case 'prowl': {
        this.prowlT += dt;
        const a = this.prowlT * 0.6, tx = pl.pos.x + Math.cos(a) * 3, tz = pl.pos.z + Math.sin(a) * 3;
        const dx = tx - this.pos.x, dz = tz - this.pos.z, d = Math.hypot(dx, dz);
        if (d > 0.5) { this.turnTo(Math.atan2(dx, dz), dt); this.moveDir(dx / d, dz / d, 2.6, dt); } else this.speed = 0;
        if (pl.pos.y < 1.2 && !pl.hidden) { this.lastSeen = G.time; this.state = 'chase'; break; }
        if (this.prowlT > 4 && !this.prowlRoared) { this.prowlRoared = true; this.roarAnim = 1.2; G.audio.roar(this.pos, false); G.onRoar(this.pos, false); }
        if (this.prowlT > 26) { this.prowlEnd = G.time; this.leave(false); }
        break;
      }
      case 'stagger':
        this.stagT -= dt; this.speed = 0; if (this.stagT <= 0) this.flee(); break;
      case 'flee':
        if (this.step(dt)) this.off(); break;
      case 'smash':
        this.smashT -= dt; if (this.smashT <= 0) { if (G.lionAttack) G.lionAttack(this, G.caughtReason || 'closet'); else { this.state = 'idle'; G.caught(G.caughtReason || 'closet'); } } break;
      case 'recover': {
        // después del zarpazo retrocede un poco, te mira y vuelve a cargar
        this.recT -= dt; this.turnTo(Math.atan2(pl.pos.x - this.pos.x, pl.pos.z - this.pos.z), dt, 5);
        const dx = this.pos.x - pl.pos.x, dz = this.pos.z - pl.pos.z, d = Math.hypot(dx, dz) || 1;
        if (d < 4.5) this.moveDir(dx / d, dz / d, 1.6, dt); else this.speed = 0;
        if (this.recT <= 0) { this.lastSeen = G.time; if (pl.hidden) this.leave(false); else this.state = 'chase'; }
        break;
      }
      case 'pin':
        // te tiene en el suelo (forcejeo)
        this.speed = 0; this.vel = 0; this.pinT -= dt; this.turnTo(Math.atan2(pl.pos.x - this.pos.x, pl.pos.z - this.pos.z), dt, 4);
        if (this.pinT <= 0) { this.state = 'recover'; this.recT = 1.5; }
        break;
      case 'pounce': case 'idle': case 'statue':
        this.speed = 0; break;
    }
    if (!this._moved) this.vel *= Math.max(0, 1 - dt * 6);
    // tumba puertas cerradas a su paso
    if (this.group.visible && this.vel > 0.5 && G.world.doors) for (const d of G.world.doors) {
      if (!d.open && Math.hypot(d.x - this.pos.x, d.z - this.pos.z) < 1.9) { d.setOpen(true, true); d.bashT = 0.3; G.audio.doorBash(d); if (G.onDoorBash) G.onDoorBash(d); }
    }
    this.animate(dt); this.sync();
  };

  L.updChase = function (dt) {
    const G = this.G, pl = this.pl();
    if (this.perceive() || (!pl.hidden && this.dist(pl.pos) < 3.5)) this.lastSeen = G.time;
    if (pl.hidden) {
      if (pl.hiddenAt - this.lastSeen < 0.9) { this.state = 'return'; this.reason = 'seen'; this.target = pl.hidden; this.goPath(this.route(pl.hidden.front.x, pl.hidden.front.z), 6.5); }
      else { const b = G.world.buildingAt(pl.hidden.x, pl.hidden.z); if (b) { this.b = b; this.state = 'hunt'; this.goPath(this.route(b.doorIn.x, b.doorIn.z).concat(b.pts.map(p => ({ x: p.x, z: p.z, pause: 1.4 }))), 3.2); } else this.leave(false); }
      return;
    }
    if (pl.pos.y > 2.2) { this.state = 'prowl'; this.prowlT = 0; this.prowlRoared = false; return; }
    if (G.time - this.lastSeen > 2.5) { this.state = 'track'; this.trackT = 0; return; }
    const W = G.world, pb = W.buildingAt(pl.pos.x, pl.pos.z), lb = W.buildingAt(this.pos.x, this.pos.z);
    let t = { x: pl.pos.x, z: pl.pos.z };
    if (pb && pb !== lb) { const dO = Math.hypot(this.pos.x - pb.doorOut.x, this.pos.z - pb.doorOut.z); t = dO > 1.0 && !this.passedOut ? pb.doorOut : pb.doorIn; if (dO <= 1.0) this.passedOut = true; }
    else if (lb && pb !== lb) { const dI = Math.hypot(this.pos.x - lb.doorIn.x, this.pos.z - lb.doorIn.z); t = dI > 1.0 && !this.passedIn ? lb.doorIn : lb.doorOut; if (dI <= 1.0) this.passedIn = true; }
    else { this.passedOut = this.passedIn = false; }
    const dx = t.x - this.pos.x, dz = t.z - this.pos.z, d = Math.hypot(dx, dz) || 1;
    this.turnTo(Math.atan2(dx, dz), dt, 7); this.moveDir(dx / d, dz / d, 6.6 + D(G) * 0.9, dt);
    if (this.dist(pl.pos) < 2.3 && Math.abs(pl.pos.y) < 1.3) { if (G.lionAttack) G.lionAttack(this, 'pounce'); else { this.state = 'pounce'; G.caught('pounce'); } }
  };

  L.animate = function (dt) {
    const m = this.m, sc = this.scale;
    this.animSpd += (this.speed - this.animSpd) * Math.min(1, dt * 6);
    const sp = this.animSpd, run = clamp((sp - 3.8) / 2.6, 0, 1), mov = clamp(sp / 1.2, 0, 1);
    // giro: el cuerpo se inclina y la cabeza mira hacia donde gira
    let dh = this.heading - this.lastHeading; while (dh > Math.PI) dh -= Math.PI * 2; while (dh < -Math.PI) dh += Math.PI * 2;
    this.lastHeading = this.heading; this.turnRate += ((dt > 0 ? dh / dt : 0) - this.turnRate) * Math.min(1, dt * 6);
    // ciclo de paso: largo de zancada según paso o galope
    const stride = (2.0 + run * 1.8) * sc;
    if (sp > 0.05) this.cyc = (this.cyc + dt * sp / stride) % 1;
    // caminar: trasera izq, delantera izq, trasera der, delantera der. Galope: delanteras juntas, traseras juntas
    const walkOff = [0.25, 0.75, 0, 0.5], galOff = [0.0, 0.1, 0.5, 0.6], duty = 0.62 - run * 0.2;
    const G = this.G;
    m.legs.forEach((l, i) => {
      const u = (this.cyc + walkOff[i] * (1 - run) + galOff[i] * run) % 1;
      const front = l.userData.front, a = (0.32 + run * 0.38) * mov;
      let ang, lift = 0;
      if (u < duty) ang = -a + (u / duty) * 2 * a;                  // apoyo: la pata va hacia atrás
      else { const w = (u - duty) / (1 - duty); ang = a - (1 - Math.cos(w * Math.PI)) * a; lift = Math.sin(w * Math.PI); } // vuelo: adelante y arriba
      l.rotation.x = ang * (front ? 0.85 : 1);
      l.scale.y = 1 - lift * (0.16 + run * 0.1) * mov;
      l.position.y = 1.08 + lift * 0.05 * mov;
      // pisada: suena al apoyar la pata
      if (G && this.state !== 'off' && this.state !== 'statue' && mov > 0.3 && this.lastU[i] > duty && u < duty && this.group.visible && G.audio && G.audio.ready && G.player) {
        const d = Math.hypot(this.pos.x - G.player.pos.x, this.pos.z - G.player.pos.z);
        if (d < 34 && (i % 2 === 0 || run < 0.5)) {
          const wet = G.world.wetAt(this.pos.x, this.pos.z); G.audio.lionStep(this.pos, sc, run > 0.5, wet);
          if (wet) G.world.ripple(this.pos.x, this.pos.z, true);
        }
      }
      this.lastU[i] = u;
    });
    // cuerpo: sube y baja dos veces por ciclo al caminar; ondula al galopar
    const U = this.cyc * Math.PI * 2;
    const bob = mov * ((1 - run) * Math.cos(U * 2) * 0.03 + run * Math.sin(U) * 0.09);
    const breath = Math.sin(this.t * (sp > 4 ? 5 : 1.6));
    // agazapado cuando acecha (busca, olfatea, merodea)
    const stalk = ['hunt', 'closet', 'prowl', 'return', 'track'].indexOf(this.state) >= 0 && run < 0.3 ? 1 : 0;
    this.crouchY += (stalk * -0.1 - this.crouchY) * Math.min(1, dt * 3);
    m.body.position.y = bob + breath * 0.01;
    m.body.rotation.x = run * Math.cos(U) * 0.07 * mov;
    m.body.rotation.z = (1 - run) * Math.sin(U) * 0.035 * mov - clamp(this.turnRate * 0.06, -0.12, 0.12);
    m.body.scale.set(1 + breath * 0.012, 1 + breath * 0.012, 1);
    m.legs.forEach(l => { l.position.y += bob * 0.5; });
    m.head.position.y = 1.52 + bob * 0.6 - (1 - run) * mov * Math.abs(Math.sin(U)) * 0.02 + stalk * -0.12 - run * 0.08;
    m.head.position.z = 1.2 + run * 0.06;
    // cola: cuelga hacia atrás; al correr se estira detrás (antes giraba hacia dentro del cuerpo)
    m.tail.rotation.z = Math.sin(this.t * 2.2) * 0.3 * (1 - run) - clamp(this.turnRate * 0.25, -0.5, 0.5);
    m.tail.rotation.x = 0.45 + Math.sin(this.t * 1.3) * 0.1 + Math.min(0.4, sp * 0.06) + run * 0.55 + Math.sin(U * 2) * 0.12 * run;
    m.tailSegs.forEach((s, i) => { if (i) { s.rotation.x = 0.25 + Math.sin(this.t * 2.2 - i * 0.8) * 0.22 * (1 - run) - run * 0.2 + Math.sin(U * 2 - i) * 0.15 * run; s.rotation.z = Math.sin(this.t * 1.7 - i) * 0.2; } });
    this.roarAnim = Math.max(0, this.roarAnim - dt); this.sniffAnim = Math.max(0, this.sniffAnim - dt);
    let hx = 0, jaw = 0.04;
    if (this.roarAnim > 0) { hx = -0.35; jaw = 0.6; }
    else if (this.sniffAnim > 0) { hx = 0.35 + Math.sin(this.t * 14) * 0.06; jaw = 0.08; }
    else hx = Math.sin(this.t * 0.9) * 0.05 + stalk * 0.18 + run * 0.12;
    m.head.rotation.x += (hx - m.head.rotation.x) * Math.min(1, dt * 8);
    const hy = Math.sin(this.t * 0.5) * 0.15 * (1 - mov * 0.6) + clamp(this.turnRate * 0.18, -0.45, 0.45);
    m.head.rotation.y += (hy - m.head.rotation.y) * Math.min(1, dt * 5);
    m.jaw.rotation.x += (jaw - m.jaw.rotation.x) * Math.min(1, dt * 12);
    // reflejo de los ojos: fuerte si la linterna lo apunta
    const cam = G && G.camera, P = G && G.player;
    let lit = 0;
    if (cam && P && P.light && !P.hidden && G.state !== 'intro') {
      const dx = this.pos.x - cam.position.x, dz = this.pos.z - cam.position.z, d = Math.hypot(dx, dz) || 1;
      const f = new T.Vector3(); cam.getWorldDirection(f); const fl = Math.hypot(f.x, f.z) || 1;
      const dot = (dx * f.x + dz * f.z) / (d * fl); lit = Math.max(0, (dot - 0.88) / 0.12) * Math.min(1, 30 / d);
    }
    const target = 0.22 + lit * 0.78; m.glowM.opacity += (target - m.glowM.opacity) * Math.min(1, dt * 6);
    const gsc = 0.18 + lit * 0.22; m.glows.forEach(gl => gl.scale.set(gsc, gsc, 1));
  };
  L.sync = function () { this.group.position.copy(this.pos); this.group.position.y += this.crouchY * this.scale; this.group.rotation.y = this.heading; };
})();
