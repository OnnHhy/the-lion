// Texturas procedurales (sin archivos externos) y dibujos de las pistas
(function () {
  const cache = {}, base = {};
  let HI = 1; // las texturas del mundo se generan al doble de resolución
  function cv(w, h) { const c = document.createElement('canvas'); c.width = w * HI; c.height = h * HI; if (HI > 1) c.getContext('2d').scale(HI, HI); return c; }
  function R(a, b) { return a + Math.random() * (b - a); }
  function rgb(r, g, b, a) { return 'rgba(' + (r | 0) + ',' + (g | 0) + ',' + (b | 0) + ',' + (a == null ? 1 : a) + ')'; }
  function blotches(x, w, h, n, col, rmin, rmax) {
    for (let i = 0; i < n; i++) {
      const cx = R(0, w), cy = R(0, h), r = R(rmin, rmax);
      const g = x.createRadialGradient(cx, cy, 0, cx, cy, r);
      g.addColorStop(0, col); g.addColorStop(1, 'rgba(0,0,0,0)');
      x.fillStyle = g; x.fillRect(cx - r, cy - r, r * 2, r * 2);
    }
  }
  function speck(x, w, h, n, col) { x.fillStyle = col; for (let i = 0; i < n; i++) x.fillRect(R(0, w), R(0, h), R(1, 3), R(1, 3)); }

  const gens = {
    planks() {
      const c = cv(256, 256), x = c.getContext('2d'), n = 6, pw = 256 / n;
      for (let i = 0; i < n; i++) {
        const k = R(0.7, 1.15); x.fillStyle = rgb(86 * k, 64 * k, 44 * k); x.fillRect(i * pw, 0, pw, 256);
        for (let j = 0; j < 16; j++) {
          x.strokeStyle = rgb(30, 20, 12, R(.15, .45)); x.lineWidth = R(.5, 1.6); x.beginPath();
          const xx = i * pw + R(2, pw - 2); x.moveTo(xx, 0);
          x.bezierCurveTo(xx + R(-4, 4), 85, xx + R(-4, 4), 170, xx + R(-3, 3), 256); x.stroke();
        }
        x.fillStyle = 'rgba(12,8,5,.95)'; x.fillRect(i * pw, 0, 2, 256);
        if (Math.random() < .6) { x.fillStyle = 'rgba(28,16,9,.75)'; x.beginPath(); x.ellipse(i * pw + R(8, pw - 8), R(20, 236), R(2, 5), R(4, 8), 0, 0, 7); x.fill(); }
        x.fillStyle = 'rgba(12,8,5,.8)'; x.fillRect(i * pw, R(30, 226), pw, 2);
      }
      blotches(x, 256, 256, 18, 'rgba(20,28,16,.35)', 20, 60);
      const g = x.createLinearGradient(0, 160, 0, 256); g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(1, 'rgba(25,22,12,.55)');
      x.fillStyle = g; x.fillRect(0, 0, 256, 256);
      return c;
    },
    plaster() {
      const c = cv(256, 256), x = c.getContext('2d');
      x.fillStyle = '#6b6152'; x.fillRect(0, 0, 256, 256);
      blotches(x, 256, 256, 40, 'rgba(40,36,28,.35)', 10, 50);
      blotches(x, 256, 256, 20, 'rgba(140,130,110,.18)', 10, 40);
      x.strokeStyle = 'rgba(30,25,20,.6)'; x.lineWidth = 1;
      for (let i = 0; i < 5; i++) { let px = R(0, 256), py = R(0, 256); x.beginPath(); x.moveTo(px, py); for (let j = 0; j < 6; j++) { px += R(-14, 14); py += R(4, 18); x.lineTo(px, py); } x.stroke(); }
      for (let i = 0; i < 6; i++) { x.fillStyle = 'rgba(80,60,40,.8)'; const bx = R(0, 230), by = R(0, 230); x.fillRect(bx, by, R(16, 34), R(8, 14)); }
      const g = x.createLinearGradient(0, 150, 0, 256); g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(1, 'rgba(35,30,15,.6)');
      x.fillStyle = g; x.fillRect(0, 0, 256, 256);
      return c;
    },
    mud() {
      const c = cv(256, 256), x = c.getContext('2d');
      x.fillStyle = '#2d2b1f'; x.fillRect(0, 0, 256, 256);
      blotches(x, 256, 256, 50, 'rgba(15,14,8,.5)', 8, 40);
      blotches(x, 256, 256, 30, 'rgba(70,64,44,.35)', 8, 30);
      blotches(x, 256, 256, 14, 'rgba(30,45,22,.45)', 10, 35);
      speck(x, 256, 256, 300, 'rgba(90,85,70,.5)');
      return c;
    },
    dirt() {
      const c = cv(256, 256), x = c.getContext('2d');
      x.fillStyle = '#463d2c'; x.fillRect(0, 0, 256, 256);
      blotches(x, 256, 256, 40, 'rgba(20,18,10,.45)', 8, 34);
      blotches(x, 256, 256, 30, 'rgba(110,95,70,.25)', 8, 30);
      x.fillStyle = 'rgba(20,16,10,.5)'; x.fillRect(70, 0, 16, 256); x.fillRect(170, 0, 16, 256);
      speck(x, 256, 256, 260, 'rgba(120,110,90,.5)');
      return c;
    },
    roof() {
      const c = cv(256, 256), x = c.getContext('2d');
      x.fillStyle = '#2a2724'; x.fillRect(0, 0, 256, 256);
      for (let r = 0; r < 8; r++) for (let i = 0; i < 9; i++) {
        const k = R(.7, 1.2); x.fillStyle = rgb(55 * k, 48 * k, 42 * k);
        x.fillRect(i * 32 - (r % 2) * 16, r * 32, 30, 30);
      }
      blotches(x, 256, 256, 20, 'rgba(30,45,20,.4)', 10, 40);
      return c;
    },
    stone() {
      const c = cv(256, 256), x = c.getContext('2d');
      x.fillStyle = '#26241f'; x.fillRect(0, 0, 256, 256);
      for (let r = 0; r < 8; r++) for (let i = 0; i < 5; i++) {
        const k = R(.7, 1.2); x.fillStyle = rgb(92 * k, 88 * k, 78 * k);
        x.fillRect(i * 56 - (r % 2) * 28 + 2, r * 32 + 2, 52, 28);
      }
      blotches(x, 256, 256, 20, 'rgba(30,40,20,.45)', 10, 40);
      return c;
    },
    hay() {
      const c = cv(128, 128), x = c.getContext('2d');
      x.fillStyle = '#7a6532'; x.fillRect(0, 0, 128, 128);
      for (let i = 0; i < 400; i++) { x.strokeStyle = rgb(R(90, 170), R(70, 140), R(30, 60), .7); x.beginPath(); const a = R(0, 128), b = R(0, 128); x.moveTo(a, b); x.lineTo(a + R(-12, 12), b + R(-3, 3)); x.stroke(); }
      return c;
    },
    bark() {
      const c = cv(64, 128), x = c.getContext('2d');
      x.fillStyle = '#1e1a15'; x.fillRect(0, 0, 64, 128);
      for (let i = 0; i < 40; i++) { x.strokeStyle = rgb(R(40, 70), R(35, 55), R(25, 40), .8); x.beginPath(); const a = R(0, 64); x.moveTo(a, 0); x.lineTo(a + R(-6, 6), 128); x.stroke(); }
      return c;
    }
  };

  TL.tex = {
    get(name, rx, ry) {
      rx = Math.max(1, Math.round((rx || 1) * 2) / 2); ry = Math.max(1, Math.round((ry || 1) * 2) / 2);
      const key = name + '_' + rx + '_' + ry;
      if (cache[key]) return cache[key];
      if (!base[name]) { HI = 2; base[name] = gens[name](); HI = 1; }
      const t = new THREE.CanvasTexture(base[name]);
      t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(rx, ry); t.anisotropy = TL.tex.aniso || 1;
      cache[key] = t; return t;
    },
    canvas(c) { const t = new THREE.CanvasTexture(c); (c._tex = c._tex || []).push(t); return t; },
    // pelaje: rayas cortas en una dirección, lomo más oscuro, panza más clara
    fur(baseHex, darkHex, bellyHex, coarse) {
      const key = 'fur' + baseHex + '_' + darkHex + '_' + bellyHex + (coarse ? 'c' : '');
      if (cache[key]) return cache[key];
      const c = cv(256, 256), x = c.getContext('2d');
      const hx = h => '#' + h.toString(16).padStart(6, '0');
      const g = x.createLinearGradient(0, 0, 0, 256); g.addColorStop(0, hx(darkHex)); g.addColorStop(0.45, hx(baseHex)); g.addColorStop(1, hx(bellyHex));
      x.fillStyle = g; x.fillRect(0, 0, 256, 256);
      const n = coarse ? 1600 : 3200, len = coarse ? 26 : 14;
      for (let i = 0; i < n; i++) {
        const px = R(0, 256), py = R(0, 256), l = R(len * 0.5, len);
        x.strokeStyle = Math.random() < 0.55 ? 'rgba(0,0,0,' + R(.08, .25) + ')' : 'rgba(255,235,200,' + R(.05, .16) + ')';
        x.lineWidth = coarse ? R(1.2, 3) : R(.8, 1.8); x.beginPath(); x.moveTo(px, py); x.lineTo(px + R(-2, 2), py + l); x.stroke();
      }
      const t = new THREE.CanvasTexture(c); t.wrapS = t.wrapT = THREE.RepeatWrapping; cache[key] = t; return t;
    },
    mist() {
      if (cache.mist) return cache.mist;
      const c = cv(256, 256), x = c.getContext('2d');
      for (let i = 0; i < 70; i++) { const cx = R(0, 256), cy = R(0, 256), r = R(20, 70); [[0, 0], [256, 0], [-256, 0], [0, 256], [0, -256]].forEach(o => { const g = x.createRadialGradient(cx + o[0], cy + o[1], 0, cx + o[0], cy + o[1], r); g.addColorStop(0, 'rgba(255,255,255,' + R(.08, .22) + ')'); g.addColorStop(1, 'rgba(255,255,255,0)'); x.fillStyle = g; x.fillRect(cx + o[0] - r, cy + o[1] - r, r * 2, r * 2); }); }
      const t = new THREE.CanvasTexture(c); t.wrapS = t.wrapT = THREE.RepeatWrapping; cache.mist = t; return t;
    },
    treeline() {
      if (cache.treeline) return cache.treeline;
      const c = cv(1024, 256), x = c.getContext('2d'); x.fillStyle = '#05070a';
      x.beginPath(); x.moveTo(0, 256); let px = 0;
      while (px < 1024) { const h = R(60, 200); x.lineTo(px, 256 - h * R(.85, 1)); x.lineTo(px + R(4, 10), 256 - h); x.lineTo(px + R(10, 26), 256 - h * R(.6, .9)); px += R(14, 34); }
      x.lineTo(1024, 256); x.closePath(); x.fill();
      x.strokeStyle = '#05070a'; for (let i = 0; i < 18; i++) { const bx = R(0, 1024), by = R(40, 120); x.lineWidth = R(1, 3); x.beginPath(); x.moveTo(bx, 256); x.lineTo(bx + R(-6, 6), by); x.stroke(); for (let k = 0; k < 4; k++) { x.lineWidth = 1; x.beginPath(); const yy = by + R(0, 60); x.moveTo(bx, yy); x.lineTo(bx + R(-30, 30), yy - R(5, 30)); x.stroke(); } }
      const t = new THREE.CanvasTexture(c); t.wrapS = THREE.RepeatWrapping; cache.treeline = t; return t;
    },
    glow() {
      if (cache.glow) return cache.glow;
      const c = cv(64, 64), x = c.getContext('2d'), g = x.createRadialGradient(32, 32, 0, 32, 32, 32);
      g.addColorStop(0, 'rgba(255,255,255,1)'); g.addColorStop(0.25, 'rgba(255,255,255,.45)'); g.addColorStop(1, 'rgba(255,255,255,0)');
      x.fillStyle = g; x.fillRect(0, 0, 64, 64); cache.glow = new THREE.CanvasTexture(c); return cache.glow;
    },
    sign(text) {
      const key = 'sign' + text; if (cache[key]) return cache[key];
      const c = cv(512, 128), x = c.getContext('2d');
      x.fillStyle = '#3a2a1a'; x.fillRect(0, 0, 512, 128); blotches(x, 512, 128, 20, 'rgba(0,0,0,.4)', 10, 50);
      x.fillStyle = 'rgba(220,200,160,.75)'; x.font = 'bold 72px Georgia'; x.textAlign = 'center'; x.fillText(text, 256, 92);
      blotches(x, 512, 128, 14, 'rgba(40,30,20,.7)', 6, 30);
      x.strokeStyle = '#1a120a'; x.lineWidth = 8; x.strokeRect(0, 0, 512, 128);
      cache[key] = new THREE.CanvasTexture(c); return cache[key];
    }
  };

  // ---------- Dibujos de pistas ----------
  function paw(x, cx, cy, s, rot, col) {
    x.save(); x.translate(cx, cy); x.rotate(rot); x.fillStyle = col;
    x.beginPath(); x.ellipse(0, s * 0.35, s * 0.55, s * 0.45, 0, 0, 7); x.fill();
    [[-0.58, -0.22], [-0.21, -0.55], [0.21, -0.55], [0.58, -0.22]].forEach(p => { x.beginPath(); x.ellipse(p[0] * s, p[1] * s, s * 0.17, s * 0.23, 0, 0, 7); x.fill(); });
    x.restore();
  }
  function lionShape(x, cx, cy, s, col, mane, dir) {
    x.save(); x.translate(cx, cy); x.scale(dir || 1, 1);
    x.fillStyle = col;
    x.fillRect(-s * 0.9, s * 0.1, s * 0.18, s * 0.6); x.fillRect(-s * 0.55, s * 0.1, s * 0.18, s * 0.62);
    x.fillRect(s * 0.35, s * 0.1, s * 0.18, s * 0.62); x.fillRect(s * 0.65, s * 0.1, s * 0.18, s * 0.6);
    x.beginPath(); x.ellipse(0, 0, s * 1.05, s * 0.42, 0, 0, 7); x.fill();
    x.strokeStyle = col; x.lineWidth = s * 0.08; x.beginPath(); x.moveTo(-s, -s * 0.05); x.quadraticCurveTo(-s * 1.6, -s * 0.1, -s * 1.5, s * 0.5); x.stroke();
    x.fillStyle = mane; x.beginPath(); x.arc(s * 1.0, -s * 0.35, s * 0.55, 0, 7); x.fill();
    x.fillStyle = col; x.beginPath(); x.arc(s * 1.12, -s * 0.33, s * 0.3, 0, 7); x.fill();
    x.restore();
  }
  function paper(x, w, h, col) {
    x.fillStyle = col; x.fillRect(0, 0, w, h);
    blotches(x, w, h, 30, 'rgba(120,90,40,.18)', 10, 60);
    const g = x.createRadialGradient(w / 2, h / 2, h * 0.3, w / 2, h / 2, w * 0.7);
    g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(1, 'rgba(60,40,15,.55)'); x.fillStyle = g; x.fillRect(0, 0, w, h);
  }
  function wrap(x, text, X, Y, maxW, lh) {
    const words = text.split(' '); let line = '';
    words.forEach(wd => { const t = line + wd + ' '; if (x.measureText(t).width > maxW && line) { x.fillText(line, X, Y); line = wd + ' '; Y += lh; } else line = t; });
    x.fillText(line, X, Y);
  }

  const arts = {
    huellas() {
      const c = cv(512, 352), x = c.getContext('2d');
      x.fillStyle = '#2b281c'; x.fillRect(0, 0, 512, 352);
      blotches(x, 512, 352, 60, 'rgba(12,10,6,.5)', 10, 50); speck(x, 512, 352, 400, 'rgba(100,95,75,.5)');
      for (let i = 0; i < 4; i++) { paw(x, 90 + i * 110, 120 + (i % 2) * 40, 34, 1.5, 'rgba(10,8,5,.85)'); paw(x, 70 + i * 110, 250 + (i % 2) * 22, 15, 1.5, 'rgba(10,8,5,.8)'); }
      return c;
    },
    huellasDecal() {
      const c = cv(512, 256), x = c.getContext('2d');
      for (let i = 0; i < 5; i++) { paw(x, 50 + i * 100, 80 + (i % 2) * 30, 30, 1.57, 'rgba(8,6,3,.85)'); paw(x, 40 + i * 100, 190 + (i % 2) * 18, 13, 1.57, 'rgba(8,6,3,.8)'); }
      return c;
    },
    foto() {
      const c = cv(512, 352), x = c.getContext('2d');
      const g = x.createLinearGradient(0, 0, 0, 352); g.addColorStop(0, '#b59a72'); g.addColorStop(1, '#6e5a3e'); x.fillStyle = g; x.fillRect(0, 0, 512, 352);
      x.fillStyle = '#4a3b28'; x.fillRect(0, 250, 512, 102);
      for (let i = 0; i < 3; i++) {
        const px = 110 + i * 150; x.fillStyle = '#2a2017';
        x.fillRect(px - 16, 130, 32, 90); x.fillRect(px - 14, 220, 12, 40); x.fillRect(px + 2, 220, 12, 40);
        x.beginPath(); x.arc(px, 115, 15, 0, 7); x.fill(); x.fillRect(px - 26, 98, 52, 7); x.fillRect(px - 14, 82, 28, 18);
        x.strokeStyle = '#1b140d'; x.lineWidth = 5; x.beginPath(); x.moveTo(px + 14, 140); x.lineTo(px + 50, 70); x.stroke();
      }
      lionShape(x, 250, 278, 70, '#2a2017', '#18110a', 1);
      x.strokeStyle = '#3c3226'; x.lineWidth = 4; x.setLineDash([8, 5]); x.beginPath(); x.moveTo(330, 255); x.lineTo(420, 230); x.lineTo(420, 160); x.stroke(); x.setLineDash([]);
      x.strokeStyle = 'rgba(230,215,180,.35)'; x.lineWidth = 1; for (let i = 0; i < 14; i++) { x.beginPath(); const a = R(0, 512); x.moveTo(a, 0); x.lineTo(a + R(-30, 30), 352); x.stroke(); }
      x.fillStyle = 'rgba(40,25,10,.8)'; x.font = 'italic 22px Georgia'; x.fillText('Hnos. Ferrán — la cacería', 30, 335);
      const v = x.createRadialGradient(256, 176, 120, 256, 176, 330); v.addColorStop(0, 'rgba(0,0,0,0)'); v.addColorStop(1, 'rgba(30,18,5,.75)'); x.fillStyle = v; x.fillRect(0, 0, 512, 352);
      x.strokeStyle = '#d8ccb0'; x.lineWidth = 14; x.strokeRect(0, 0, 512, 352);
      return c;
    },
    dibujo() {
      const c = cv(512, 352), x = c.getContext('2d');
      paper(x, 512, 352, '#e8dfc8');
      x.globalAlpha = .9; x.lineWidth = 4; x.lineCap = 'round';
      function scrib(col, cx, cy, rx, ry, n) { x.strokeStyle = col; for (let i = 0; i < n; i++) { x.beginPath(); const a = R(0, 6.3); x.moveTo(cx + Math.cos(a) * rx * R(.2, 1), cy + Math.sin(a) * ry * R(.2, 1)); x.lineTo(cx + Math.cos(a + 2) * rx * R(.2, 1), cy + Math.sin(a + 2) * ry * R(.2, 1)); x.stroke(); } }
      scrib('#7a4a1c', 210, 150, 120, 70, 70); scrib('#4a2a10', 320, 110, 60, 60, 60); scrib('#c58a2a', 320, 115, 32, 30, 25);
      x.strokeStyle = '#7a4a1c'; [130, 170, 250, 290].forEach(l => { x.beginPath(); x.moveTo(l, 200); x.lineTo(l, 260); x.stroke(); });
      scrib('#e0a830', 200, 245, 50, 26, 40); scrib('#c58a2a', 250, 232, 20, 18, 18);
      x.strokeStyle = '#e0a830'; [170, 190, 215, 235].forEach(l => { x.beginPath(); x.moveTo(l, 265); x.lineTo(l, 290); x.stroke(); });
      x.strokeStyle = '#b03030'; x.beginPath(); x.moveTo(420, 230); x.lineTo(395, 300); x.lineTo(445, 300); x.closePath(); x.stroke();
      x.strokeStyle = '#3a2a20'; x.beginPath(); x.arc(420, 212, 16, 0, 7); x.stroke(); x.beginPath(); x.arc(420, 214, 7, 0.2, 2.9); x.stroke();
      x.beginPath(); x.moveTo(410, 300); x.lineTo(408, 325); x.moveTo(430, 300); x.lineTo(432, 325); x.moveTo(402, 255); x.lineTo(375, 240); x.moveTo(438, 255); x.lineTo(470, 240); x.stroke();
      x.strokeStyle = '#e8c020'; x.beginPath(); x.arc(450, 55, 26, 0, 7); x.stroke();
      x.globalAlpha = 1; x.fillStyle = '#2a3a8a'; x.font = 'bold 34px "Comic Sans MS", cursive'; x.fillText('MIS AMIGOS', 40, 60);
      return c;
    },
    pelo() {
      const c = cv(512, 352), x = c.getContext('2d');
      x.fillStyle = '#cfc6b4'; x.fillRect(0, 0, 512, 352); blotches(x, 512, 352, 30, 'rgba(120,100,70,.25)', 20, 70);
      x.strokeStyle = 'rgba(150,140,120,.6)'; x.lineWidth = 2; for (let i = 0; i < 12; i++) { x.beginPath(); x.moveTo(0, i * 30); x.bezierCurveTo(150, i * 30 + 10, 350, i * 30 - 10, 512, i * 30 + 5); x.stroke(); }
      for (let i = 0; i < 60; i++) {
        x.strokeStyle = rgb(R(200, 240), R(150, 190), R(40, 80), .9); x.lineWidth = R(1, 2.2);
        let px = R(150, 360), py = R(110, 250); x.beginPath(); x.moveTo(px, py);
        x.bezierCurveTo(px + R(-50, 50), py + R(-30, 30), px + R(-60, 60), py + R(-30, 30), px + R(-80, 80), py + R(-40, 40)); x.stroke();
      }
      return c;
    },
    trampa() {
      const c = cv(512, 352), x = c.getContext('2d');
      x.fillStyle = '#2a2016'; x.fillRect(0, 0, 512, 352); blotches(x, 512, 352, 30, 'rgba(10,8,5,.5)', 20, 70);
      x.strokeStyle = '#6a3e1e'; x.lineWidth = 14; x.beginPath(); x.arc(256, 180, 110, Math.PI * 1.05, Math.PI * 1.95); x.stroke(); x.beginPath(); x.arc(256, 180, 110, Math.PI * 0.05, Math.PI * 0.95); x.stroke();
      x.fillStyle = '#5a3418'; for (let i = 0; i < 9; i++) { const a = Math.PI * (1.1 + i * 0.1); const px = 256 + Math.cos(a) * 104, py = 180 + Math.sin(a) * 104; x.beginPath(); x.moveTo(px - 8, py); x.lineTo(px, py + 22); x.lineTo(px + 8, py); x.fill(); }
      x.fillStyle = '#4a2c14'; x.fillRect(220, 170, 72, 20); x.fillRect(150, 300, 220, 10);
      for (let i = 0; i < 40; i++) { x.strokeStyle = rgb(R(30, 55), R(20, 35), R(12, 20), .95); x.lineWidth = R(1, 2); x.beginPath(); const px = R(190, 330), py = R(90, 130); x.moveTo(px, py); x.quadraticCurveTo(px + R(-30, 30), py + R(-20, 20), px + R(-40, 40), py + R(-10, 30)); x.stroke(); }
      blotches(x, 512, 352, 8, 'rgba(70,15,10,.7)', 10, 30);
      return c;
    },
    libro() {
      const c = cv(512, 352), x = c.getContext('2d');
      paper(x, 512, 352, '#cfc2a0');
      x.strokeStyle = 'rgba(120,40,30,.35)'; x.lineWidth = 1; for (let i = 1; i < 11; i++) { x.beginPath(); x.moveTo(20, i * 32); x.lineTo(492, i * 32); x.stroke(); }
      x.beginPath(); x.moveTo(360, 10); x.lineTo(360, 342); x.stroke();
      x.fillStyle = '#2a1e18'; x.font = 'italic 22px Georgia';
      [['Piel de puma', '$ 80'], ['Cachorro (vendido)', '$ 120'], ['Cachorro (vendido)', '$ 120'], ['Cadenas nuevas', '- $ 35'], ['Carne (cebo)', '- $ 10'], ['Piel del grande', '$ 300 ?']].forEach((r, i) => { x.fillText(r[0], 30, 56 + i * 44); x.fillText(r[1], 380, 56 + i * 44); });
      x.strokeStyle = 'rgba(30,20,20,.8)'; x.lineWidth = 2; x.beginPath(); x.moveTo(28, 56 + 5 * 44 - 8); x.lineTo(470, 56 + 5 * 44 - 8); x.stroke();
      blotches(x, 512, 352, 4, 'rgba(90,50,20,.35)', 20, 50);
      return c;
    },
    collar() {
      const c = cv(512, 352), x = c.getContext('2d');
      x.fillStyle = '#2a241c'; x.fillRect(0, 0, 512, 352);
      for (let i = 0; i < 900; i++) { x.fillStyle = 'rgba(' + (60 + Math.random() * 40) + ',' + (50 + Math.random() * 30) + ',30,.25)'; x.fillRect(Math.random() * 512, Math.random() * 352, 3, 2); }
      x.strokeStyle = '#5a3a1e'; x.lineWidth = 26; x.lineCap = 'round'; x.beginPath(); x.ellipse(256, 176, 140, 90, -0.2, 0.4, Math.PI * 2 - 0.3); x.stroke();
      x.strokeStyle = 'rgba(0,0,0,.35)'; x.lineWidth = 2; x.setLineDash([6, 6]); x.beginPath(); x.ellipse(256, 176, 140, 90, -0.2, 0.4, Math.PI * 2 - 0.3); x.stroke(); x.setLineDash([]);
      x.fillStyle = '#9a8a60'; x.beginPath(); x.arc(392, 205, 24, 0, Math.PI * 2); x.fill(); x.fillStyle = '#3a2a14'; x.font = 'bold 18px Georgia'; x.textAlign = 'center'; x.fillText('SOL', 392, 212); x.textAlign = 'left';
      x.fillStyle = 'rgba(120,20,10,.5)'; x.beginPath(); x.arc(150, 120, 14, 0, 6.3); x.fill();
      return c;
    },
    diario() {
      const c = cv(512, 352), x = c.getContext('2d');
      paper(x, 512, 352, '#d9cdb0');
      x.strokeStyle = 'rgba(80,90,140,.35)'; x.lineWidth = 1; for (let i = 1; i < 11; i++) { x.beginPath(); x.moveTo(20, i * 32); x.lineTo(492, i * 32); x.stroke(); }
      x.fillStyle = '#2a2030'; x.font = 'italic 26px Georgia';
      wrap(x, 'Mañana lo hacemos cruzar otra vez. El viejo ya no se levanta como antes. Si el pueblo lo ve, nadie se queda.', 30, 58, 450, 32);
      x.font = 'italic 30px Georgia'; x.fillText('— F.', 400, 300);
      blotches(x, 512, 352, 3, 'rgba(90,50,20,.4)', 20, 40);
      return c;
    },
    cartel() {
      const c = cv(512, 352), x = c.getContext('2d');
      paper(x, 512, 352, '#cdbb8e');
      x.fillStyle = '#2a1a10'; x.textAlign = 'center';
      x.font = 'bold 54px Georgia'; x.fillText('SE BUSCA', 256, 70);
      lionShape(x, 230, 160, 48, '#3a2414', '#22150b', 1);
      x.font = 'bold 26px Georgia'; x.fillText('LA PIEL DEL LEÓN DE LA CIÉNAGA', 256, 250);
      x.font = 'bold 40px Georgia'; x.fillText('RECOMPENSA $300', 256, 298);
      x.font = 'italic 20px Georgia'; x.fillText('Tratar con los Hnos. Ferrán', 256, 330);
      x.textAlign = 'left';
      x.fillStyle = 'rgba(40,20,10,.8)'; x.beginPath(); x.arc(30, 30, 7, 0, 7); x.fill(); x.beginPath(); x.arc(482, 30, 7, 0, 7); x.fill();
      return c;
    }
  };
  const artCache = {};
  // Si existe una imagen real de la pista (js/pistas-img.js → TL.CLUE_IMG), se dibuja encima del dibujo por código
  TL.art = function (id) {
    if (artCache[id]) return artCache[id];
    const c = artCache[id] = arts[id]();
    const src = TL.CLUE_IMG && TL.CLUE_IMG[id];
    if (src) {
      const im = new Image();
      im.onload = () => {
        const x = c.getContext('2d'); x.setTransform(1, 0, 0, 1, 0, 0);
        const r = Math.max(c.width / im.width, c.height / im.height), w = im.width * r, h = im.height * r;
        x.drawImage(im, (c.width - w) / 2, (c.height - h) / 2, w, h);
        (c._tex || []).forEach(t => t.needsUpdate = true);
      };
      im.src = src;
    }
    return c;
  };
})();
